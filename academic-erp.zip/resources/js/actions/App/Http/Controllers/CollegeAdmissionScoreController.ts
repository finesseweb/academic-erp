import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CollegeAdmissionScoreController::index
 * @see app/Http/Controllers/CollegeAdmissionScoreController.php:17
 * @route '/college/{college}/admission-scores'
 */
export const index = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/college/{college}/admission-scores',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionScoreController::index
 * @see app/Http/Controllers/CollegeAdmissionScoreController.php:17
 * @route '/college/{college}/admission-scores'
 */
index.url = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { college: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { college: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                }

    return index.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionScoreController::index
 * @see app/Http/Controllers/CollegeAdmissionScoreController.php:17
 * @route '/college/{college}/admission-scores'
 */
index.get = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CollegeAdmissionScoreController::index
 * @see app/Http/Controllers/CollegeAdmissionScoreController.php:17
 * @route '/college/{college}/admission-scores'
 */
index.head = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionScoreController::index
 * @see app/Http/Controllers/CollegeAdmissionScoreController.php:17
 * @route '/college/{college}/admission-scores'
 */
    const indexForm = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionScoreController::index
 * @see app/Http/Controllers/CollegeAdmissionScoreController.php:17
 * @route '/college/{college}/admission-scores'
 */
        indexForm.get = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CollegeAdmissionScoreController::index
 * @see app/Http/Controllers/CollegeAdmissionScoreController.php:17
 * @route '/college/{college}/admission-scores'
 */
        indexForm.head = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CollegeAdmissionScoreController::upsert
 * @see app/Http/Controllers/CollegeAdmissionScoreController.php:51
 * @route '/college/{college}/admission-application-choices/{choice}/scores'
 */
export const upsert = (args: { college: number | { id: number }, choice: number | { id: number } } | [college: number | { id: number }, choice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: upsert.url(args, options),
    method: 'put',
})

upsert.definition = {
    methods: ["put"],
    url: '/college/{college}/admission-application-choices/{choice}/scores',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionScoreController::upsert
 * @see app/Http/Controllers/CollegeAdmissionScoreController.php:51
 * @route '/college/{college}/admission-application-choices/{choice}/scores'
 */
upsert.url = (args: { college: number | { id: number }, choice: number | { id: number } } | [college: number | { id: number }, choice: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    choice: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                choice: typeof args.choice === 'object'
                ? args.choice.id
                : args.choice,
                }

    return upsert.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{choice}', parsedArgs.choice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionScoreController::upsert
 * @see app/Http/Controllers/CollegeAdmissionScoreController.php:51
 * @route '/college/{college}/admission-application-choices/{choice}/scores'
 */
upsert.put = (args: { college: number | { id: number }, choice: number | { id: number } } | [college: number | { id: number }, choice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: upsert.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionScoreController::upsert
 * @see app/Http/Controllers/CollegeAdmissionScoreController.php:51
 * @route '/college/{college}/admission-application-choices/{choice}/scores'
 */
    const upsertForm = (args: { college: number | { id: number }, choice: number | { id: number } } | [college: number | { id: number }, choice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: upsert.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionScoreController::upsert
 * @see app/Http/Controllers/CollegeAdmissionScoreController.php:51
 * @route '/college/{college}/admission-application-choices/{choice}/scores'
 */
        upsertForm.put = (args: { college: number | { id: number }, choice: number | { id: number } } | [college: number | { id: number }, choice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: upsert.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    upsert.form = upsertForm
const CollegeAdmissionScoreController = { index, upsert }

export default CollegeAdmissionScoreController