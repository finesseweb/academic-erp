import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AuthorizedSignatoryController::index
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:18
 * @route '/admin/university/signatories'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/university/signatories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AuthorizedSignatoryController::index
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:18
 * @route '/admin/university/signatories'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AuthorizedSignatoryController::index
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:18
 * @route '/admin/university/signatories'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AuthorizedSignatoryController::index
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:18
 * @route '/admin/university/signatories'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AuthorizedSignatoryController::index
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:18
 * @route '/admin/university/signatories'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AuthorizedSignatoryController::index
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:18
 * @route '/admin/university/signatories'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AuthorizedSignatoryController::index
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:18
 * @route '/admin/university/signatories'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\AuthorizedSignatoryController::create
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:54
 * @route '/admin/university/signatories/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/university/signatories/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AuthorizedSignatoryController::create
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:54
 * @route '/admin/university/signatories/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AuthorizedSignatoryController::create
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:54
 * @route '/admin/university/signatories/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AuthorizedSignatoryController::create
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:54
 * @route '/admin/university/signatories/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AuthorizedSignatoryController::create
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:54
 * @route '/admin/university/signatories/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AuthorizedSignatoryController::create
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:54
 * @route '/admin/university/signatories/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AuthorizedSignatoryController::create
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:54
 * @route '/admin/university/signatories/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\AuthorizedSignatoryController::store
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:61
 * @route '/admin/university/signatories'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/university/signatories',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AuthorizedSignatoryController::store
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:61
 * @route '/admin/university/signatories'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AuthorizedSignatoryController::store
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:61
 * @route '/admin/university/signatories'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AuthorizedSignatoryController::store
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:61
 * @route '/admin/university/signatories'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AuthorizedSignatoryController::store
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:61
 * @route '/admin/university/signatories'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\AuthorizedSignatoryController::edit
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:68
 * @route '/admin/university/signatories/{signatory}/edit'
 */
export const edit = (args: { signatory: number | { id: number } } | [signatory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/university/signatories/{signatory}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AuthorizedSignatoryController::edit
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:68
 * @route '/admin/university/signatories/{signatory}/edit'
 */
edit.url = (args: { signatory: number | { id: number } } | [signatory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { signatory: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { signatory: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    signatory: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        signatory: typeof args.signatory === 'object'
                ? args.signatory.id
                : args.signatory,
                }

    return edit.definition.url
            .replace('{signatory}', parsedArgs.signatory.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AuthorizedSignatoryController::edit
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:68
 * @route '/admin/university/signatories/{signatory}/edit'
 */
edit.get = (args: { signatory: number | { id: number } } | [signatory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AuthorizedSignatoryController::edit
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:68
 * @route '/admin/university/signatories/{signatory}/edit'
 */
edit.head = (args: { signatory: number | { id: number } } | [signatory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AuthorizedSignatoryController::edit
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:68
 * @route '/admin/university/signatories/{signatory}/edit'
 */
    const editForm = (args: { signatory: number | { id: number } } | [signatory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AuthorizedSignatoryController::edit
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:68
 * @route '/admin/university/signatories/{signatory}/edit'
 */
        editForm.get = (args: { signatory: number | { id: number } } | [signatory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AuthorizedSignatoryController::edit
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:68
 * @route '/admin/university/signatories/{signatory}/edit'
 */
        editForm.head = (args: { signatory: number | { id: number } } | [signatory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\AuthorizedSignatoryController::update
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:76
 * @route '/admin/university/signatories/{signatory}'
 */
export const update = (args: { signatory: number | { id: number } } | [signatory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/university/signatories/{signatory}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\AuthorizedSignatoryController::update
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:76
 * @route '/admin/university/signatories/{signatory}'
 */
update.url = (args: { signatory: number | { id: number } } | [signatory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { signatory: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { signatory: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    signatory: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        signatory: typeof args.signatory === 'object'
                ? args.signatory.id
                : args.signatory,
                }

    return update.definition.url
            .replace('{signatory}', parsedArgs.signatory.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AuthorizedSignatoryController::update
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:76
 * @route '/admin/university/signatories/{signatory}'
 */
update.patch = (args: { signatory: number | { id: number } } | [signatory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\AuthorizedSignatoryController::update
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:76
 * @route '/admin/university/signatories/{signatory}'
 */
    const updateForm = (args: { signatory: number | { id: number } } | [signatory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AuthorizedSignatoryController::update
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:76
 * @route '/admin/university/signatories/{signatory}'
 */
        updateForm.patch = (args: { signatory: number | { id: number } } | [signatory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\AuthorizedSignatoryController::status
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:84
 * @route '/admin/university/signatories/{signatory}/status'
 */
export const status = (args: { signatory: number | { id: number } } | [signatory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

status.definition = {
    methods: ["patch"],
    url: '/admin/university/signatories/{signatory}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\AuthorizedSignatoryController::status
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:84
 * @route '/admin/university/signatories/{signatory}/status'
 */
status.url = (args: { signatory: number | { id: number } } | [signatory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { signatory: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { signatory: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    signatory: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        signatory: typeof args.signatory === 'object'
                ? args.signatory.id
                : args.signatory,
                }

    return status.definition.url
            .replace('{signatory}', parsedArgs.signatory.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AuthorizedSignatoryController::status
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:84
 * @route '/admin/university/signatories/{signatory}/status'
 */
status.patch = (args: { signatory: number | { id: number } } | [signatory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\AuthorizedSignatoryController::status
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:84
 * @route '/admin/university/signatories/{signatory}/status'
 */
    const statusForm = (args: { signatory: number | { id: number } } | [signatory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: status.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AuthorizedSignatoryController::status
 * @see app/Http/Controllers/AuthorizedSignatoryController.php:84
 * @route '/admin/university/signatories/{signatory}/status'
 */
        statusForm.patch = (args: { signatory: number | { id: number } } | [signatory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: status.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    status.form = statusForm
const AuthorizedSignatoryController = { index, create, store, edit, update, status }

export default AuthorizedSignatoryController