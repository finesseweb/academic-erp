import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::index
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:32
 * @route '/college/{college}/admission-form-setup'
 */
export const index = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/college/{college}/admission-form-setup',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::index
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:32
 * @route '/college/{college}/admission-form-setup'
 */
index.url = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { college: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { college: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                }

    return index.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::index
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:32
 * @route '/college/{college}/admission-form-setup'
 */
index.get = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::index
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:32
 * @route '/college/{college}/admission-form-setup'
 */
index.head = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::index
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:32
 * @route '/college/{college}/admission-form-setup'
 */
    const indexForm = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::index
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:32
 * @route '/college/{college}/admission-form-setup'
 */
        indexForm.get = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::index
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:32
 * @route '/college/{college}/admission-form-setup'
 */
        indexForm.head = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::updateApplicantRegistrationSettings
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:439
 * @route '/college/{college}/admission-form-setup/applicant-registration-settings'
 */
export const updateApplicantRegistrationSettings = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateApplicantRegistrationSettings.url(args, options),
    method: 'patch',
})

updateApplicantRegistrationSettings.definition = {
    methods: ["patch"],
    url: '/college/{college}/admission-form-setup/applicant-registration-settings',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::updateApplicantRegistrationSettings
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:439
 * @route '/college/{college}/admission-form-setup/applicant-registration-settings'
 */
updateApplicantRegistrationSettings.url = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { college: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { college: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                }

    return updateApplicantRegistrationSettings.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::updateApplicantRegistrationSettings
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:439
 * @route '/college/{college}/admission-form-setup/applicant-registration-settings'
 */
updateApplicantRegistrationSettings.patch = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateApplicantRegistrationSettings.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::updateApplicantRegistrationSettings
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:439
 * @route '/college/{college}/admission-form-setup/applicant-registration-settings'
 */
    const updateApplicantRegistrationSettingsForm = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateApplicantRegistrationSettings.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::updateApplicantRegistrationSettings
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:439
 * @route '/college/{college}/admission-form-setup/applicant-registration-settings'
 */
        updateApplicantRegistrationSettingsForm.patch = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateApplicantRegistrationSettings.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateApplicantRegistrationSettings.form = updateApplicantRegistrationSettingsForm
/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::storeTemplate
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:111
 * @route '/college/{college}/admission-form-setup/templates'
 */
export const storeTemplate = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeTemplate.url(args, options),
    method: 'post',
})

storeTemplate.definition = {
    methods: ["post"],
    url: '/college/{college}/admission-form-setup/templates',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::storeTemplate
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:111
 * @route '/college/{college}/admission-form-setup/templates'
 */
storeTemplate.url = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { college: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { college: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                }

    return storeTemplate.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::storeTemplate
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:111
 * @route '/college/{college}/admission-form-setup/templates'
 */
storeTemplate.post = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeTemplate.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::storeTemplate
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:111
 * @route '/college/{college}/admission-form-setup/templates'
 */
    const storeTemplateForm = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeTemplate.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::storeTemplate
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:111
 * @route '/college/{college}/admission-form-setup/templates'
 */
        storeTemplateForm.post = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeTemplate.url(args, options),
            method: 'post',
        })
    
    storeTemplate.form = storeTemplateForm
/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::updateTemplate
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:231
 * @route '/college/{college}/admission-form-setup/templates/{template}'
 */
export const updateTemplate = (args: { college: number | { id: number }, template: number | { id: number } } | [college: number | { id: number }, template: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateTemplate.url(args, options),
    method: 'patch',
})

updateTemplate.definition = {
    methods: ["patch"],
    url: '/college/{college}/admission-form-setup/templates/{template}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::updateTemplate
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:231
 * @route '/college/{college}/admission-form-setup/templates/{template}'
 */
updateTemplate.url = (args: { college: number | { id: number }, template: number | { id: number } } | [college: number | { id: number }, template: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    template: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                }

    return updateTemplate.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{template}', parsedArgs.template.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::updateTemplate
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:231
 * @route '/college/{college}/admission-form-setup/templates/{template}'
 */
updateTemplate.patch = (args: { college: number | { id: number }, template: number | { id: number } } | [college: number | { id: number }, template: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateTemplate.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::updateTemplate
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:231
 * @route '/college/{college}/admission-form-setup/templates/{template}'
 */
    const updateTemplateForm = (args: { college: number | { id: number }, template: number | { id: number } } | [college: number | { id: number }, template: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateTemplate.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::updateTemplate
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:231
 * @route '/college/{college}/admission-form-setup/templates/{template}'
 */
        updateTemplateForm.patch = (args: { college: number | { id: number }, template: number | { id: number } } | [college: number | { id: number }, template: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateTemplate.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateTemplate.form = updateTemplateForm
/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::destroyTemplate
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:246
 * @route '/college/{college}/admission-form-setup/templates/{template}'
 */
export const destroyTemplate = (args: { college: number | { id: number }, template: number | { id: number } } | [college: number | { id: number }, template: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyTemplate.url(args, options),
    method: 'delete',
})

destroyTemplate.definition = {
    methods: ["delete"],
    url: '/college/{college}/admission-form-setup/templates/{template}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::destroyTemplate
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:246
 * @route '/college/{college}/admission-form-setup/templates/{template}'
 */
destroyTemplate.url = (args: { college: number | { id: number }, template: number | { id: number } } | [college: number | { id: number }, template: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    template: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                }

    return destroyTemplate.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{template}', parsedArgs.template.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::destroyTemplate
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:246
 * @route '/college/{college}/admission-form-setup/templates/{template}'
 */
destroyTemplate.delete = (args: { college: number | { id: number }, template: number | { id: number } } | [college: number | { id: number }, template: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyTemplate.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::destroyTemplate
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:246
 * @route '/college/{college}/admission-form-setup/templates/{template}'
 */
    const destroyTemplateForm = (args: { college: number | { id: number }, template: number | { id: number } } | [college: number | { id: number }, template: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyTemplate.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::destroyTemplate
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:246
 * @route '/college/{college}/admission-form-setup/templates/{template}'
 */
        destroyTemplateForm.delete = (args: { college: number | { id: number }, template: number | { id: number } } | [college: number | { id: number }, template: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyTemplate.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyTemplate.form = destroyTemplateForm
/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::statusTemplate
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:159
 * @route '/college/{college}/admission-form-setup/templates/{template}/status'
 */
export const statusTemplate = (args: { college: number | { id: number }, template: number | { id: number } } | [college: number | { id: number }, template: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: statusTemplate.url(args, options),
    method: 'patch',
})

statusTemplate.definition = {
    methods: ["patch"],
    url: '/college/{college}/admission-form-setup/templates/{template}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::statusTemplate
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:159
 * @route '/college/{college}/admission-form-setup/templates/{template}/status'
 */
statusTemplate.url = (args: { college: number | { id: number }, template: number | { id: number } } | [college: number | { id: number }, template: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    template: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                }

    return statusTemplate.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{template}', parsedArgs.template.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::statusTemplate
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:159
 * @route '/college/{college}/admission-form-setup/templates/{template}/status'
 */
statusTemplate.patch = (args: { college: number | { id: number }, template: number | { id: number } } | [college: number | { id: number }, template: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: statusTemplate.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::statusTemplate
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:159
 * @route '/college/{college}/admission-form-setup/templates/{template}/status'
 */
    const statusTemplateForm = (args: { college: number | { id: number }, template: number | { id: number } } | [college: number | { id: number }, template: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: statusTemplate.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::statusTemplate
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:159
 * @route '/college/{college}/admission-form-setup/templates/{template}/status'
 */
        statusTemplateForm.patch = (args: { college: number | { id: number }, template: number | { id: number } } | [college: number | { id: number }, template: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: statusTemplate.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    statusTemplate.form = statusTemplateForm
/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::storeStep
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:173
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps'
 */
export const storeStep = (args: { college: number | { id: number }, template: number | { id: number } } | [college: number | { id: number }, template: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeStep.url(args, options),
    method: 'post',
})

storeStep.definition = {
    methods: ["post"],
    url: '/college/{college}/admission-form-setup/templates/{template}/steps',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::storeStep
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:173
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps'
 */
storeStep.url = (args: { college: number | { id: number }, template: number | { id: number } } | [college: number | { id: number }, template: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    template: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                }

    return storeStep.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{template}', parsedArgs.template.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::storeStep
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:173
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps'
 */
storeStep.post = (args: { college: number | { id: number }, template: number | { id: number } } | [college: number | { id: number }, template: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeStep.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::storeStep
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:173
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps'
 */
    const storeStepForm = (args: { college: number | { id: number }, template: number | { id: number } } | [college: number | { id: number }, template: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeStep.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::storeStep
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:173
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps'
 */
        storeStepForm.post = (args: { college: number | { id: number }, template: number | { id: number } } | [college: number | { id: number }, template: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeStep.url(args, options),
            method: 'post',
        })
    
    storeStep.form = storeStepForm
/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::updateStep
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:254
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}'
 */
export const updateStep = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStep.url(args, options),
    method: 'patch',
})

updateStep.definition = {
    methods: ["patch"],
    url: '/college/{college}/admission-form-setup/templates/{template}/steps/{step}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::updateStep
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:254
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}'
 */
updateStep.url = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    template: args[1],
                    step: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                                step: typeof args.step === 'object'
                ? args.step.id
                : args.step,
                }

    return updateStep.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{template}', parsedArgs.template.toString())
            .replace('{step}', parsedArgs.step.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::updateStep
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:254
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}'
 */
updateStep.patch = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStep.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::updateStep
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:254
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}'
 */
    const updateStepForm = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateStep.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::updateStep
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:254
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}'
 */
        updateStepForm.patch = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateStep.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateStep.form = updateStepForm
/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::destroyStep
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:262
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}'
 */
export const destroyStep = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyStep.url(args, options),
    method: 'delete',
})

destroyStep.definition = {
    methods: ["delete"],
    url: '/college/{college}/admission-form-setup/templates/{template}/steps/{step}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::destroyStep
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:262
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}'
 */
destroyStep.url = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    template: args[1],
                    step: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                                step: typeof args.step === 'object'
                ? args.step.id
                : args.step,
                }

    return destroyStep.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{template}', parsedArgs.template.toString())
            .replace('{step}', parsedArgs.step.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::destroyStep
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:262
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}'
 */
destroyStep.delete = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyStep.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::destroyStep
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:262
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}'
 */
    const destroyStepForm = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyStep.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::destroyStep
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:262
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}'
 */
        destroyStepForm.delete = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyStep.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyStep.form = destroyStepForm
/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::storePanel
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:269
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/panels'
 */
export const storePanel = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storePanel.url(args, options),
    method: 'post',
})

storePanel.definition = {
    methods: ["post"],
    url: '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/panels',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::storePanel
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:269
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/panels'
 */
storePanel.url = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    template: args[1],
                    step: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                                step: typeof args.step === 'object'
                ? args.step.id
                : args.step,
                }

    return storePanel.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{template}', parsedArgs.template.toString())
            .replace('{step}', parsedArgs.step.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::storePanel
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:269
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/panels'
 */
storePanel.post = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storePanel.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::storePanel
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:269
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/panels'
 */
    const storePanelForm = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storePanel.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::storePanel
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:269
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/panels'
 */
        storePanelForm.post = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storePanel.url(args, options),
            method: 'post',
        })
    
    storePanel.form = storePanelForm
/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::updatePanel
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:276
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/panels/{panel}'
 */
export const updatePanel = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updatePanel.url(args, options),
    method: 'patch',
})

updatePanel.definition = {
    methods: ["patch"],
    url: '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/panels/{panel}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::updatePanel
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:276
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/panels/{panel}'
 */
updatePanel.url = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    template: args[1],
                    step: args[2],
                    panel: args[3],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                                step: typeof args.step === 'object'
                ? args.step.id
                : args.step,
                                panel: typeof args.panel === 'object'
                ? args.panel.id
                : args.panel,
                }

    return updatePanel.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{template}', parsedArgs.template.toString())
            .replace('{step}', parsedArgs.step.toString())
            .replace('{panel}', parsedArgs.panel.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::updatePanel
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:276
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/panels/{panel}'
 */
updatePanel.patch = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updatePanel.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::updatePanel
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:276
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/panels/{panel}'
 */
    const updatePanelForm = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updatePanel.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::updatePanel
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:276
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/panels/{panel}'
 */
        updatePanelForm.patch = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updatePanel.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updatePanel.form = updatePanelForm
/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::destroyPanel
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:282
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/panels/{panel}'
 */
export const destroyPanel = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyPanel.url(args, options),
    method: 'delete',
})

destroyPanel.definition = {
    methods: ["delete"],
    url: '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/panels/{panel}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::destroyPanel
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:282
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/panels/{panel}'
 */
destroyPanel.url = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    template: args[1],
                    step: args[2],
                    panel: args[3],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                                step: typeof args.step === 'object'
                ? args.step.id
                : args.step,
                                panel: typeof args.panel === 'object'
                ? args.panel.id
                : args.panel,
                }

    return destroyPanel.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{template}', parsedArgs.template.toString())
            .replace('{step}', parsedArgs.step.toString())
            .replace('{panel}', parsedArgs.panel.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::destroyPanel
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:282
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/panels/{panel}'
 */
destroyPanel.delete = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyPanel.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::destroyPanel
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:282
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/panels/{panel}'
 */
    const destroyPanelForm = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyPanel.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::destroyPanel
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:282
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/panels/{panel}'
 */
        destroyPanelForm.delete = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyPanel.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyPanel.form = destroyPanelForm
/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::storeField
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:183
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/fields'
 */
export const storeField = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeField.url(args, options),
    method: 'post',
})

storeField.definition = {
    methods: ["post"],
    url: '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/fields',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::storeField
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:183
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/fields'
 */
storeField.url = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    template: args[1],
                    step: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                                step: typeof args.step === 'object'
                ? args.step.id
                : args.step,
                }

    return storeField.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{template}', parsedArgs.template.toString())
            .replace('{step}', parsedArgs.step.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::storeField
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:183
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/fields'
 */
storeField.post = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeField.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::storeField
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:183
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/fields'
 */
    const storeFieldForm = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeField.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::storeField
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:183
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/fields'
 */
        storeFieldForm.post = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeField.url(args, options),
            method: 'post',
        })
    
    storeField.form = storeFieldForm
/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::updateField
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:287
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/fields/{field}'
 */
export const updateField = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, field: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, field: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateField.url(args, options),
    method: 'patch',
})

updateField.definition = {
    methods: ["patch"],
    url: '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/fields/{field}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::updateField
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:287
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/fields/{field}'
 */
updateField.url = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, field: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, field: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    template: args[1],
                    step: args[2],
                    field: args[3],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                                step: typeof args.step === 'object'
                ? args.step.id
                : args.step,
                                field: typeof args.field === 'object'
                ? args.field.id
                : args.field,
                }

    return updateField.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{template}', parsedArgs.template.toString())
            .replace('{step}', parsedArgs.step.toString())
            .replace('{field}', parsedArgs.field.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::updateField
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:287
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/fields/{field}'
 */
updateField.patch = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, field: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, field: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateField.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::updateField
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:287
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/fields/{field}'
 */
    const updateFieldForm = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, field: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, field: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateField.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::updateField
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:287
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/fields/{field}'
 */
        updateFieldForm.patch = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, field: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, field: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateField.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateField.form = updateFieldForm
/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::destroyField
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:295
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/fields/{field}'
 */
export const destroyField = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, field: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, field: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyField.url(args, options),
    method: 'delete',
})

destroyField.definition = {
    methods: ["delete"],
    url: '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/fields/{field}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::destroyField
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:295
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/fields/{field}'
 */
destroyField.url = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, field: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, field: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    template: args[1],
                    step: args[2],
                    field: args[3],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                                step: typeof args.step === 'object'
                ? args.step.id
                : args.step,
                                field: typeof args.field === 'object'
                ? args.field.id
                : args.field,
                }

    return destroyField.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{template}', parsedArgs.template.toString())
            .replace('{step}', parsedArgs.step.toString())
            .replace('{field}', parsedArgs.field.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::destroyField
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:295
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/fields/{field}'
 */
destroyField.delete = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, field: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, field: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyField.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::destroyField
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:295
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/fields/{field}'
 */
    const destroyFieldForm = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, field: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, field: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyField.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::destroyField
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:295
 * @route '/college/{college}/admission-form-setup/templates/{template}/steps/{step}/fields/{field}'
 */
        destroyFieldForm.delete = (args: { college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, field: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, step: number | { id: number }, field: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyField.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyField.form = destroyFieldForm
/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::mapTemplate
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:301
 * @route '/college/{college}/admission-form-setup/templates/{template}/mappings'
 */
export const mapTemplate = (args: { college: number | { id: number }, template: number | { id: number } } | [college: number | { id: number }, template: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: mapTemplate.url(args, options),
    method: 'post',
})

mapTemplate.definition = {
    methods: ["post"],
    url: '/college/{college}/admission-form-setup/templates/{template}/mappings',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::mapTemplate
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:301
 * @route '/college/{college}/admission-form-setup/templates/{template}/mappings'
 */
mapTemplate.url = (args: { college: number | { id: number }, template: number | { id: number } } | [college: number | { id: number }, template: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    template: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                }

    return mapTemplate.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{template}', parsedArgs.template.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::mapTemplate
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:301
 * @route '/college/{college}/admission-form-setup/templates/{template}/mappings'
 */
mapTemplate.post = (args: { college: number | { id: number }, template: number | { id: number } } | [college: number | { id: number }, template: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: mapTemplate.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::mapTemplate
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:301
 * @route '/college/{college}/admission-form-setup/templates/{template}/mappings'
 */
    const mapTemplateForm = (args: { college: number | { id: number }, template: number | { id: number } } | [college: number | { id: number }, template: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: mapTemplate.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::mapTemplate
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:301
 * @route '/college/{college}/admission-form-setup/templates/{template}/mappings'
 */
        mapTemplateForm.post = (args: { college: number | { id: number }, template: number | { id: number } } | [college: number | { id: number }, template: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: mapTemplate.url(args, options),
            method: 'post',
        })
    
    mapTemplate.form = mapTemplateForm
/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::destroyMapping
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:365
 * @route '/college/{college}/admission-form-setup/templates/{template}/mappings/{mapping}'
 */
export const destroyMapping = (args: { college: number | { id: number }, template: number | { id: number }, mapping: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyMapping.url(args, options),
    method: 'delete',
})

destroyMapping.definition = {
    methods: ["delete"],
    url: '/college/{college}/admission-form-setup/templates/{template}/mappings/{mapping}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::destroyMapping
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:365
 * @route '/college/{college}/admission-form-setup/templates/{template}/mappings/{mapping}'
 */
destroyMapping.url = (args: { college: number | { id: number }, template: number | { id: number }, mapping: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    template: args[1],
                    mapping: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                                mapping: typeof args.mapping === 'object'
                ? args.mapping.id
                : args.mapping,
                }

    return destroyMapping.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{template}', parsedArgs.template.toString())
            .replace('{mapping}', parsedArgs.mapping.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::destroyMapping
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:365
 * @route '/college/{college}/admission-form-setup/templates/{template}/mappings/{mapping}'
 */
destroyMapping.delete = (args: { college: number | { id: number }, template: number | { id: number }, mapping: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyMapping.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::destroyMapping
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:365
 * @route '/college/{college}/admission-form-setup/templates/{template}/mappings/{mapping}'
 */
    const destroyMappingForm = (args: { college: number | { id: number }, template: number | { id: number }, mapping: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyMapping.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::destroyMapping
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:365
 * @route '/college/{college}/admission-form-setup/templates/{template}/mappings/{mapping}'
 */
        destroyMappingForm.delete = (args: { college: number | { id: number }, template: number | { id: number }, mapping: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyMapping.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyMapping.form = destroyMappingForm
/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::publicAccess
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:385
 * @route '/college/{college}/admission-form-setup/templates/{template}/mappings/{mapping}/public-access'
 */
export const publicAccess = (args: { college: number | { id: number }, template: number | { id: number }, mapping: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: publicAccess.url(args, options),
    method: 'patch',
})

publicAccess.definition = {
    methods: ["patch"],
    url: '/college/{college}/admission-form-setup/templates/{template}/mappings/{mapping}/public-access',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::publicAccess
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:385
 * @route '/college/{college}/admission-form-setup/templates/{template}/mappings/{mapping}/public-access'
 */
publicAccess.url = (args: { college: number | { id: number }, template: number | { id: number }, mapping: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    template: args[1],
                    mapping: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                                mapping: typeof args.mapping === 'object'
                ? args.mapping.id
                : args.mapping,
                }

    return publicAccess.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{template}', parsedArgs.template.toString())
            .replace('{mapping}', parsedArgs.mapping.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::publicAccess
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:385
 * @route '/college/{college}/admission-form-setup/templates/{template}/mappings/{mapping}/public-access'
 */
publicAccess.patch = (args: { college: number | { id: number }, template: number | { id: number }, mapping: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: publicAccess.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::publicAccess
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:385
 * @route '/college/{college}/admission-form-setup/templates/{template}/mappings/{mapping}/public-access'
 */
    const publicAccessForm = (args: { college: number | { id: number }, template: number | { id: number }, mapping: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: publicAccess.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::publicAccess
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:385
 * @route '/college/{college}/admission-form-setup/templates/{template}/mappings/{mapping}/public-access'
 */
        publicAccessForm.patch = (args: { college: number | { id: number }, template: number | { id: number }, mapping: number | { id: number } } | [college: number | { id: number }, template: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: publicAccess.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    publicAccess.form = publicAccessForm
/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::storeFeeRule
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:456
 * @route '/college/{college}/admission-form-setup/fee-rules'
 */
export const storeFeeRule = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeFeeRule.url(args, options),
    method: 'post',
})

storeFeeRule.definition = {
    methods: ["post"],
    url: '/college/{college}/admission-form-setup/fee-rules',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::storeFeeRule
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:456
 * @route '/college/{college}/admission-form-setup/fee-rules'
 */
storeFeeRule.url = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { college: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { college: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                }

    return storeFeeRule.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::storeFeeRule
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:456
 * @route '/college/{college}/admission-form-setup/fee-rules'
 */
storeFeeRule.post = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeFeeRule.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::storeFeeRule
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:456
 * @route '/college/{college}/admission-form-setup/fee-rules'
 */
    const storeFeeRuleForm = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeFeeRule.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionFormSetupController::storeFeeRule
 * @see app/Http/Controllers/CollegeAdmissionFormSetupController.php:456
 * @route '/college/{college}/admission-form-setup/fee-rules'
 */
        storeFeeRuleForm.post = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeFeeRule.url(args, options),
            method: 'post',
        })
    
    storeFeeRule.form = storeFeeRuleForm
const CollegeAdmissionFormSetupController = { index, updateApplicantRegistrationSettings, storeTemplate, updateTemplate, destroyTemplate, statusTemplate, storeStep, updateStep, destroyStep, storePanel, updatePanel, destroyPanel, storeField, updateField, destroyField, mapTemplate, destroyMapping, publicAccess, storeFeeRule }

export default CollegeAdmissionFormSetupController