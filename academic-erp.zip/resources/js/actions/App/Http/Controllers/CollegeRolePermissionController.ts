import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CollegeRolePermissionController::edit
 * @see app/Http/Controllers/CollegeRolePermissionController.php:16
 * @route '/college/{college}/roles/{role}/permissions'
 */
export const edit = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/college/{college}/roles/{role}/permissions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CollegeRolePermissionController::edit
 * @see app/Http/Controllers/CollegeRolePermissionController.php:16
 * @route '/college/{college}/roles/{role}/permissions'
 */
edit.url = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    role: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                role: typeof args.role === 'object'
                ? args.role.id
                : args.role,
                }

    return edit.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{role}', parsedArgs.role.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeRolePermissionController::edit
 * @see app/Http/Controllers/CollegeRolePermissionController.php:16
 * @route '/college/{college}/roles/{role}/permissions'
 */
edit.get = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CollegeRolePermissionController::edit
 * @see app/Http/Controllers/CollegeRolePermissionController.php:16
 * @route '/college/{college}/roles/{role}/permissions'
 */
edit.head = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CollegeRolePermissionController::edit
 * @see app/Http/Controllers/CollegeRolePermissionController.php:16
 * @route '/college/{college}/roles/{role}/permissions'
 */
    const editForm = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CollegeRolePermissionController::edit
 * @see app/Http/Controllers/CollegeRolePermissionController.php:16
 * @route '/college/{college}/roles/{role}/permissions'
 */
        editForm.get = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CollegeRolePermissionController::edit
 * @see app/Http/Controllers/CollegeRolePermissionController.php:16
 * @route '/college/{college}/roles/{role}/permissions'
 */
        editForm.head = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\CollegeRolePermissionController::update
 * @see app/Http/Controllers/CollegeRolePermissionController.php:38
 * @route '/college/{college}/roles/{role}/permissions'
 */
export const update = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/college/{college}/roles/{role}/permissions',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CollegeRolePermissionController::update
 * @see app/Http/Controllers/CollegeRolePermissionController.php:38
 * @route '/college/{college}/roles/{role}/permissions'
 */
update.url = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    role: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                role: typeof args.role === 'object'
                ? args.role.id
                : args.role,
                }

    return update.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{role}', parsedArgs.role.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeRolePermissionController::update
 * @see app/Http/Controllers/CollegeRolePermissionController.php:38
 * @route '/college/{college}/roles/{role}/permissions'
 */
update.put = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\CollegeRolePermissionController::update
 * @see app/Http/Controllers/CollegeRolePermissionController.php:38
 * @route '/college/{college}/roles/{role}/permissions'
 */
    const updateForm = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeRolePermissionController::update
 * @see app/Http/Controllers/CollegeRolePermissionController.php:38
 * @route '/college/{college}/roles/{role}/permissions'
 */
        updateForm.put = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const CollegeRolePermissionController = { edit, update }

export default CollegeRolePermissionController