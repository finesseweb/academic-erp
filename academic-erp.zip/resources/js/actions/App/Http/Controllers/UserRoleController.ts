import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\UserRoleController::edit
 * @see app/Http/Controllers/UserRoleController.php:19
 * @route '/admin/users/{user}/roles'
 */
export const edit = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/users/{user}/roles',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UserRoleController::edit
 * @see app/Http/Controllers/UserRoleController.php:19
 * @route '/admin/users/{user}/roles'
 */
edit.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return edit.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserRoleController::edit
 * @see app/Http/Controllers/UserRoleController.php:19
 * @route '/admin/users/{user}/roles'
 */
edit.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\UserRoleController::edit
 * @see app/Http/Controllers/UserRoleController.php:19
 * @route '/admin/users/{user}/roles'
 */
edit.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\UserRoleController::edit
 * @see app/Http/Controllers/UserRoleController.php:19
 * @route '/admin/users/{user}/roles'
 */
    const editForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\UserRoleController::edit
 * @see app/Http/Controllers/UserRoleController.php:19
 * @route '/admin/users/{user}/roles'
 */
        editForm.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\UserRoleController::edit
 * @see app/Http/Controllers/UserRoleController.php:19
 * @route '/admin/users/{user}/roles'
 */
        editForm.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\UserRoleController::store
 * @see app/Http/Controllers/UserRoleController.php:28
 * @route '/admin/users/{user}/roles'
 */
export const store = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: store.url(args, options),
    method: 'put',
})

store.definition = {
    methods: ["put"],
    url: '/admin/users/{user}/roles',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\UserRoleController::store
 * @see app/Http/Controllers/UserRoleController.php:28
 * @route '/admin/users/{user}/roles'
 */
store.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return store.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserRoleController::store
 * @see app/Http/Controllers/UserRoleController.php:28
 * @route '/admin/users/{user}/roles'
 */
store.put = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: store.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\UserRoleController::store
 * @see app/Http/Controllers/UserRoleController.php:28
 * @route '/admin/users/{user}/roles'
 */
    const storeForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UserRoleController::store
 * @see app/Http/Controllers/UserRoleController.php:28
 * @route '/admin/users/{user}/roles'
 */
        storeForm.put = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\UserRoleController::updateScope
 * @see app/Http/Controllers/UserRoleController.php:61
 * @route '/admin/users/{user}/roles/{assignment}/scope'
 */
export const updateScope = (args: { user: number | { id: number }, assignment: number | { id: number } } | [user: number | { id: number }, assignment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateScope.url(args, options),
    method: 'patch',
})

updateScope.definition = {
    methods: ["patch"],
    url: '/admin/users/{user}/roles/{assignment}/scope',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\UserRoleController::updateScope
 * @see app/Http/Controllers/UserRoleController.php:61
 * @route '/admin/users/{user}/roles/{assignment}/scope'
 */
updateScope.url = (args: { user: number | { id: number }, assignment: number | { id: number } } | [user: number | { id: number }, assignment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                    assignment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                                assignment: typeof args.assignment === 'object'
                ? args.assignment.id
                : args.assignment,
                }

    return updateScope.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace('{assignment}', parsedArgs.assignment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserRoleController::updateScope
 * @see app/Http/Controllers/UserRoleController.php:61
 * @route '/admin/users/{user}/roles/{assignment}/scope'
 */
updateScope.patch = (args: { user: number | { id: number }, assignment: number | { id: number } } | [user: number | { id: number }, assignment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateScope.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\UserRoleController::updateScope
 * @see app/Http/Controllers/UserRoleController.php:61
 * @route '/admin/users/{user}/roles/{assignment}/scope'
 */
    const updateScopeForm = (args: { user: number | { id: number }, assignment: number | { id: number } } | [user: number | { id: number }, assignment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateScope.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UserRoleController::updateScope
 * @see app/Http/Controllers/UserRoleController.php:61
 * @route '/admin/users/{user}/roles/{assignment}/scope'
 */
        updateScopeForm.patch = (args: { user: number | { id: number }, assignment: number | { id: number } } | [user: number | { id: number }, assignment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateScope.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateScope.form = updateScopeForm
/**
* @see \App\Http\Controllers\UserRoleController::destroy
 * @see app/Http/Controllers/UserRoleController.php:50
 * @route '/admin/users/{user}/roles/{assignment}'
 */
export const destroy = (args: { user: number | { id: number }, assignment: number | { id: number } } | [user: number | { id: number }, assignment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/users/{user}/roles/{assignment}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\UserRoleController::destroy
 * @see app/Http/Controllers/UserRoleController.php:50
 * @route '/admin/users/{user}/roles/{assignment}'
 */
destroy.url = (args: { user: number | { id: number }, assignment: number | { id: number } } | [user: number | { id: number }, assignment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                    assignment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                                assignment: typeof args.assignment === 'object'
                ? args.assignment.id
                : args.assignment,
                }

    return destroy.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace('{assignment}', parsedArgs.assignment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UserRoleController::destroy
 * @see app/Http/Controllers/UserRoleController.php:50
 * @route '/admin/users/{user}/roles/{assignment}'
 */
destroy.delete = (args: { user: number | { id: number }, assignment: number | { id: number } } | [user: number | { id: number }, assignment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\UserRoleController::destroy
 * @see app/Http/Controllers/UserRoleController.php:50
 * @route '/admin/users/{user}/roles/{assignment}'
 */
    const destroyForm = (args: { user: number | { id: number }, assignment: number | { id: number } } | [user: number | { id: number }, assignment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UserRoleController::destroy
 * @see app/Http/Controllers/UserRoleController.php:50
 * @route '/admin/users/{user}/roles/{assignment}'
 */
        destroyForm.delete = (args: { user: number | { id: number }, assignment: number | { id: number } } | [user: number | { id: number }, assignment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const UserRoleController = { edit, store, updateScope, destroy }

export default UserRoleController