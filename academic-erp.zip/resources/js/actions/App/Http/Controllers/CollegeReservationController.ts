import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CollegeReservationController::index
 * @see app/Http/Controllers/CollegeReservationController.php:23
 * @route '/college/{college}/reservations'
 */
export const index = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/college/{college}/reservations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CollegeReservationController::index
 * @see app/Http/Controllers/CollegeReservationController.php:23
 * @route '/college/{college}/reservations'
 */
index.url = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { college: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { college: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                }

    return index.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeReservationController::index
 * @see app/Http/Controllers/CollegeReservationController.php:23
 * @route '/college/{college}/reservations'
 */
index.get = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CollegeReservationController::index
 * @see app/Http/Controllers/CollegeReservationController.php:23
 * @route '/college/{college}/reservations'
 */
index.head = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CollegeReservationController::index
 * @see app/Http/Controllers/CollegeReservationController.php:23
 * @route '/college/{college}/reservations'
 */
    const indexForm = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CollegeReservationController::index
 * @see app/Http/Controllers/CollegeReservationController.php:23
 * @route '/college/{college}/reservations'
 */
        indexForm.get = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CollegeReservationController::index
 * @see app/Http/Controllers/CollegeReservationController.php:23
 * @route '/college/{college}/reservations'
 */
        indexForm.head = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CollegeReservationController::store
 * @see app/Http/Controllers/CollegeReservationController.php:103
 * @route '/college/{college}/reservations'
 */
export const store = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/college/{college}/reservations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CollegeReservationController::store
 * @see app/Http/Controllers/CollegeReservationController.php:103
 * @route '/college/{college}/reservations'
 */
store.url = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { college: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { college: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                }

    return store.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeReservationController::store
 * @see app/Http/Controllers/CollegeReservationController.php:103
 * @route '/college/{college}/reservations'
 */
store.post = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CollegeReservationController::store
 * @see app/Http/Controllers/CollegeReservationController.php:103
 * @route '/college/{college}/reservations'
 */
    const storeForm = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeReservationController::store
 * @see app/Http/Controllers/CollegeReservationController.php:103
 * @route '/college/{college}/reservations'
 */
        storeForm.post = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CollegeReservationController::update
 * @see app/Http/Controllers/CollegeReservationController.php:121
 * @route '/college/{college}/reservations/{plan}'
 */
export const update = (args: { college: number | { id: number }, plan: number | { id: number } } | [college: number | { id: number }, plan: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/college/{college}/reservations/{plan}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeReservationController::update
 * @see app/Http/Controllers/CollegeReservationController.php:121
 * @route '/college/{college}/reservations/{plan}'
 */
update.url = (args: { college: number | { id: number }, plan: number | { id: number } } | [college: number | { id: number }, plan: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    plan: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                plan: typeof args.plan === 'object'
                ? args.plan.id
                : args.plan,
                }

    return update.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{plan}', parsedArgs.plan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeReservationController::update
 * @see app/Http/Controllers/CollegeReservationController.php:121
 * @route '/college/{college}/reservations/{plan}'
 */
update.patch = (args: { college: number | { id: number }, plan: number | { id: number } } | [college: number | { id: number }, plan: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeReservationController::update
 * @see app/Http/Controllers/CollegeReservationController.php:121
 * @route '/college/{college}/reservations/{plan}'
 */
    const updateForm = (args: { college: number | { id: number }, plan: number | { id: number } } | [college: number | { id: number }, plan: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeReservationController::update
 * @see app/Http/Controllers/CollegeReservationController.php:121
 * @route '/college/{college}/reservations/{plan}'
 */
        updateForm.patch = (args: { college: number | { id: number }, plan: number | { id: number } } | [college: number | { id: number }, plan: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CollegeReservationController::status
 * @see app/Http/Controllers/CollegeReservationController.php:206
 * @route '/college/{college}/reservations/{plan}/status'
 */
export const status = (args: { college: number | { id: number }, plan: number | { id: number } } | [college: number | { id: number }, plan: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

status.definition = {
    methods: ["patch"],
    url: '/college/{college}/reservations/{plan}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeReservationController::status
 * @see app/Http/Controllers/CollegeReservationController.php:206
 * @route '/college/{college}/reservations/{plan}/status'
 */
status.url = (args: { college: number | { id: number }, plan: number | { id: number } } | [college: number | { id: number }, plan: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    plan: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                plan: typeof args.plan === 'object'
                ? args.plan.id
                : args.plan,
                }

    return status.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{plan}', parsedArgs.plan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeReservationController::status
 * @see app/Http/Controllers/CollegeReservationController.php:206
 * @route '/college/{college}/reservations/{plan}/status'
 */
status.patch = (args: { college: number | { id: number }, plan: number | { id: number } } | [college: number | { id: number }, plan: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeReservationController::status
 * @see app/Http/Controllers/CollegeReservationController.php:206
 * @route '/college/{college}/reservations/{plan}/status'
 */
    const statusForm = (args: { college: number | { id: number }, plan: number | { id: number } } | [college: number | { id: number }, plan: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: status.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeReservationController::status
 * @see app/Http/Controllers/CollegeReservationController.php:206
 * @route '/college/{college}/reservations/{plan}/status'
 */
        statusForm.patch = (args: { college: number | { id: number }, plan: number | { id: number } } | [college: number | { id: number }, plan: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: status.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    status.form = statusForm
/**
* @see \App\Http\Controllers\CollegeReservationController::storeAllocation
 * @see app/Http/Controllers/CollegeReservationController.php:141
 * @route '/college/{college}/reservations/{plan}/allocations'
 */
export const storeAllocation = (args: { college: number | { id: number }, plan: number | { id: number } } | [college: number | { id: number }, plan: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeAllocation.url(args, options),
    method: 'post',
})

storeAllocation.definition = {
    methods: ["post"],
    url: '/college/{college}/reservations/{plan}/allocations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CollegeReservationController::storeAllocation
 * @see app/Http/Controllers/CollegeReservationController.php:141
 * @route '/college/{college}/reservations/{plan}/allocations'
 */
storeAllocation.url = (args: { college: number | { id: number }, plan: number | { id: number } } | [college: number | { id: number }, plan: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    plan: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                plan: typeof args.plan === 'object'
                ? args.plan.id
                : args.plan,
                }

    return storeAllocation.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{plan}', parsedArgs.plan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeReservationController::storeAllocation
 * @see app/Http/Controllers/CollegeReservationController.php:141
 * @route '/college/{college}/reservations/{plan}/allocations'
 */
storeAllocation.post = (args: { college: number | { id: number }, plan: number | { id: number } } | [college: number | { id: number }, plan: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeAllocation.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CollegeReservationController::storeAllocation
 * @see app/Http/Controllers/CollegeReservationController.php:141
 * @route '/college/{college}/reservations/{plan}/allocations'
 */
    const storeAllocationForm = (args: { college: number | { id: number }, plan: number | { id: number } } | [college: number | { id: number }, plan: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeAllocation.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeReservationController::storeAllocation
 * @see app/Http/Controllers/CollegeReservationController.php:141
 * @route '/college/{college}/reservations/{plan}/allocations'
 */
        storeAllocationForm.post = (args: { college: number | { id: number }, plan: number | { id: number } } | [college: number | { id: number }, plan: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeAllocation.url(args, options),
            method: 'post',
        })
    
    storeAllocation.form = storeAllocationForm
/**
* @see \App\Http\Controllers\CollegeReservationController::updateAllocation
 * @see app/Http/Controllers/CollegeReservationController.php:161
 * @route '/college/{college}/reservations/{plan}/allocations/{allocation}'
 */
export const updateAllocation = (args: { college: number | { id: number }, plan: number | { id: number }, allocation: number | { id: number } } | [college: number | { id: number }, plan: number | { id: number }, allocation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateAllocation.url(args, options),
    method: 'patch',
})

updateAllocation.definition = {
    methods: ["patch"],
    url: '/college/{college}/reservations/{plan}/allocations/{allocation}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeReservationController::updateAllocation
 * @see app/Http/Controllers/CollegeReservationController.php:161
 * @route '/college/{college}/reservations/{plan}/allocations/{allocation}'
 */
updateAllocation.url = (args: { college: number | { id: number }, plan: number | { id: number }, allocation: number | { id: number } } | [college: number | { id: number }, plan: number | { id: number }, allocation: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    plan: args[1],
                    allocation: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                plan: typeof args.plan === 'object'
                ? args.plan.id
                : args.plan,
                                allocation: typeof args.allocation === 'object'
                ? args.allocation.id
                : args.allocation,
                }

    return updateAllocation.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{plan}', parsedArgs.plan.toString())
            .replace('{allocation}', parsedArgs.allocation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeReservationController::updateAllocation
 * @see app/Http/Controllers/CollegeReservationController.php:161
 * @route '/college/{college}/reservations/{plan}/allocations/{allocation}'
 */
updateAllocation.patch = (args: { college: number | { id: number }, plan: number | { id: number }, allocation: number | { id: number } } | [college: number | { id: number }, plan: number | { id: number }, allocation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateAllocation.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeReservationController::updateAllocation
 * @see app/Http/Controllers/CollegeReservationController.php:161
 * @route '/college/{college}/reservations/{plan}/allocations/{allocation}'
 */
    const updateAllocationForm = (args: { college: number | { id: number }, plan: number | { id: number }, allocation: number | { id: number } } | [college: number | { id: number }, plan: number | { id: number }, allocation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateAllocation.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeReservationController::updateAllocation
 * @see app/Http/Controllers/CollegeReservationController.php:161
 * @route '/college/{college}/reservations/{plan}/allocations/{allocation}'
 */
        updateAllocationForm.patch = (args: { college: number | { id: number }, plan: number | { id: number }, allocation: number | { id: number } } | [college: number | { id: number }, plan: number | { id: number }, allocation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateAllocation.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateAllocation.form = updateAllocationForm
/**
* @see \App\Http\Controllers\CollegeReservationController::destroyAllocation
 * @see app/Http/Controllers/CollegeReservationController.php:183
 * @route '/college/{college}/reservations/{plan}/allocations/{allocation}'
 */
export const destroyAllocation = (args: { college: number | { id: number }, plan: number | { id: number }, allocation: number | { id: number } } | [college: number | { id: number }, plan: number | { id: number }, allocation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyAllocation.url(args, options),
    method: 'delete',
})

destroyAllocation.definition = {
    methods: ["delete"],
    url: '/college/{college}/reservations/{plan}/allocations/{allocation}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CollegeReservationController::destroyAllocation
 * @see app/Http/Controllers/CollegeReservationController.php:183
 * @route '/college/{college}/reservations/{plan}/allocations/{allocation}'
 */
destroyAllocation.url = (args: { college: number | { id: number }, plan: number | { id: number }, allocation: number | { id: number } } | [college: number | { id: number }, plan: number | { id: number }, allocation: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    plan: args[1],
                    allocation: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                plan: typeof args.plan === 'object'
                ? args.plan.id
                : args.plan,
                                allocation: typeof args.allocation === 'object'
                ? args.allocation.id
                : args.allocation,
                }

    return destroyAllocation.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{plan}', parsedArgs.plan.toString())
            .replace('{allocation}', parsedArgs.allocation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeReservationController::destroyAllocation
 * @see app/Http/Controllers/CollegeReservationController.php:183
 * @route '/college/{college}/reservations/{plan}/allocations/{allocation}'
 */
destroyAllocation.delete = (args: { college: number | { id: number }, plan: number | { id: number }, allocation: number | { id: number } } | [college: number | { id: number }, plan: number | { id: number }, allocation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyAllocation.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CollegeReservationController::destroyAllocation
 * @see app/Http/Controllers/CollegeReservationController.php:183
 * @route '/college/{college}/reservations/{plan}/allocations/{allocation}'
 */
    const destroyAllocationForm = (args: { college: number | { id: number }, plan: number | { id: number }, allocation: number | { id: number } } | [college: number | { id: number }, plan: number | { id: number }, allocation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyAllocation.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeReservationController::destroyAllocation
 * @see app/Http/Controllers/CollegeReservationController.php:183
 * @route '/college/{college}/reservations/{plan}/allocations/{allocation}'
 */
        destroyAllocationForm.delete = (args: { college: number | { id: number }, plan: number | { id: number }, allocation: number | { id: number } } | [college: number | { id: number }, plan: number | { id: number }, allocation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyAllocation.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyAllocation.form = destroyAllocationForm
const CollegeReservationController = { index, store, update, status, storeAllocation, updateAllocation, destroyAllocation }

export default CollegeReservationController