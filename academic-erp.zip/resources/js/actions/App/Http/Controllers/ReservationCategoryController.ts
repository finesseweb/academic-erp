import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ReservationCategoryController::index
 * @see app/Http/Controllers/ReservationCategoryController.php:17
 * @route '/admin/reservation-categories'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/reservation-categories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReservationCategoryController::index
 * @see app/Http/Controllers/ReservationCategoryController.php:17
 * @route '/admin/reservation-categories'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReservationCategoryController::index
 * @see app/Http/Controllers/ReservationCategoryController.php:17
 * @route '/admin/reservation-categories'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReservationCategoryController::index
 * @see app/Http/Controllers/ReservationCategoryController.php:17
 * @route '/admin/reservation-categories'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReservationCategoryController::index
 * @see app/Http/Controllers/ReservationCategoryController.php:17
 * @route '/admin/reservation-categories'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReservationCategoryController::index
 * @see app/Http/Controllers/ReservationCategoryController.php:17
 * @route '/admin/reservation-categories'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReservationCategoryController::index
 * @see app/Http/Controllers/ReservationCategoryController.php:17
 * @route '/admin/reservation-categories'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ReservationCategoryController::store
 * @see app/Http/Controllers/ReservationCategoryController.php:37
 * @route '/admin/reservation-categories'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/reservation-categories',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ReservationCategoryController::store
 * @see app/Http/Controllers/ReservationCategoryController.php:37
 * @route '/admin/reservation-categories'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReservationCategoryController::store
 * @see app/Http/Controllers/ReservationCategoryController.php:37
 * @route '/admin/reservation-categories'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ReservationCategoryController::store
 * @see app/Http/Controllers/ReservationCategoryController.php:37
 * @route '/admin/reservation-categories'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ReservationCategoryController::store
 * @see app/Http/Controllers/ReservationCategoryController.php:37
 * @route '/admin/reservation-categories'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ReservationCategoryController::update
 * @see app/Http/Controllers/ReservationCategoryController.php:56
 * @route '/admin/reservation-categories/{reservationCategory}'
 */
export const update = (args: { reservationCategory: number | { id: number } } | [reservationCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/reservation-categories/{reservationCategory}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\ReservationCategoryController::update
 * @see app/Http/Controllers/ReservationCategoryController.php:56
 * @route '/admin/reservation-categories/{reservationCategory}'
 */
update.url = (args: { reservationCategory: number | { id: number } } | [reservationCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { reservationCategory: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { reservationCategory: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    reservationCategory: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        reservationCategory: typeof args.reservationCategory === 'object'
                ? args.reservationCategory.id
                : args.reservationCategory,
                }

    return update.definition.url
            .replace('{reservationCategory}', parsedArgs.reservationCategory.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReservationCategoryController::update
 * @see app/Http/Controllers/ReservationCategoryController.php:56
 * @route '/admin/reservation-categories/{reservationCategory}'
 */
update.patch = (args: { reservationCategory: number | { id: number } } | [reservationCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\ReservationCategoryController::update
 * @see app/Http/Controllers/ReservationCategoryController.php:56
 * @route '/admin/reservation-categories/{reservationCategory}'
 */
    const updateForm = (args: { reservationCategory: number | { id: number } } | [reservationCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ReservationCategoryController::update
 * @see app/Http/Controllers/ReservationCategoryController.php:56
 * @route '/admin/reservation-categories/{reservationCategory}'
 */
        updateForm.patch = (args: { reservationCategory: number | { id: number } } | [reservationCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\ReservationCategoryController::status
 * @see app/Http/Controllers/ReservationCategoryController.php:85
 * @route '/admin/reservation-categories/{reservationCategory}/status'
 */
export const status = (args: { reservationCategory: number | { id: number } } | [reservationCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

status.definition = {
    methods: ["patch"],
    url: '/admin/reservation-categories/{reservationCategory}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\ReservationCategoryController::status
 * @see app/Http/Controllers/ReservationCategoryController.php:85
 * @route '/admin/reservation-categories/{reservationCategory}/status'
 */
status.url = (args: { reservationCategory: number | { id: number } } | [reservationCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { reservationCategory: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { reservationCategory: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    reservationCategory: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        reservationCategory: typeof args.reservationCategory === 'object'
                ? args.reservationCategory.id
                : args.reservationCategory,
                }

    return status.definition.url
            .replace('{reservationCategory}', parsedArgs.reservationCategory.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReservationCategoryController::status
 * @see app/Http/Controllers/ReservationCategoryController.php:85
 * @route '/admin/reservation-categories/{reservationCategory}/status'
 */
status.patch = (args: { reservationCategory: number | { id: number } } | [reservationCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\ReservationCategoryController::status
 * @see app/Http/Controllers/ReservationCategoryController.php:85
 * @route '/admin/reservation-categories/{reservationCategory}/status'
 */
    const statusForm = (args: { reservationCategory: number | { id: number } } | [reservationCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: status.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ReservationCategoryController::status
 * @see app/Http/Controllers/ReservationCategoryController.php:85
 * @route '/admin/reservation-categories/{reservationCategory}/status'
 */
        statusForm.patch = (args: { reservationCategory: number | { id: number } } | [reservationCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: status.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    status.form = statusForm
const ReservationCategoryController = { index, store, update, status }

export default ReservationCategoryController