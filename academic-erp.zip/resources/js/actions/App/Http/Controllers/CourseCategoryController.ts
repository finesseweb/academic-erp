import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CourseCategoryController::index
 * @see app/Http/Controllers/CourseCategoryController.php:18
 * @route '/admin/course-categories'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/course-categories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CourseCategoryController::index
 * @see app/Http/Controllers/CourseCategoryController.php:18
 * @route '/admin/course-categories'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CourseCategoryController::index
 * @see app/Http/Controllers/CourseCategoryController.php:18
 * @route '/admin/course-categories'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CourseCategoryController::index
 * @see app/Http/Controllers/CourseCategoryController.php:18
 * @route '/admin/course-categories'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CourseCategoryController::index
 * @see app/Http/Controllers/CourseCategoryController.php:18
 * @route '/admin/course-categories'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CourseCategoryController::index
 * @see app/Http/Controllers/CourseCategoryController.php:18
 * @route '/admin/course-categories'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CourseCategoryController::index
 * @see app/Http/Controllers/CourseCategoryController.php:18
 * @route '/admin/course-categories'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CourseCategoryController::store
 * @see app/Http/Controllers/CourseCategoryController.php:26
 * @route '/admin/course-categories'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/course-categories',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CourseCategoryController::store
 * @see app/Http/Controllers/CourseCategoryController.php:26
 * @route '/admin/course-categories'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CourseCategoryController::store
 * @see app/Http/Controllers/CourseCategoryController.php:26
 * @route '/admin/course-categories'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CourseCategoryController::store
 * @see app/Http/Controllers/CourseCategoryController.php:26
 * @route '/admin/course-categories'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CourseCategoryController::store
 * @see app/Http/Controllers/CourseCategoryController.php:26
 * @route '/admin/course-categories'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CourseCategoryController::update
 * @see app/Http/Controllers/CourseCategoryController.php:35
 * @route '/admin/course-categories/{courseCategory}'
 */
export const update = (args: { courseCategory: number | { id: number } } | [courseCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/course-categories/{courseCategory}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CourseCategoryController::update
 * @see app/Http/Controllers/CourseCategoryController.php:35
 * @route '/admin/course-categories/{courseCategory}'
 */
update.url = (args: { courseCategory: number | { id: number } } | [courseCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { courseCategory: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { courseCategory: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    courseCategory: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        courseCategory: typeof args.courseCategory === 'object'
                ? args.courseCategory.id
                : args.courseCategory,
                }

    return update.definition.url
            .replace('{courseCategory}', parsedArgs.courseCategory.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CourseCategoryController::update
 * @see app/Http/Controllers/CourseCategoryController.php:35
 * @route '/admin/course-categories/{courseCategory}'
 */
update.patch = (args: { courseCategory: number | { id: number } } | [courseCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CourseCategoryController::update
 * @see app/Http/Controllers/CourseCategoryController.php:35
 * @route '/admin/course-categories/{courseCategory}'
 */
    const updateForm = (args: { courseCategory: number | { id: number } } | [courseCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CourseCategoryController::update
 * @see app/Http/Controllers/CourseCategoryController.php:35
 * @route '/admin/course-categories/{courseCategory}'
 */
        updateForm.patch = (args: { courseCategory: number | { id: number } } | [courseCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CourseCategoryController::status
 * @see app/Http/Controllers/CourseCategoryController.php:44
 * @route '/admin/course-categories/{courseCategory}/status'
 */
export const status = (args: { courseCategory: number | { id: number } } | [courseCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

status.definition = {
    methods: ["patch"],
    url: '/admin/course-categories/{courseCategory}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CourseCategoryController::status
 * @see app/Http/Controllers/CourseCategoryController.php:44
 * @route '/admin/course-categories/{courseCategory}/status'
 */
status.url = (args: { courseCategory: number | { id: number } } | [courseCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { courseCategory: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { courseCategory: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    courseCategory: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        courseCategory: typeof args.courseCategory === 'object'
                ? args.courseCategory.id
                : args.courseCategory,
                }

    return status.definition.url
            .replace('{courseCategory}', parsedArgs.courseCategory.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CourseCategoryController::status
 * @see app/Http/Controllers/CourseCategoryController.php:44
 * @route '/admin/course-categories/{courseCategory}/status'
 */
status.patch = (args: { courseCategory: number | { id: number } } | [courseCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CourseCategoryController::status
 * @see app/Http/Controllers/CourseCategoryController.php:44
 * @route '/admin/course-categories/{courseCategory}/status'
 */
    const statusForm = (args: { courseCategory: number | { id: number } } | [courseCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: status.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CourseCategoryController::status
 * @see app/Http/Controllers/CourseCategoryController.php:44
 * @route '/admin/course-categories/{courseCategory}/status'
 */
        statusForm.patch = (args: { courseCategory: number | { id: number } } | [courseCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: status.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    status.form = statusForm
const CourseCategoryController = { index, store, update, status }

export default CourseCategoryController