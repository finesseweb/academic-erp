import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AcademicPolicyGradingRuleController::edit
 * @see app/Http/Controllers/AcademicPolicyGradingRuleController.php:20
 * @route '/admin/academic-policies/{academicPolicy}/grading'
 */
export const edit = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/academic-policies/{academicPolicy}/grading',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AcademicPolicyGradingRuleController::edit
 * @see app/Http/Controllers/AcademicPolicyGradingRuleController.php:20
 * @route '/admin/academic-policies/{academicPolicy}/grading'
 */
edit.url = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { academicPolicy: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { academicPolicy: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    academicPolicy: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        academicPolicy: typeof args.academicPolicy === 'object'
                ? args.academicPolicy.id
                : args.academicPolicy,
                }

    return edit.definition.url
            .replace('{academicPolicy}', parsedArgs.academicPolicy.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AcademicPolicyGradingRuleController::edit
 * @see app/Http/Controllers/AcademicPolicyGradingRuleController.php:20
 * @route '/admin/academic-policies/{academicPolicy}/grading'
 */
edit.get = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AcademicPolicyGradingRuleController::edit
 * @see app/Http/Controllers/AcademicPolicyGradingRuleController.php:20
 * @route '/admin/academic-policies/{academicPolicy}/grading'
 */
edit.head = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AcademicPolicyGradingRuleController::edit
 * @see app/Http/Controllers/AcademicPolicyGradingRuleController.php:20
 * @route '/admin/academic-policies/{academicPolicy}/grading'
 */
    const editForm = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AcademicPolicyGradingRuleController::edit
 * @see app/Http/Controllers/AcademicPolicyGradingRuleController.php:20
 * @route '/admin/academic-policies/{academicPolicy}/grading'
 */
        editForm.get = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AcademicPolicyGradingRuleController::edit
 * @see app/Http/Controllers/AcademicPolicyGradingRuleController.php:20
 * @route '/admin/academic-policies/{academicPolicy}/grading'
 */
        editForm.head = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\AcademicPolicyGradingRuleController::update
 * @see app/Http/Controllers/AcademicPolicyGradingRuleController.php:31
 * @route '/admin/academic-policies/{academicPolicy}/grading'
 */
export const update = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/academic-policies/{academicPolicy}/grading',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AcademicPolicyGradingRuleController::update
 * @see app/Http/Controllers/AcademicPolicyGradingRuleController.php:31
 * @route '/admin/academic-policies/{academicPolicy}/grading'
 */
update.url = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { academicPolicy: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { academicPolicy: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    academicPolicy: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        academicPolicy: typeof args.academicPolicy === 'object'
                ? args.academicPolicy.id
                : args.academicPolicy,
                }

    return update.definition.url
            .replace('{academicPolicy}', parsedArgs.academicPolicy.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AcademicPolicyGradingRuleController::update
 * @see app/Http/Controllers/AcademicPolicyGradingRuleController.php:31
 * @route '/admin/academic-policies/{academicPolicy}/grading'
 */
update.put = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AcademicPolicyGradingRuleController::update
 * @see app/Http/Controllers/AcademicPolicyGradingRuleController.php:31
 * @route '/admin/academic-policies/{academicPolicy}/grading'
 */
    const updateForm = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AcademicPolicyGradingRuleController::update
 * @see app/Http/Controllers/AcademicPolicyGradingRuleController.php:31
 * @route '/admin/academic-policies/{academicPolicy}/grading'
 */
        updateForm.put = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const AcademicPolicyGradingRuleController = { edit, update }

export default AcademicPolicyGradingRuleController