import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AcademicPolicyApprovalController::index
 * @see app/Http/Controllers/AcademicPolicyApprovalController.php:18
 * @route '/admin/academic-policies/approval-inbox'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/academic-policies/approval-inbox',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AcademicPolicyApprovalController::index
 * @see app/Http/Controllers/AcademicPolicyApprovalController.php:18
 * @route '/admin/academic-policies/approval-inbox'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AcademicPolicyApprovalController::index
 * @see app/Http/Controllers/AcademicPolicyApprovalController.php:18
 * @route '/admin/academic-policies/approval-inbox'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AcademicPolicyApprovalController::index
 * @see app/Http/Controllers/AcademicPolicyApprovalController.php:18
 * @route '/admin/academic-policies/approval-inbox'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AcademicPolicyApprovalController::index
 * @see app/Http/Controllers/AcademicPolicyApprovalController.php:18
 * @route '/admin/academic-policies/approval-inbox'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AcademicPolicyApprovalController::index
 * @see app/Http/Controllers/AcademicPolicyApprovalController.php:18
 * @route '/admin/academic-policies/approval-inbox'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AcademicPolicyApprovalController::index
 * @see app/Http/Controllers/AcademicPolicyApprovalController.php:18
 * @route '/admin/academic-policies/approval-inbox'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\AcademicPolicyApprovalController::decide
 * @see app/Http/Controllers/AcademicPolicyApprovalController.php:93
 * @route '/admin/academic-policies/approval-inbox/{approvalRequest}/decision'
 */
export const decide = (args: { approvalRequest: string | number } | [approvalRequest: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: decide.url(args, options),
    method: 'post',
})

decide.definition = {
    methods: ["post"],
    url: '/admin/academic-policies/approval-inbox/{approvalRequest}/decision',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AcademicPolicyApprovalController::decide
 * @see app/Http/Controllers/AcademicPolicyApprovalController.php:93
 * @route '/admin/academic-policies/approval-inbox/{approvalRequest}/decision'
 */
decide.url = (args: { approvalRequest: string | number } | [approvalRequest: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { approvalRequest: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    approvalRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        approvalRequest: args.approvalRequest,
                }

    return decide.definition.url
            .replace('{approvalRequest}', parsedArgs.approvalRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AcademicPolicyApprovalController::decide
 * @see app/Http/Controllers/AcademicPolicyApprovalController.php:93
 * @route '/admin/academic-policies/approval-inbox/{approvalRequest}/decision'
 */
decide.post = (args: { approvalRequest: string | number } | [approvalRequest: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: decide.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AcademicPolicyApprovalController::decide
 * @see app/Http/Controllers/AcademicPolicyApprovalController.php:93
 * @route '/admin/academic-policies/approval-inbox/{approvalRequest}/decision'
 */
    const decideForm = (args: { approvalRequest: string | number } | [approvalRequest: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: decide.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AcademicPolicyApprovalController::decide
 * @see app/Http/Controllers/AcademicPolicyApprovalController.php:93
 * @route '/admin/academic-policies/approval-inbox/{approvalRequest}/decision'
 */
        decideForm.post = (args: { approvalRequest: string | number } | [approvalRequest: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: decide.url(args, options),
            method: 'post',
        })
    
    decide.form = decideForm
const AcademicPolicyApprovalController = { index, decide }

export default AcademicPolicyApprovalController