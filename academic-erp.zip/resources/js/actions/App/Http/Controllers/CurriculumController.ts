import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CurriculumController::index
 * @see app/Http/Controllers/CurriculumController.php:37
 * @route '/admin/curricula'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/curricula',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CurriculumController::index
 * @see app/Http/Controllers/CurriculumController.php:37
 * @route '/admin/curricula'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumController::index
 * @see app/Http/Controllers/CurriculumController.php:37
 * @route '/admin/curricula'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CurriculumController::index
 * @see app/Http/Controllers/CurriculumController.php:37
 * @route '/admin/curricula'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CurriculumController::index
 * @see app/Http/Controllers/CurriculumController.php:37
 * @route '/admin/curricula'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CurriculumController::index
 * @see app/Http/Controllers/CurriculumController.php:37
 * @route '/admin/curricula'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CurriculumController::index
 * @see app/Http/Controllers/CurriculumController.php:37
 * @route '/admin/curricula'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CurriculumController::store
 * @see app/Http/Controllers/CurriculumController.php:209
 * @route '/admin/curricula'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/curricula',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CurriculumController::store
 * @see app/Http/Controllers/CurriculumController.php:209
 * @route '/admin/curricula'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumController::store
 * @see app/Http/Controllers/CurriculumController.php:209
 * @route '/admin/curricula'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CurriculumController::store
 * @see app/Http/Controllers/CurriculumController.php:209
 * @route '/admin/curricula'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CurriculumController::store
 * @see app/Http/Controllers/CurriculumController.php:209
 * @route '/admin/curricula'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CurriculumController::update
 * @see app/Http/Controllers/CurriculumController.php:217
 * @route '/admin/curricula/{curriculum}'
 */
export const update = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/curricula/{curriculum}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CurriculumController::update
 * @see app/Http/Controllers/CurriculumController.php:217
 * @route '/admin/curricula/{curriculum}'
 */
update.url = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { curriculum: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { curriculum: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                }

    return update.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumController::update
 * @see app/Http/Controllers/CurriculumController.php:217
 * @route '/admin/curricula/{curriculum}'
 */
update.patch = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CurriculumController::update
 * @see app/Http/Controllers/CurriculumController.php:217
 * @route '/admin/curricula/{curriculum}'
 */
    const updateForm = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CurriculumController::update
 * @see app/Http/Controllers/CurriculumController.php:217
 * @route '/admin/curricula/{curriculum}'
 */
        updateForm.patch = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CurriculumController::destroy
 * @see app/Http/Controllers/CurriculumController.php:280
 * @route '/admin/curricula/{curriculum}'
 */
export const destroy = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/curricula/{curriculum}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CurriculumController::destroy
 * @see app/Http/Controllers/CurriculumController.php:280
 * @route '/admin/curricula/{curriculum}'
 */
destroy.url = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { curriculum: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { curriculum: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                }

    return destroy.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumController::destroy
 * @see app/Http/Controllers/CurriculumController.php:280
 * @route '/admin/curricula/{curriculum}'
 */
destroy.delete = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CurriculumController::destroy
 * @see app/Http/Controllers/CurriculumController.php:280
 * @route '/admin/curricula/{curriculum}'
 */
    const destroyForm = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CurriculumController::destroy
 * @see app/Http/Controllers/CurriculumController.php:280
 * @route '/admin/curricula/{curriculum}'
 */
        destroyForm.delete = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\CurriculumController::cloneStructure
 * @see app/Http/Controllers/CurriculumController.php:261
 * @route '/admin/curricula/{curriculum}/clone-structure'
 */
export const cloneStructure = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cloneStructure.url(args, options),
    method: 'post',
})

cloneStructure.definition = {
    methods: ["post"],
    url: '/admin/curricula/{curriculum}/clone-structure',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CurriculumController::cloneStructure
 * @see app/Http/Controllers/CurriculumController.php:261
 * @route '/admin/curricula/{curriculum}/clone-structure'
 */
cloneStructure.url = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { curriculum: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { curriculum: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                }

    return cloneStructure.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumController::cloneStructure
 * @see app/Http/Controllers/CurriculumController.php:261
 * @route '/admin/curricula/{curriculum}/clone-structure'
 */
cloneStructure.post = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cloneStructure.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CurriculumController::cloneStructure
 * @see app/Http/Controllers/CurriculumController.php:261
 * @route '/admin/curricula/{curriculum}/clone-structure'
 */
    const cloneStructureForm = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cloneStructure.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CurriculumController::cloneStructure
 * @see app/Http/Controllers/CurriculumController.php:261
 * @route '/admin/curricula/{curriculum}/clone-structure'
 */
        cloneStructureForm.post = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cloneStructure.url(args, options),
            method: 'post',
        })
    
    cloneStructure.form = cloneStructureForm
/**
* @see \App\Http\Controllers\CurriculumController::amend
 * @see app/Http/Controllers/CurriculumController.php:242
 * @route '/admin/curricula/{curriculum}/amend'
 */
export const amend = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: amend.url(args, options),
    method: 'post',
})

amend.definition = {
    methods: ["post"],
    url: '/admin/curricula/{curriculum}/amend',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CurriculumController::amend
 * @see app/Http/Controllers/CurriculumController.php:242
 * @route '/admin/curricula/{curriculum}/amend'
 */
amend.url = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { curriculum: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { curriculum: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                }

    return amend.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumController::amend
 * @see app/Http/Controllers/CurriculumController.php:242
 * @route '/admin/curricula/{curriculum}/amend'
 */
amend.post = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: amend.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CurriculumController::amend
 * @see app/Http/Controllers/CurriculumController.php:242
 * @route '/admin/curricula/{curriculum}/amend'
 */
    const amendForm = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: amend.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CurriculumController::amend
 * @see app/Http/Controllers/CurriculumController.php:242
 * @route '/admin/curricula/{curriculum}/amend'
 */
        amendForm.post = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: amend.url(args, options),
            method: 'post',
        })
    
    amend.form = amendForm
/**
* @see \App\Http\Controllers\CurriculumController::submitForApproval
 * @see app/Http/Controllers/CurriculumController.php:303
 * @route '/admin/curricula/{curriculum}/submit-for-approval'
 */
export const submitForApproval = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submitForApproval.url(args, options),
    method: 'post',
})

submitForApproval.definition = {
    methods: ["post"],
    url: '/admin/curricula/{curriculum}/submit-for-approval',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CurriculumController::submitForApproval
 * @see app/Http/Controllers/CurriculumController.php:303
 * @route '/admin/curricula/{curriculum}/submit-for-approval'
 */
submitForApproval.url = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { curriculum: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { curriculum: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                }

    return submitForApproval.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumController::submitForApproval
 * @see app/Http/Controllers/CurriculumController.php:303
 * @route '/admin/curricula/{curriculum}/submit-for-approval'
 */
submitForApproval.post = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submitForApproval.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CurriculumController::submitForApproval
 * @see app/Http/Controllers/CurriculumController.php:303
 * @route '/admin/curricula/{curriculum}/submit-for-approval'
 */
    const submitForApprovalForm = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: submitForApproval.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CurriculumController::submitForApproval
 * @see app/Http/Controllers/CurriculumController.php:303
 * @route '/admin/curricula/{curriculum}/submit-for-approval'
 */
        submitForApprovalForm.post = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: submitForApproval.url(args, options),
            method: 'post',
        })
    
    submitForApproval.form = submitForApprovalForm
/**
* @see \App\Http\Controllers\CurriculumController::retire
 * @see app/Http/Controllers/CurriculumController.php:224
 * @route '/admin/curricula/{curriculum}/retire'
 */
export const retire = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: retire.url(args, options),
    method: 'patch',
})

retire.definition = {
    methods: ["patch"],
    url: '/admin/curricula/{curriculum}/retire',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CurriculumController::retire
 * @see app/Http/Controllers/CurriculumController.php:224
 * @route '/admin/curricula/{curriculum}/retire'
 */
retire.url = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { curriculum: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { curriculum: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                }

    return retire.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumController::retire
 * @see app/Http/Controllers/CurriculumController.php:224
 * @route '/admin/curricula/{curriculum}/retire'
 */
retire.patch = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: retire.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CurriculumController::retire
 * @see app/Http/Controllers/CurriculumController.php:224
 * @route '/admin/curricula/{curriculum}/retire'
 */
    const retireForm = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: retire.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CurriculumController::retire
 * @see app/Http/Controllers/CurriculumController.php:224
 * @route '/admin/curricula/{curriculum}/retire'
 */
        retireForm.patch = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: retire.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    retire.form = retireForm
/**
* @see \App\Http\Controllers\CurriculumController::restore
 * @see app/Http/Controllers/CurriculumController.php:232
 * @route '/admin/curricula/{curriculum}/restore'
 */
export const restore = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: restore.url(args, options),
    method: 'patch',
})

restore.definition = {
    methods: ["patch"],
    url: '/admin/curricula/{curriculum}/restore',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CurriculumController::restore
 * @see app/Http/Controllers/CurriculumController.php:232
 * @route '/admin/curricula/{curriculum}/restore'
 */
restore.url = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { curriculum: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { curriculum: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                }

    return restore.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumController::restore
 * @see app/Http/Controllers/CurriculumController.php:232
 * @route '/admin/curricula/{curriculum}/restore'
 */
restore.patch = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: restore.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CurriculumController::restore
 * @see app/Http/Controllers/CurriculumController.php:232
 * @route '/admin/curricula/{curriculum}/restore'
 */
    const restoreForm = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: restore.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CurriculumController::restore
 * @see app/Http/Controllers/CurriculumController.php:232
 * @route '/admin/curricula/{curriculum}/restore'
 */
        restoreForm.patch = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: restore.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    restore.form = restoreForm
const CurriculumController = { index, store, update, destroy, cloneStructure, amend, submitForApproval, retire, restore }

export default CurriculumController