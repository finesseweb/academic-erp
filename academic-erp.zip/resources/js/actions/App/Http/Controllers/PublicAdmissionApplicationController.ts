import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PublicAdmissionApplicationController::show
 * @see app/Http/Controllers/PublicAdmissionApplicationController.php:23
 * @route '/apply/{slug}/application'
 */
export const show = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/apply/{slug}/application',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicAdmissionApplicationController::show
 * @see app/Http/Controllers/PublicAdmissionApplicationController.php:23
 * @route '/apply/{slug}/application'
 */
show.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return show.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicAdmissionApplicationController::show
 * @see app/Http/Controllers/PublicAdmissionApplicationController.php:23
 * @route '/apply/{slug}/application'
 */
show.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicAdmissionApplicationController::show
 * @see app/Http/Controllers/PublicAdmissionApplicationController.php:23
 * @route '/apply/{slug}/application'
 */
show.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicAdmissionApplicationController::show
 * @see app/Http/Controllers/PublicAdmissionApplicationController.php:23
 * @route '/apply/{slug}/application'
 */
    const showForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicAdmissionApplicationController::show
 * @see app/Http/Controllers/PublicAdmissionApplicationController.php:23
 * @route '/apply/{slug}/application'
 */
        showForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicAdmissionApplicationController::show
 * @see app/Http/Controllers/PublicAdmissionApplicationController.php:23
 * @route '/apply/{slug}/application'
 */
        showForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\PublicAdmissionApplicationController::store
 * @see app/Http/Controllers/PublicAdmissionApplicationController.php:95
 * @route '/apply/{slug}/application'
 */
export const store = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/apply/{slug}/application',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PublicAdmissionApplicationController::store
 * @see app/Http/Controllers/PublicAdmissionApplicationController.php:95
 * @route '/apply/{slug}/application'
 */
store.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return store.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicAdmissionApplicationController::store
 * @see app/Http/Controllers/PublicAdmissionApplicationController.php:95
 * @route '/apply/{slug}/application'
 */
store.post = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\PublicAdmissionApplicationController::store
 * @see app/Http/Controllers/PublicAdmissionApplicationController.php:95
 * @route '/apply/{slug}/application'
 */
    const storeForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PublicAdmissionApplicationController::store
 * @see app/Http/Controllers/PublicAdmissionApplicationController.php:95
 * @route '/apply/{slug}/application'
 */
        storeForm.post = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
const PublicAdmissionApplicationController = { show, store }

export default PublicAdmissionApplicationController