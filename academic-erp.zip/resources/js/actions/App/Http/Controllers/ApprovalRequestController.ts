import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ApprovalRequestController::index
 * @see app/Http/Controllers/ApprovalRequestController.php:21
 * @route '/admin/academic-approval/inbox'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/academic-approval/inbox',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ApprovalRequestController::index
 * @see app/Http/Controllers/ApprovalRequestController.php:21
 * @route '/admin/academic-approval/inbox'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ApprovalRequestController::index
 * @see app/Http/Controllers/ApprovalRequestController.php:21
 * @route '/admin/academic-approval/inbox'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ApprovalRequestController::index
 * @see app/Http/Controllers/ApprovalRequestController.php:21
 * @route '/admin/academic-approval/inbox'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ApprovalRequestController::index
 * @see app/Http/Controllers/ApprovalRequestController.php:21
 * @route '/admin/academic-approval/inbox'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ApprovalRequestController::index
 * @see app/Http/Controllers/ApprovalRequestController.php:21
 * @route '/admin/academic-approval/inbox'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ApprovalRequestController::index
 * @see app/Http/Controllers/ApprovalRequestController.php:21
 * @route '/admin/academic-approval/inbox'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ApprovalRequestController::decide
 * @see app/Http/Controllers/ApprovalRequestController.php:209
 * @route '/admin/academic-approval/requests/{approvalRequest}/decision'
 */
export const decide = (args: { approvalRequest: number | { id: number } } | [approvalRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: decide.url(args, options),
    method: 'post',
})

decide.definition = {
    methods: ["post"],
    url: '/admin/academic-approval/requests/{approvalRequest}/decision',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ApprovalRequestController::decide
 * @see app/Http/Controllers/ApprovalRequestController.php:209
 * @route '/admin/academic-approval/requests/{approvalRequest}/decision'
 */
decide.url = (args: { approvalRequest: number | { id: number } } | [approvalRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { approvalRequest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { approvalRequest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    approvalRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        approvalRequest: typeof args.approvalRequest === 'object'
                ? args.approvalRequest.id
                : args.approvalRequest,
                }

    return decide.definition.url
            .replace('{approvalRequest}', parsedArgs.approvalRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ApprovalRequestController::decide
 * @see app/Http/Controllers/ApprovalRequestController.php:209
 * @route '/admin/academic-approval/requests/{approvalRequest}/decision'
 */
decide.post = (args: { approvalRequest: number | { id: number } } | [approvalRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: decide.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ApprovalRequestController::decide
 * @see app/Http/Controllers/ApprovalRequestController.php:209
 * @route '/admin/academic-approval/requests/{approvalRequest}/decision'
 */
    const decideForm = (args: { approvalRequest: number | { id: number } } | [approvalRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: decide.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ApprovalRequestController::decide
 * @see app/Http/Controllers/ApprovalRequestController.php:209
 * @route '/admin/academic-approval/requests/{approvalRequest}/decision'
 */
        decideForm.post = (args: { approvalRequest: number | { id: number } } | [approvalRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: decide.url(args, options),
            method: 'post',
        })
    
    decide.form = decideForm
const ApprovalRequestController = { index, decide }

export default ApprovalRequestController