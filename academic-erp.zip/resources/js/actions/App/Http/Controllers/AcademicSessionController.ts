import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AcademicSessionController::index
 * @see app/Http/Controllers/AcademicSessionController.php:18
 * @route '/admin/academic-sessions'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/academic-sessions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AcademicSessionController::index
 * @see app/Http/Controllers/AcademicSessionController.php:18
 * @route '/admin/academic-sessions'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AcademicSessionController::index
 * @see app/Http/Controllers/AcademicSessionController.php:18
 * @route '/admin/academic-sessions'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AcademicSessionController::index
 * @see app/Http/Controllers/AcademicSessionController.php:18
 * @route '/admin/academic-sessions'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AcademicSessionController::index
 * @see app/Http/Controllers/AcademicSessionController.php:18
 * @route '/admin/academic-sessions'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AcademicSessionController::index
 * @see app/Http/Controllers/AcademicSessionController.php:18
 * @route '/admin/academic-sessions'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AcademicSessionController::index
 * @see app/Http/Controllers/AcademicSessionController.php:18
 * @route '/admin/academic-sessions'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\AcademicSessionController::store
 * @see app/Http/Controllers/AcademicSessionController.php:27
 * @route '/admin/academic-sessions'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/academic-sessions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AcademicSessionController::store
 * @see app/Http/Controllers/AcademicSessionController.php:27
 * @route '/admin/academic-sessions'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AcademicSessionController::store
 * @see app/Http/Controllers/AcademicSessionController.php:27
 * @route '/admin/academic-sessions'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AcademicSessionController::store
 * @see app/Http/Controllers/AcademicSessionController.php:27
 * @route '/admin/academic-sessions'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AcademicSessionController::store
 * @see app/Http/Controllers/AcademicSessionController.php:27
 * @route '/admin/academic-sessions'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\AcademicSessionController::update
 * @see app/Http/Controllers/AcademicSessionController.php:37
 * @route '/admin/academic-sessions/{academicSession}'
 */
export const update = (args: { academicSession: number | { id: number } } | [academicSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/academic-sessions/{academicSession}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\AcademicSessionController::update
 * @see app/Http/Controllers/AcademicSessionController.php:37
 * @route '/admin/academic-sessions/{academicSession}'
 */
update.url = (args: { academicSession: number | { id: number } } | [academicSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { academicSession: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { academicSession: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    academicSession: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        academicSession: typeof args.academicSession === 'object'
                ? args.academicSession.id
                : args.academicSession,
                }

    return update.definition.url
            .replace('{academicSession}', parsedArgs.academicSession.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AcademicSessionController::update
 * @see app/Http/Controllers/AcademicSessionController.php:37
 * @route '/admin/academic-sessions/{academicSession}'
 */
update.patch = (args: { academicSession: number | { id: number } } | [academicSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\AcademicSessionController::update
 * @see app/Http/Controllers/AcademicSessionController.php:37
 * @route '/admin/academic-sessions/{academicSession}'
 */
    const updateForm = (args: { academicSession: number | { id: number } } | [academicSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AcademicSessionController::update
 * @see app/Http/Controllers/AcademicSessionController.php:37
 * @route '/admin/academic-sessions/{academicSession}'
 */
        updateForm.patch = (args: { academicSession: number | { id: number } } | [academicSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\AcademicSessionController::status
 * @see app/Http/Controllers/AcademicSessionController.php:47
 * @route '/admin/academic-sessions/{academicSession}/status'
 */
export const status = (args: { academicSession: number | { id: number } } | [academicSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

status.definition = {
    methods: ["patch"],
    url: '/admin/academic-sessions/{academicSession}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\AcademicSessionController::status
 * @see app/Http/Controllers/AcademicSessionController.php:47
 * @route '/admin/academic-sessions/{academicSession}/status'
 */
status.url = (args: { academicSession: number | { id: number } } | [academicSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { academicSession: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { academicSession: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    academicSession: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        academicSession: typeof args.academicSession === 'object'
                ? args.academicSession.id
                : args.academicSession,
                }

    return status.definition.url
            .replace('{academicSession}', parsedArgs.academicSession.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AcademicSessionController::status
 * @see app/Http/Controllers/AcademicSessionController.php:47
 * @route '/admin/academic-sessions/{academicSession}/status'
 */
status.patch = (args: { academicSession: number | { id: number } } | [academicSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\AcademicSessionController::status
 * @see app/Http/Controllers/AcademicSessionController.php:47
 * @route '/admin/academic-sessions/{academicSession}/status'
 */
    const statusForm = (args: { academicSession: number | { id: number } } | [academicSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: status.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AcademicSessionController::status
 * @see app/Http/Controllers/AcademicSessionController.php:47
 * @route '/admin/academic-sessions/{academicSession}/status'
 */
        statusForm.patch = (args: { academicSession: number | { id: number } } | [academicSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: status.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    status.form = statusForm
/**
* @see \App\Http\Controllers\AcademicSessionController::setCurrent
 * @see app/Http/Controllers/AcademicSessionController.php:57
 * @route '/admin/academic-sessions/{academicSession}/current'
 */
export const setCurrent = (args: { academicSession: number | { id: number } } | [academicSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: setCurrent.url(args, options),
    method: 'patch',
})

setCurrent.definition = {
    methods: ["patch"],
    url: '/admin/academic-sessions/{academicSession}/current',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\AcademicSessionController::setCurrent
 * @see app/Http/Controllers/AcademicSessionController.php:57
 * @route '/admin/academic-sessions/{academicSession}/current'
 */
setCurrent.url = (args: { academicSession: number | { id: number } } | [academicSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { academicSession: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { academicSession: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    academicSession: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        academicSession: typeof args.academicSession === 'object'
                ? args.academicSession.id
                : args.academicSession,
                }

    return setCurrent.definition.url
            .replace('{academicSession}', parsedArgs.academicSession.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AcademicSessionController::setCurrent
 * @see app/Http/Controllers/AcademicSessionController.php:57
 * @route '/admin/academic-sessions/{academicSession}/current'
 */
setCurrent.patch = (args: { academicSession: number | { id: number } } | [academicSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: setCurrent.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\AcademicSessionController::setCurrent
 * @see app/Http/Controllers/AcademicSessionController.php:57
 * @route '/admin/academic-sessions/{academicSession}/current'
 */
    const setCurrentForm = (args: { academicSession: number | { id: number } } | [academicSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: setCurrent.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AcademicSessionController::setCurrent
 * @see app/Http/Controllers/AcademicSessionController.php:57
 * @route '/admin/academic-sessions/{academicSession}/current'
 */
        setCurrentForm.patch = (args: { academicSession: number | { id: number } } | [academicSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: setCurrent.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    setCurrent.form = setCurrentForm
const AcademicSessionController = { index, store, update, status, setCurrent }

export default AcademicSessionController