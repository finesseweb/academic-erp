import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CollegeAdmissionInterviewController::index
 * @see app/Http/Controllers/CollegeAdmissionInterviewController.php:9
 * @route '/college/{college}/admission-interviews'
 */
export const index = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/college/{college}/admission-interviews',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionInterviewController::index
 * @see app/Http/Controllers/CollegeAdmissionInterviewController.php:9
 * @route '/college/{college}/admission-interviews'
 */
index.url = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { college: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { college: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                }

    return index.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionInterviewController::index
 * @see app/Http/Controllers/CollegeAdmissionInterviewController.php:9
 * @route '/college/{college}/admission-interviews'
 */
index.get = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CollegeAdmissionInterviewController::index
 * @see app/Http/Controllers/CollegeAdmissionInterviewController.php:9
 * @route '/college/{college}/admission-interviews'
 */
index.head = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionInterviewController::index
 * @see app/Http/Controllers/CollegeAdmissionInterviewController.php:9
 * @route '/college/{college}/admission-interviews'
 */
    const indexForm = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionInterviewController::index
 * @see app/Http/Controllers/CollegeAdmissionInterviewController.php:9
 * @route '/college/{college}/admission-interviews'
 */
        indexForm.get = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CollegeAdmissionInterviewController::index
 * @see app/Http/Controllers/CollegeAdmissionInterviewController.php:9
 * @route '/college/{college}/admission-interviews'
 */
        indexForm.head = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CollegeAdmissionInterviewController::upsert
 * @see app/Http/Controllers/CollegeAdmissionInterviewController.php:16
 * @route '/college/{college}/admission-application-choices/{choice}/interview'
 */
export const upsert = (args: { college: number | { id: number }, choice: number | { id: number } } | [college: number | { id: number }, choice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: upsert.url(args, options),
    method: 'put',
})

upsert.definition = {
    methods: ["put"],
    url: '/college/{college}/admission-application-choices/{choice}/interview',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionInterviewController::upsert
 * @see app/Http/Controllers/CollegeAdmissionInterviewController.php:16
 * @route '/college/{college}/admission-application-choices/{choice}/interview'
 */
upsert.url = (args: { college: number | { id: number }, choice: number | { id: number } } | [college: number | { id: number }, choice: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    choice: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                choice: typeof args.choice === 'object'
                ? args.choice.id
                : args.choice,
                }

    return upsert.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{choice}', parsedArgs.choice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionInterviewController::upsert
 * @see app/Http/Controllers/CollegeAdmissionInterviewController.php:16
 * @route '/college/{college}/admission-application-choices/{choice}/interview'
 */
upsert.put = (args: { college: number | { id: number }, choice: number | { id: number } } | [college: number | { id: number }, choice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: upsert.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionInterviewController::upsert
 * @see app/Http/Controllers/CollegeAdmissionInterviewController.php:16
 * @route '/college/{college}/admission-application-choices/{choice}/interview'
 */
    const upsertForm = (args: { college: number | { id: number }, choice: number | { id: number } } | [college: number | { id: number }, choice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: upsert.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionInterviewController::upsert
 * @see app/Http/Controllers/CollegeAdmissionInterviewController.php:16
 * @route '/college/{college}/admission-application-choices/{choice}/interview'
 */
        upsertForm.put = (args: { college: number | { id: number }, choice: number | { id: number } } | [college: number | { id: number }, choice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: upsert.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    upsert.form = upsertForm
const CollegeAdmissionInterviewController = { index, upsert }

export default CollegeAdmissionInterviewController