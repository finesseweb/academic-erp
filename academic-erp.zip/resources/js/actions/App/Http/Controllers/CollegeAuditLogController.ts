import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CollegeAuditLogController::index
 * @see app/Http/Controllers/CollegeAuditLogController.php:14
 * @route '/college/{college}/audit-logs'
 */
export const index = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/college/{college}/audit-logs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CollegeAuditLogController::index
 * @see app/Http/Controllers/CollegeAuditLogController.php:14
 * @route '/college/{college}/audit-logs'
 */
index.url = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { college: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { college: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                }

    return index.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAuditLogController::index
 * @see app/Http/Controllers/CollegeAuditLogController.php:14
 * @route '/college/{college}/audit-logs'
 */
index.get = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CollegeAuditLogController::index
 * @see app/Http/Controllers/CollegeAuditLogController.php:14
 * @route '/college/{college}/audit-logs'
 */
index.head = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CollegeAuditLogController::index
 * @see app/Http/Controllers/CollegeAuditLogController.php:14
 * @route '/college/{college}/audit-logs'
 */
    const indexForm = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CollegeAuditLogController::index
 * @see app/Http/Controllers/CollegeAuditLogController.php:14
 * @route '/college/{college}/audit-logs'
 */
        indexForm.get = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CollegeAuditLogController::index
 * @see app/Http/Controllers/CollegeAuditLogController.php:14
 * @route '/college/{college}/audit-logs'
 */
        indexForm.head = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const CollegeAuditLogController = { index }

export default CollegeAuditLogController