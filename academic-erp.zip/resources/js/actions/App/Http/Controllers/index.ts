import ApplicantPortalController from './ApplicantPortalController'
import PublicAdmissionApplicationController from './PublicAdmissionApplicationController'
import StudentPortalController from './StudentPortalController'
import UniversityController from './UniversityController'
import CollegeController from './CollegeController'
import UniversityAdmissionFormSetupController from './UniversityAdmissionFormSetupController'
import AuthorizedSignatoryController from './AuthorizedSignatoryController'
import UserController from './UserController'
import UserRoleController from './UserRoleController'
import RoleController from './RoleController'
import RolePermissionController from './RolePermissionController'
import PermissionController from './PermissionController'
import AuditLogController from './AuditLogController'
import TestDataCleanupController from './TestDataCleanupController'
import AcademicSessionController from './AcademicSessionController'
import AcademicCalendarController from './AcademicCalendarController'
import DegreeLevelController from './DegreeLevelController'
import DegreeController from './DegreeController'
import AcademicDisciplineController from './AcademicDisciplineController'
import ProgramTemplateController from './ProgramTemplateController'
import CourseCategoryController from './CourseCategoryController'
import CourseTypeController from './CourseTypeController'
import CourseController from './CourseController'
import AcademicPolicyController from './AcademicPolicyController'
import AcademicPolicyApprovalController from './AcademicPolicyApprovalController'
import AcademicPolicyCreditCompletionRuleController from './AcademicPolicyCreditCompletionRuleController'
import AcademicPolicyAttendanceRuleController from './AcademicPolicyAttendanceRuleController'
import AcademicPolicyAssessmentExamRuleController from './AcademicPolicyAssessmentExamRuleController'
import AcademicPolicyGradingRuleController from './AcademicPolicyGradingRuleController'
import AcademicPolicyProgressionRuleController from './AcademicPolicyProgressionRuleController'
import ApprovalRequestController from './ApprovalRequestController'
import ApprovalWorkflowController from './ApprovalWorkflowController'
import ReservationCategoryController from './ReservationCategoryController'
import CurriculumController from './CurriculumController'
import CurriculumStructureController from './CurriculumStructureController'
import CollegeProgramOfferingController from './CollegeProgramOfferingController'
import CollegeProgramIntakeController from './CollegeProgramIntakeController'
import CollegeReservationController from './CollegeReservationController'
import CollegeAdmissionSelectionRuleController from './CollegeAdmissionSelectionRuleController'
import CollegeAdmissionCycleController from './CollegeAdmissionCycleController'
import CollegeAdmissionFormSetupController from './CollegeAdmissionFormSetupController'
import CollegeAdmissionApplicationController from './CollegeAdmissionApplicationController'
import CollegeAdmissionScoreController from './CollegeAdmissionScoreController'
import CollegeAdmissionInterviewController from './CollegeAdmissionInterviewController'
import CollegeUserController from './CollegeUserController'
import CollegeAuditLogController from './CollegeAuditLogController'
import CollegeUserRoleController from './CollegeUserRoleController'
import CollegeRoleController from './CollegeRoleController'
import CollegeRolePermissionController from './CollegeRolePermissionController'
import Settings from './Settings'
const Controllers = {
    ApplicantPortalController: Object.assign(ApplicantPortalController, ApplicantPortalController),
PublicAdmissionApplicationController: Object.assign(PublicAdmissionApplicationController, PublicAdmissionApplicationController),
StudentPortalController: Object.assign(StudentPortalController, StudentPortalController),
UniversityController: Object.assign(UniversityController, UniversityController),
CollegeController: Object.assign(CollegeController, CollegeController),
UniversityAdmissionFormSetupController: Object.assign(UniversityAdmissionFormSetupController, UniversityAdmissionFormSetupController),
AuthorizedSignatoryController: Object.assign(AuthorizedSignatoryController, AuthorizedSignatoryController),
UserController: Object.assign(UserController, UserController),
UserRoleController: Object.assign(UserRoleController, UserRoleController),
RoleController: Object.assign(RoleController, RoleController),
RolePermissionController: Object.assign(RolePermissionController, RolePermissionController),
PermissionController: Object.assign(PermissionController, PermissionController),
AuditLogController: Object.assign(AuditLogController, AuditLogController),
TestDataCleanupController: Object.assign(TestDataCleanupController, TestDataCleanupController),
AcademicSessionController: Object.assign(AcademicSessionController, AcademicSessionController),
AcademicCalendarController: Object.assign(AcademicCalendarController, AcademicCalendarController),
DegreeLevelController: Object.assign(DegreeLevelController, DegreeLevelController),
DegreeController: Object.assign(DegreeController, DegreeController),
AcademicDisciplineController: Object.assign(AcademicDisciplineController, AcademicDisciplineController),
ProgramTemplateController: Object.assign(ProgramTemplateController, ProgramTemplateController),
CourseCategoryController: Object.assign(CourseCategoryController, CourseCategoryController),
CourseTypeController: Object.assign(CourseTypeController, CourseTypeController),
CourseController: Object.assign(CourseController, CourseController),
AcademicPolicyController: Object.assign(AcademicPolicyController, AcademicPolicyController),
AcademicPolicyApprovalController: Object.assign(AcademicPolicyApprovalController, AcademicPolicyApprovalController),
AcademicPolicyCreditCompletionRuleController: Object.assign(AcademicPolicyCreditCompletionRuleController, AcademicPolicyCreditCompletionRuleController),
AcademicPolicyAttendanceRuleController: Object.assign(AcademicPolicyAttendanceRuleController, AcademicPolicyAttendanceRuleController),
AcademicPolicyAssessmentExamRuleController: Object.assign(AcademicPolicyAssessmentExamRuleController, AcademicPolicyAssessmentExamRuleController),
AcademicPolicyGradingRuleController: Object.assign(AcademicPolicyGradingRuleController, AcademicPolicyGradingRuleController),
AcademicPolicyProgressionRuleController: Object.assign(AcademicPolicyProgressionRuleController, AcademicPolicyProgressionRuleController),
ApprovalRequestController: Object.assign(ApprovalRequestController, ApprovalRequestController),
ApprovalWorkflowController: Object.assign(ApprovalWorkflowController, ApprovalWorkflowController),
ReservationCategoryController: Object.assign(ReservationCategoryController, ReservationCategoryController),
CurriculumController: Object.assign(CurriculumController, CurriculumController),
CurriculumStructureController: Object.assign(CurriculumStructureController, CurriculumStructureController),
CollegeProgramOfferingController: Object.assign(CollegeProgramOfferingController, CollegeProgramOfferingController),
CollegeProgramIntakeController: Object.assign(CollegeProgramIntakeController, CollegeProgramIntakeController),
CollegeReservationController: Object.assign(CollegeReservationController, CollegeReservationController),
CollegeAdmissionSelectionRuleController: Object.assign(CollegeAdmissionSelectionRuleController, CollegeAdmissionSelectionRuleController),
CollegeAdmissionCycleController: Object.assign(CollegeAdmissionCycleController, CollegeAdmissionCycleController),
CollegeAdmissionFormSetupController: Object.assign(CollegeAdmissionFormSetupController, CollegeAdmissionFormSetupController),
CollegeAdmissionApplicationController: Object.assign(CollegeAdmissionApplicationController, CollegeAdmissionApplicationController),
CollegeAdmissionScoreController: Object.assign(CollegeAdmissionScoreController, CollegeAdmissionScoreController),
CollegeAdmissionInterviewController: Object.assign(CollegeAdmissionInterviewController, CollegeAdmissionInterviewController),
CollegeUserController: Object.assign(CollegeUserController, CollegeUserController),
CollegeAuditLogController: Object.assign(CollegeAuditLogController, CollegeAuditLogController),
CollegeUserRoleController: Object.assign(CollegeUserRoleController, CollegeUserRoleController),
CollegeRoleController: Object.assign(CollegeRoleController, CollegeRoleController),
CollegeRolePermissionController: Object.assign(CollegeRolePermissionController, CollegeRolePermissionController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers