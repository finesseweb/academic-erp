import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DegreeLevelController::index
 * @see app/Http/Controllers/DegreeLevelController.php:18
 * @route '/admin/degree-levels'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/degree-levels',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DegreeLevelController::index
 * @see app/Http/Controllers/DegreeLevelController.php:18
 * @route '/admin/degree-levels'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DegreeLevelController::index
 * @see app/Http/Controllers/DegreeLevelController.php:18
 * @route '/admin/degree-levels'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DegreeLevelController::index
 * @see app/Http/Controllers/DegreeLevelController.php:18
 * @route '/admin/degree-levels'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DegreeLevelController::index
 * @see app/Http/Controllers/DegreeLevelController.php:18
 * @route '/admin/degree-levels'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DegreeLevelController::index
 * @see app/Http/Controllers/DegreeLevelController.php:18
 * @route '/admin/degree-levels'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DegreeLevelController::index
 * @see app/Http/Controllers/DegreeLevelController.php:18
 * @route '/admin/degree-levels'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\DegreeLevelController::store
 * @see app/Http/Controllers/DegreeLevelController.php:26
 * @route '/admin/degree-levels'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/degree-levels',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DegreeLevelController::store
 * @see app/Http/Controllers/DegreeLevelController.php:26
 * @route '/admin/degree-levels'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DegreeLevelController::store
 * @see app/Http/Controllers/DegreeLevelController.php:26
 * @route '/admin/degree-levels'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DegreeLevelController::store
 * @see app/Http/Controllers/DegreeLevelController.php:26
 * @route '/admin/degree-levels'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DegreeLevelController::store
 * @see app/Http/Controllers/DegreeLevelController.php:26
 * @route '/admin/degree-levels'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\DegreeLevelController::update
 * @see app/Http/Controllers/DegreeLevelController.php:35
 * @route '/admin/degree-levels/{degreeLevel}'
 */
export const update = (args: { degreeLevel: number | { id: number } } | [degreeLevel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/degree-levels/{degreeLevel}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\DegreeLevelController::update
 * @see app/Http/Controllers/DegreeLevelController.php:35
 * @route '/admin/degree-levels/{degreeLevel}'
 */
update.url = (args: { degreeLevel: number | { id: number } } | [degreeLevel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { degreeLevel: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { degreeLevel: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    degreeLevel: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        degreeLevel: typeof args.degreeLevel === 'object'
                ? args.degreeLevel.id
                : args.degreeLevel,
                }

    return update.definition.url
            .replace('{degreeLevel}', parsedArgs.degreeLevel.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DegreeLevelController::update
 * @see app/Http/Controllers/DegreeLevelController.php:35
 * @route '/admin/degree-levels/{degreeLevel}'
 */
update.patch = (args: { degreeLevel: number | { id: number } } | [degreeLevel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DegreeLevelController::update
 * @see app/Http/Controllers/DegreeLevelController.php:35
 * @route '/admin/degree-levels/{degreeLevel}'
 */
    const updateForm = (args: { degreeLevel: number | { id: number } } | [degreeLevel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DegreeLevelController::update
 * @see app/Http/Controllers/DegreeLevelController.php:35
 * @route '/admin/degree-levels/{degreeLevel}'
 */
        updateForm.patch = (args: { degreeLevel: number | { id: number } } | [degreeLevel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\DegreeLevelController::status
 * @see app/Http/Controllers/DegreeLevelController.php:44
 * @route '/admin/degree-levels/{degreeLevel}/status'
 */
export const status = (args: { degreeLevel: number | { id: number } } | [degreeLevel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

status.definition = {
    methods: ["patch"],
    url: '/admin/degree-levels/{degreeLevel}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\DegreeLevelController::status
 * @see app/Http/Controllers/DegreeLevelController.php:44
 * @route '/admin/degree-levels/{degreeLevel}/status'
 */
status.url = (args: { degreeLevel: number | { id: number } } | [degreeLevel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { degreeLevel: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { degreeLevel: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    degreeLevel: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        degreeLevel: typeof args.degreeLevel === 'object'
                ? args.degreeLevel.id
                : args.degreeLevel,
                }

    return status.definition.url
            .replace('{degreeLevel}', parsedArgs.degreeLevel.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DegreeLevelController::status
 * @see app/Http/Controllers/DegreeLevelController.php:44
 * @route '/admin/degree-levels/{degreeLevel}/status'
 */
status.patch = (args: { degreeLevel: number | { id: number } } | [degreeLevel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DegreeLevelController::status
 * @see app/Http/Controllers/DegreeLevelController.php:44
 * @route '/admin/degree-levels/{degreeLevel}/status'
 */
    const statusForm = (args: { degreeLevel: number | { id: number } } | [degreeLevel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: status.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DegreeLevelController::status
 * @see app/Http/Controllers/DegreeLevelController.php:44
 * @route '/admin/degree-levels/{degreeLevel}/status'
 */
        statusForm.patch = (args: { degreeLevel: number | { id: number } } | [degreeLevel: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: status.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    status.form = statusForm
const DegreeLevelController = { index, store, update, status }

export default DegreeLevelController