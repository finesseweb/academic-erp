import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CollegeAdmissionCycleController::index
 * @see app/Http/Controllers/CollegeAdmissionCycleController.php:19
 * @route '/college/{college}/admission-cycles'
 */
export const index = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/college/{college}/admission-cycles',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionCycleController::index
 * @see app/Http/Controllers/CollegeAdmissionCycleController.php:19
 * @route '/college/{college}/admission-cycles'
 */
index.url = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { college: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { college: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                }

    return index.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionCycleController::index
 * @see app/Http/Controllers/CollegeAdmissionCycleController.php:19
 * @route '/college/{college}/admission-cycles'
 */
index.get = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CollegeAdmissionCycleController::index
 * @see app/Http/Controllers/CollegeAdmissionCycleController.php:19
 * @route '/college/{college}/admission-cycles'
 */
index.head = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionCycleController::index
 * @see app/Http/Controllers/CollegeAdmissionCycleController.php:19
 * @route '/college/{college}/admission-cycles'
 */
    const indexForm = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionCycleController::index
 * @see app/Http/Controllers/CollegeAdmissionCycleController.php:19
 * @route '/college/{college}/admission-cycles'
 */
        indexForm.get = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CollegeAdmissionCycleController::index
 * @see app/Http/Controllers/CollegeAdmissionCycleController.php:19
 * @route '/college/{college}/admission-cycles'
 */
        indexForm.head = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CollegeAdmissionCycleController::store
 * @see app/Http/Controllers/CollegeAdmissionCycleController.php:67
 * @route '/college/{college}/admission-cycles'
 */
export const store = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/college/{college}/admission-cycles',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionCycleController::store
 * @see app/Http/Controllers/CollegeAdmissionCycleController.php:67
 * @route '/college/{college}/admission-cycles'
 */
store.url = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { college: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { college: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                }

    return store.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionCycleController::store
 * @see app/Http/Controllers/CollegeAdmissionCycleController.php:67
 * @route '/college/{college}/admission-cycles'
 */
store.post = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionCycleController::store
 * @see app/Http/Controllers/CollegeAdmissionCycleController.php:67
 * @route '/college/{college}/admission-cycles'
 */
    const storeForm = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionCycleController::store
 * @see app/Http/Controllers/CollegeAdmissionCycleController.php:67
 * @route '/college/{college}/admission-cycles'
 */
        storeForm.post = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CollegeAdmissionCycleController::update
 * @see app/Http/Controllers/CollegeAdmissionCycleController.php:74
 * @route '/college/{college}/admission-cycles/{cycle}'
 */
export const update = (args: { college: number | { id: number }, cycle: number | { id: number } } | [college: number | { id: number }, cycle: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/college/{college}/admission-cycles/{cycle}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionCycleController::update
 * @see app/Http/Controllers/CollegeAdmissionCycleController.php:74
 * @route '/college/{college}/admission-cycles/{cycle}'
 */
update.url = (args: { college: number | { id: number }, cycle: number | { id: number } } | [college: number | { id: number }, cycle: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    cycle: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                cycle: typeof args.cycle === 'object'
                ? args.cycle.id
                : args.cycle,
                }

    return update.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{cycle}', parsedArgs.cycle.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionCycleController::update
 * @see app/Http/Controllers/CollegeAdmissionCycleController.php:74
 * @route '/college/{college}/admission-cycles/{cycle}'
 */
update.patch = (args: { college: number | { id: number }, cycle: number | { id: number } } | [college: number | { id: number }, cycle: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionCycleController::update
 * @see app/Http/Controllers/CollegeAdmissionCycleController.php:74
 * @route '/college/{college}/admission-cycles/{cycle}'
 */
    const updateForm = (args: { college: number | { id: number }, cycle: number | { id: number } } | [college: number | { id: number }, cycle: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionCycleController::update
 * @see app/Http/Controllers/CollegeAdmissionCycleController.php:74
 * @route '/college/{college}/admission-cycles/{cycle}'
 */
        updateForm.patch = (args: { college: number | { id: number }, cycle: number | { id: number } } | [college: number | { id: number }, cycle: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CollegeAdmissionCycleController::status
 * @see app/Http/Controllers/CollegeAdmissionCycleController.php:81
 * @route '/college/{college}/admission-cycles/{cycle}/status'
 */
export const status = (args: { college: number | { id: number }, cycle: number | { id: number } } | [college: number | { id: number }, cycle: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

status.definition = {
    methods: ["patch"],
    url: '/college/{college}/admission-cycles/{cycle}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionCycleController::status
 * @see app/Http/Controllers/CollegeAdmissionCycleController.php:81
 * @route '/college/{college}/admission-cycles/{cycle}/status'
 */
status.url = (args: { college: number | { id: number }, cycle: number | { id: number } } | [college: number | { id: number }, cycle: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    cycle: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                cycle: typeof args.cycle === 'object'
                ? args.cycle.id
                : args.cycle,
                }

    return status.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{cycle}', parsedArgs.cycle.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionCycleController::status
 * @see app/Http/Controllers/CollegeAdmissionCycleController.php:81
 * @route '/college/{college}/admission-cycles/{cycle}/status'
 */
status.patch = (args: { college: number | { id: number }, cycle: number | { id: number } } | [college: number | { id: number }, cycle: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionCycleController::status
 * @see app/Http/Controllers/CollegeAdmissionCycleController.php:81
 * @route '/college/{college}/admission-cycles/{cycle}/status'
 */
    const statusForm = (args: { college: number | { id: number }, cycle: number | { id: number } } | [college: number | { id: number }, cycle: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: status.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionCycleController::status
 * @see app/Http/Controllers/CollegeAdmissionCycleController.php:81
 * @route '/college/{college}/admission-cycles/{cycle}/status'
 */
        statusForm.patch = (args: { college: number | { id: number }, cycle: number | { id: number } } | [college: number | { id: number }, cycle: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: status.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    status.form = statusForm
const CollegeAdmissionCycleController = { index, store, update, status }

export default CollegeAdmissionCycleController