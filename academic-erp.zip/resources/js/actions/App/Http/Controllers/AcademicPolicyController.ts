import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AcademicPolicyController::index
 * @see app/Http/Controllers/AcademicPolicyController.php:30
 * @route '/admin/academic-policies'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/academic-policies',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AcademicPolicyController::index
 * @see app/Http/Controllers/AcademicPolicyController.php:30
 * @route '/admin/academic-policies'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AcademicPolicyController::index
 * @see app/Http/Controllers/AcademicPolicyController.php:30
 * @route '/admin/academic-policies'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AcademicPolicyController::index
 * @see app/Http/Controllers/AcademicPolicyController.php:30
 * @route '/admin/academic-policies'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AcademicPolicyController::index
 * @see app/Http/Controllers/AcademicPolicyController.php:30
 * @route '/admin/academic-policies'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AcademicPolicyController::index
 * @see app/Http/Controllers/AcademicPolicyController.php:30
 * @route '/admin/academic-policies'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AcademicPolicyController::index
 * @see app/Http/Controllers/AcademicPolicyController.php:30
 * @route '/admin/academic-policies'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\AcademicPolicyController::store
 * @see app/Http/Controllers/AcademicPolicyController.php:186
 * @route '/admin/academic-policies'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/academic-policies',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AcademicPolicyController::store
 * @see app/Http/Controllers/AcademicPolicyController.php:186
 * @route '/admin/academic-policies'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AcademicPolicyController::store
 * @see app/Http/Controllers/AcademicPolicyController.php:186
 * @route '/admin/academic-policies'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AcademicPolicyController::store
 * @see app/Http/Controllers/AcademicPolicyController.php:186
 * @route '/admin/academic-policies'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AcademicPolicyController::store
 * @see app/Http/Controllers/AcademicPolicyController.php:186
 * @route '/admin/academic-policies'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\AcademicPolicyController::update
 * @see app/Http/Controllers/AcademicPolicyController.php:193
 * @route '/admin/academic-policies/{academicPolicy}'
 */
export const update = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/academic-policies/{academicPolicy}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\AcademicPolicyController::update
 * @see app/Http/Controllers/AcademicPolicyController.php:193
 * @route '/admin/academic-policies/{academicPolicy}'
 */
update.url = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { academicPolicy: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { academicPolicy: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    academicPolicy: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        academicPolicy: typeof args.academicPolicy === 'object'
                ? args.academicPolicy.id
                : args.academicPolicy,
                }

    return update.definition.url
            .replace('{academicPolicy}', parsedArgs.academicPolicy.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AcademicPolicyController::update
 * @see app/Http/Controllers/AcademicPolicyController.php:193
 * @route '/admin/academic-policies/{academicPolicy}'
 */
update.patch = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\AcademicPolicyController::update
 * @see app/Http/Controllers/AcademicPolicyController.php:193
 * @route '/admin/academic-policies/{academicPolicy}'
 */
    const updateForm = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AcademicPolicyController::update
 * @see app/Http/Controllers/AcademicPolicyController.php:193
 * @route '/admin/academic-policies/{academicPolicy}'
 */
        updateForm.patch = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\AcademicPolicyController::validatePolicy
 * @see app/Http/Controllers/AcademicPolicyController.php:281
 * @route '/admin/academic-policies/{academicPolicy}/validate'
 */
export const validatePolicy = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: validatePolicy.url(args, options),
    method: 'post',
})

validatePolicy.definition = {
    methods: ["post"],
    url: '/admin/academic-policies/{academicPolicy}/validate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AcademicPolicyController::validatePolicy
 * @see app/Http/Controllers/AcademicPolicyController.php:281
 * @route '/admin/academic-policies/{academicPolicy}/validate'
 */
validatePolicy.url = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { academicPolicy: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { academicPolicy: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    academicPolicy: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        academicPolicy: typeof args.academicPolicy === 'object'
                ? args.academicPolicy.id
                : args.academicPolicy,
                }

    return validatePolicy.definition.url
            .replace('{academicPolicy}', parsedArgs.academicPolicy.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AcademicPolicyController::validatePolicy
 * @see app/Http/Controllers/AcademicPolicyController.php:281
 * @route '/admin/academic-policies/{academicPolicy}/validate'
 */
validatePolicy.post = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: validatePolicy.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AcademicPolicyController::validatePolicy
 * @see app/Http/Controllers/AcademicPolicyController.php:281
 * @route '/admin/academic-policies/{academicPolicy}/validate'
 */
    const validatePolicyForm = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: validatePolicy.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AcademicPolicyController::validatePolicy
 * @see app/Http/Controllers/AcademicPolicyController.php:281
 * @route '/admin/academic-policies/{academicPolicy}/validate'
 */
        validatePolicyForm.post = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: validatePolicy.url(args, options),
            method: 'post',
        })
    
    validatePolicy.form = validatePolicyForm
/**
* @see \App\Http\Controllers\AcademicPolicyController::submitForApproval
 * @see app/Http/Controllers/AcademicPolicyController.php:199
 * @route '/admin/academic-policies/{academicPolicy}/submit-for-approval'
 */
export const submitForApproval = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submitForApproval.url(args, options),
    method: 'post',
})

submitForApproval.definition = {
    methods: ["post"],
    url: '/admin/academic-policies/{academicPolicy}/submit-for-approval',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AcademicPolicyController::submitForApproval
 * @see app/Http/Controllers/AcademicPolicyController.php:199
 * @route '/admin/academic-policies/{academicPolicy}/submit-for-approval'
 */
submitForApproval.url = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { academicPolicy: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { academicPolicy: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    academicPolicy: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        academicPolicy: typeof args.academicPolicy === 'object'
                ? args.academicPolicy.id
                : args.academicPolicy,
                }

    return submitForApproval.definition.url
            .replace('{academicPolicy}', parsedArgs.academicPolicy.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AcademicPolicyController::submitForApproval
 * @see app/Http/Controllers/AcademicPolicyController.php:199
 * @route '/admin/academic-policies/{academicPolicy}/submit-for-approval'
 */
submitForApproval.post = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submitForApproval.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AcademicPolicyController::submitForApproval
 * @see app/Http/Controllers/AcademicPolicyController.php:199
 * @route '/admin/academic-policies/{academicPolicy}/submit-for-approval'
 */
    const submitForApprovalForm = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: submitForApproval.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AcademicPolicyController::submitForApproval
 * @see app/Http/Controllers/AcademicPolicyController.php:199
 * @route '/admin/academic-policies/{academicPolicy}/submit-for-approval'
 */
        submitForApprovalForm.post = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: submitForApproval.url(args, options),
            method: 'post',
        })
    
    submitForApproval.form = submitForApprovalForm
/**
* @see \App\Http\Controllers\AcademicPolicyController::amend
 * @see app/Http/Controllers/AcademicPolicyController.php:251
 * @route '/admin/academic-policies/{academicPolicy}/amend'
 */
export const amend = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: amend.url(args, options),
    method: 'post',
})

amend.definition = {
    methods: ["post"],
    url: '/admin/academic-policies/{academicPolicy}/amend',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AcademicPolicyController::amend
 * @see app/Http/Controllers/AcademicPolicyController.php:251
 * @route '/admin/academic-policies/{academicPolicy}/amend'
 */
amend.url = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { academicPolicy: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { academicPolicy: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    academicPolicy: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        academicPolicy: typeof args.academicPolicy === 'object'
                ? args.academicPolicy.id
                : args.academicPolicy,
                }

    return amend.definition.url
            .replace('{academicPolicy}', parsedArgs.academicPolicy.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AcademicPolicyController::amend
 * @see app/Http/Controllers/AcademicPolicyController.php:251
 * @route '/admin/academic-policies/{academicPolicy}/amend'
 */
amend.post = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: amend.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AcademicPolicyController::amend
 * @see app/Http/Controllers/AcademicPolicyController.php:251
 * @route '/admin/academic-policies/{academicPolicy}/amend'
 */
    const amendForm = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: amend.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AcademicPolicyController::amend
 * @see app/Http/Controllers/AcademicPolicyController.php:251
 * @route '/admin/academic-policies/{academicPolicy}/amend'
 */
        amendForm.post = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: amend.url(args, options),
            method: 'post',
        })
    
    amend.form = amendForm
/**
* @see \App\Http\Controllers\AcademicPolicyController::cloneFullPolicy
 * @see app/Http/Controllers/AcademicPolicyController.php:224
 * @route '/admin/academic-policies/{academicPolicy}/clone-full'
 */
export const cloneFullPolicy = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cloneFullPolicy.url(args, options),
    method: 'post',
})

cloneFullPolicy.definition = {
    methods: ["post"],
    url: '/admin/academic-policies/{academicPolicy}/clone-full',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AcademicPolicyController::cloneFullPolicy
 * @see app/Http/Controllers/AcademicPolicyController.php:224
 * @route '/admin/academic-policies/{academicPolicy}/clone-full'
 */
cloneFullPolicy.url = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { academicPolicy: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { academicPolicy: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    academicPolicy: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        academicPolicy: typeof args.academicPolicy === 'object'
                ? args.academicPolicy.id
                : args.academicPolicy,
                }

    return cloneFullPolicy.definition.url
            .replace('{academicPolicy}', parsedArgs.academicPolicy.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AcademicPolicyController::cloneFullPolicy
 * @see app/Http/Controllers/AcademicPolicyController.php:224
 * @route '/admin/academic-policies/{academicPolicy}/clone-full'
 */
cloneFullPolicy.post = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cloneFullPolicy.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AcademicPolicyController::cloneFullPolicy
 * @see app/Http/Controllers/AcademicPolicyController.php:224
 * @route '/admin/academic-policies/{academicPolicy}/clone-full'
 */
    const cloneFullPolicyForm = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cloneFullPolicy.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AcademicPolicyController::cloneFullPolicy
 * @see app/Http/Controllers/AcademicPolicyController.php:224
 * @route '/admin/academic-policies/{academicPolicy}/clone-full'
 */
        cloneFullPolicyForm.post = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cloneFullPolicy.url(args, options),
            method: 'post',
        })
    
    cloneFullPolicy.form = cloneFullPolicyForm
const AcademicPolicyController = { index, store, update, validatePolicy, submitForApproval, amend, cloneFullPolicy }

export default AcademicPolicyController