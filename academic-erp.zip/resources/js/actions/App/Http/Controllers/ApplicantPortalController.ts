import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ApplicantPortalController::gateway
 * @see app/Http/Controllers/ApplicantPortalController.php:23
 * @route '/apply/{slug}'
 */
export const gateway = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: gateway.url(args, options),
    method: 'get',
})

gateway.definition = {
    methods: ["get","head"],
    url: '/apply/{slug}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ApplicantPortalController::gateway
 * @see app/Http/Controllers/ApplicantPortalController.php:23
 * @route '/apply/{slug}'
 */
gateway.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return gateway.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ApplicantPortalController::gateway
 * @see app/Http/Controllers/ApplicantPortalController.php:23
 * @route '/apply/{slug}'
 */
gateway.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: gateway.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ApplicantPortalController::gateway
 * @see app/Http/Controllers/ApplicantPortalController.php:23
 * @route '/apply/{slug}'
 */
gateway.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: gateway.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ApplicantPortalController::gateway
 * @see app/Http/Controllers/ApplicantPortalController.php:23
 * @route '/apply/{slug}'
 */
    const gatewayForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: gateway.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ApplicantPortalController::gateway
 * @see app/Http/Controllers/ApplicantPortalController.php:23
 * @route '/apply/{slug}'
 */
        gatewayForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: gateway.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ApplicantPortalController::gateway
 * @see app/Http/Controllers/ApplicantPortalController.php:23
 * @route '/apply/{slug}'
 */
        gatewayForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: gateway.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    gateway.form = gatewayForm
/**
* @see \App\Http\Controllers\ApplicantPortalController::register
 * @see app/Http/Controllers/ApplicantPortalController.php:52
 * @route '/apply/{slug}/register'
 */
export const register = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(args, options),
    method: 'post',
})

register.definition = {
    methods: ["post"],
    url: '/apply/{slug}/register',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ApplicantPortalController::register
 * @see app/Http/Controllers/ApplicantPortalController.php:52
 * @route '/apply/{slug}/register'
 */
register.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return register.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ApplicantPortalController::register
 * @see app/Http/Controllers/ApplicantPortalController.php:52
 * @route '/apply/{slug}/register'
 */
register.post = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ApplicantPortalController::register
 * @see app/Http/Controllers/ApplicantPortalController.php:52
 * @route '/apply/{slug}/register'
 */
    const registerForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: register.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ApplicantPortalController::register
 * @see app/Http/Controllers/ApplicantPortalController.php:52
 * @route '/apply/{slug}/register'
 */
        registerForm.post = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: register.url(args, options),
            method: 'post',
        })
    
    register.form = registerForm
/**
* @see \App\Http\Controllers\ApplicantPortalController::login
 * @see app/Http/Controllers/ApplicantPortalController.php:66
 * @route '/apply/{slug}/login'
 */
export const login = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(args, options),
    method: 'post',
})

login.definition = {
    methods: ["post"],
    url: '/apply/{slug}/login',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ApplicantPortalController::login
 * @see app/Http/Controllers/ApplicantPortalController.php:66
 * @route '/apply/{slug}/login'
 */
login.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return login.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ApplicantPortalController::login
 * @see app/Http/Controllers/ApplicantPortalController.php:66
 * @route '/apply/{slug}/login'
 */
login.post = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ApplicantPortalController::login
 * @see app/Http/Controllers/ApplicantPortalController.php:66
 * @route '/apply/{slug}/login'
 */
    const loginForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: login.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ApplicantPortalController::login
 * @see app/Http/Controllers/ApplicantPortalController.php:66
 * @route '/apply/{slug}/login'
 */
        loginForm.post = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: login.url(args, options),
            method: 'post',
        })
    
    login.form = loginForm
/**
* @see \App\Http\Controllers\ApplicantPortalController::verificationNotice
 * @see app/Http/Controllers/ApplicantPortalController.php:73
 * @route '/apply/{slug}/verify-email'
 */
export const verificationNotice = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: verificationNotice.url(args, options),
    method: 'get',
})

verificationNotice.definition = {
    methods: ["get","head"],
    url: '/apply/{slug}/verify-email',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ApplicantPortalController::verificationNotice
 * @see app/Http/Controllers/ApplicantPortalController.php:73
 * @route '/apply/{slug}/verify-email'
 */
verificationNotice.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return verificationNotice.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ApplicantPortalController::verificationNotice
 * @see app/Http/Controllers/ApplicantPortalController.php:73
 * @route '/apply/{slug}/verify-email'
 */
verificationNotice.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: verificationNotice.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ApplicantPortalController::verificationNotice
 * @see app/Http/Controllers/ApplicantPortalController.php:73
 * @route '/apply/{slug}/verify-email'
 */
verificationNotice.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: verificationNotice.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ApplicantPortalController::verificationNotice
 * @see app/Http/Controllers/ApplicantPortalController.php:73
 * @route '/apply/{slug}/verify-email'
 */
    const verificationNoticeForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: verificationNotice.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ApplicantPortalController::verificationNotice
 * @see app/Http/Controllers/ApplicantPortalController.php:73
 * @route '/apply/{slug}/verify-email'
 */
        verificationNoticeForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: verificationNotice.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ApplicantPortalController::verificationNotice
 * @see app/Http/Controllers/ApplicantPortalController.php:73
 * @route '/apply/{slug}/verify-email'
 */
        verificationNoticeForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: verificationNotice.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    verificationNotice.form = verificationNoticeForm
/**
* @see \App\Http\Controllers\ApplicantPortalController::verifyEmail
 * @see app/Http/Controllers/ApplicantPortalController.php:78
 * @route '/apply/{slug}/verify-email/{id}/{hash}'
 */
export const verifyEmail = (args: { slug: string | number, id: string | number, hash: string | number } | [slug: string | number, id: string | number, hash: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: verifyEmail.url(args, options),
    method: 'get',
})

verifyEmail.definition = {
    methods: ["get","head"],
    url: '/apply/{slug}/verify-email/{id}/{hash}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ApplicantPortalController::verifyEmail
 * @see app/Http/Controllers/ApplicantPortalController.php:78
 * @route '/apply/{slug}/verify-email/{id}/{hash}'
 */
verifyEmail.url = (args: { slug: string | number, id: string | number, hash: string | number } | [slug: string | number, id: string | number, hash: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                    id: args[1],
                    hash: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                                id: args.id,
                                hash: args.hash,
                }

    return verifyEmail.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace('{id}', parsedArgs.id.toString())
            .replace('{hash}', parsedArgs.hash.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ApplicantPortalController::verifyEmail
 * @see app/Http/Controllers/ApplicantPortalController.php:78
 * @route '/apply/{slug}/verify-email/{id}/{hash}'
 */
verifyEmail.get = (args: { slug: string | number, id: string | number, hash: string | number } | [slug: string | number, id: string | number, hash: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: verifyEmail.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ApplicantPortalController::verifyEmail
 * @see app/Http/Controllers/ApplicantPortalController.php:78
 * @route '/apply/{slug}/verify-email/{id}/{hash}'
 */
verifyEmail.head = (args: { slug: string | number, id: string | number, hash: string | number } | [slug: string | number, id: string | number, hash: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: verifyEmail.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ApplicantPortalController::verifyEmail
 * @see app/Http/Controllers/ApplicantPortalController.php:78
 * @route '/apply/{slug}/verify-email/{id}/{hash}'
 */
    const verifyEmailForm = (args: { slug: string | number, id: string | number, hash: string | number } | [slug: string | number, id: string | number, hash: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: verifyEmail.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ApplicantPortalController::verifyEmail
 * @see app/Http/Controllers/ApplicantPortalController.php:78
 * @route '/apply/{slug}/verify-email/{id}/{hash}'
 */
        verifyEmailForm.get = (args: { slug: string | number, id: string | number, hash: string | number } | [slug: string | number, id: string | number, hash: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: verifyEmail.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ApplicantPortalController::verifyEmail
 * @see app/Http/Controllers/ApplicantPortalController.php:78
 * @route '/apply/{slug}/verify-email/{id}/{hash}'
 */
        verifyEmailForm.head = (args: { slug: string | number, id: string | number, hash: string | number } | [slug: string | number, id: string | number, hash: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: verifyEmail.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    verifyEmail.form = verifyEmailForm
/**
* @see \App\Http\Controllers\ApplicantPortalController::resendVerification
 * @see app/Http/Controllers/ApplicantPortalController.php:86
 * @route '/apply/{slug}/verify-email/resend'
 */
export const resendVerification = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resendVerification.url(args, options),
    method: 'post',
})

resendVerification.definition = {
    methods: ["post"],
    url: '/apply/{slug}/verify-email/resend',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ApplicantPortalController::resendVerification
 * @see app/Http/Controllers/ApplicantPortalController.php:86
 * @route '/apply/{slug}/verify-email/resend'
 */
resendVerification.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return resendVerification.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ApplicantPortalController::resendVerification
 * @see app/Http/Controllers/ApplicantPortalController.php:86
 * @route '/apply/{slug}/verify-email/resend'
 */
resendVerification.post = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resendVerification.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ApplicantPortalController::resendVerification
 * @see app/Http/Controllers/ApplicantPortalController.php:86
 * @route '/apply/{slug}/verify-email/resend'
 */
    const resendVerificationForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resendVerification.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ApplicantPortalController::resendVerification
 * @see app/Http/Controllers/ApplicantPortalController.php:86
 * @route '/apply/{slug}/verify-email/resend'
 */
        resendVerificationForm.post = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resendVerification.url(args, options),
            method: 'post',
        })
    
    resendVerification.form = resendVerificationForm
/**
* @see \App\Http\Controllers\ApplicantPortalController::logout
 * @see app/Http/Controllers/ApplicantPortalController.php:91
 * @route '/apply/{slug}/logout'
 */
export const logout = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(args, options),
    method: 'post',
})

logout.definition = {
    methods: ["post"],
    url: '/apply/{slug}/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ApplicantPortalController::logout
 * @see app/Http/Controllers/ApplicantPortalController.php:91
 * @route '/apply/{slug}/logout'
 */
logout.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return logout.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ApplicantPortalController::logout
 * @see app/Http/Controllers/ApplicantPortalController.php:91
 * @route '/apply/{slug}/logout'
 */
logout.post = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ApplicantPortalController::logout
 * @see app/Http/Controllers/ApplicantPortalController.php:91
 * @route '/apply/{slug}/logout'
 */
    const logoutForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: logout.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ApplicantPortalController::logout
 * @see app/Http/Controllers/ApplicantPortalController.php:91
 * @route '/apply/{slug}/logout'
 */
        logoutForm.post = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: logout.url(args, options),
            method: 'post',
        })
    
    logout.form = logoutForm
const ApplicantPortalController = { gateway, register, login, verificationNotice, verifyEmail, resendVerification, logout }

export default ApplicantPortalController