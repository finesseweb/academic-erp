import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CollegeUserController::index
 * @see app/Http/Controllers/CollegeUserController.php:23
 * @route '/college/{college}/users'
 */
export const index = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/college/{college}/users',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CollegeUserController::index
 * @see app/Http/Controllers/CollegeUserController.php:23
 * @route '/college/{college}/users'
 */
index.url = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { college: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { college: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                }

    return index.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeUserController::index
 * @see app/Http/Controllers/CollegeUserController.php:23
 * @route '/college/{college}/users'
 */
index.get = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CollegeUserController::index
 * @see app/Http/Controllers/CollegeUserController.php:23
 * @route '/college/{college}/users'
 */
index.head = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CollegeUserController::index
 * @see app/Http/Controllers/CollegeUserController.php:23
 * @route '/college/{college}/users'
 */
    const indexForm = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CollegeUserController::index
 * @see app/Http/Controllers/CollegeUserController.php:23
 * @route '/college/{college}/users'
 */
        indexForm.get = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CollegeUserController::index
 * @see app/Http/Controllers/CollegeUserController.php:23
 * @route '/college/{college}/users'
 */
        indexForm.head = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CollegeUserController::create
 * @see app/Http/Controllers/CollegeUserController.php:32
 * @route '/college/{college}/users/create'
 */
export const create = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/college/{college}/users/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CollegeUserController::create
 * @see app/Http/Controllers/CollegeUserController.php:32
 * @route '/college/{college}/users/create'
 */
create.url = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { college: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { college: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                }

    return create.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeUserController::create
 * @see app/Http/Controllers/CollegeUserController.php:32
 * @route '/college/{college}/users/create'
 */
create.get = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CollegeUserController::create
 * @see app/Http/Controllers/CollegeUserController.php:32
 * @route '/college/{college}/users/create'
 */
create.head = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CollegeUserController::create
 * @see app/Http/Controllers/CollegeUserController.php:32
 * @route '/college/{college}/users/create'
 */
    const createForm = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CollegeUserController::create
 * @see app/Http/Controllers/CollegeUserController.php:32
 * @route '/college/{college}/users/create'
 */
        createForm.get = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CollegeUserController::create
 * @see app/Http/Controllers/CollegeUserController.php:32
 * @route '/college/{college}/users/create'
 */
        createForm.head = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\CollegeUserController::store
 * @see app/Http/Controllers/CollegeUserController.php:39
 * @route '/college/{college}/users'
 */
export const store = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/college/{college}/users',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CollegeUserController::store
 * @see app/Http/Controllers/CollegeUserController.php:39
 * @route '/college/{college}/users'
 */
store.url = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { college: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { college: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                }

    return store.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeUserController::store
 * @see app/Http/Controllers/CollegeUserController.php:39
 * @route '/college/{college}/users'
 */
store.post = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CollegeUserController::store
 * @see app/Http/Controllers/CollegeUserController.php:39
 * @route '/college/{college}/users'
 */
    const storeForm = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeUserController::store
 * @see app/Http/Controllers/CollegeUserController.php:39
 * @route '/college/{college}/users'
 */
        storeForm.post = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CollegeUserController::edit
 * @see app/Http/Controllers/CollegeUserController.php:59
 * @route '/college/{college}/users/{user}/edit'
 */
export const edit = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/college/{college}/users/{user}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CollegeUserController::edit
 * @see app/Http/Controllers/CollegeUserController.php:59
 * @route '/college/{college}/users/{user}/edit'
 */
edit.url = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    user: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return edit.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeUserController::edit
 * @see app/Http/Controllers/CollegeUserController.php:59
 * @route '/college/{college}/users/{user}/edit'
 */
edit.get = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CollegeUserController::edit
 * @see app/Http/Controllers/CollegeUserController.php:59
 * @route '/college/{college}/users/{user}/edit'
 */
edit.head = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CollegeUserController::edit
 * @see app/Http/Controllers/CollegeUserController.php:59
 * @route '/college/{college}/users/{user}/edit'
 */
    const editForm = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CollegeUserController::edit
 * @see app/Http/Controllers/CollegeUserController.php:59
 * @route '/college/{college}/users/{user}/edit'
 */
        editForm.get = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CollegeUserController::edit
 * @see app/Http/Controllers/CollegeUserController.php:59
 * @route '/college/{college}/users/{user}/edit'
 */
        editForm.head = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\CollegeUserController::update
 * @see app/Http/Controllers/CollegeUserController.php:67
 * @route '/college/{college}/users/{user}'
 */
export const update = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/college/{college}/users/{user}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeUserController::update
 * @see app/Http/Controllers/CollegeUserController.php:67
 * @route '/college/{college}/users/{user}'
 */
update.url = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    user: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return update.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeUserController::update
 * @see app/Http/Controllers/CollegeUserController.php:67
 * @route '/college/{college}/users/{user}'
 */
update.patch = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeUserController::update
 * @see app/Http/Controllers/CollegeUserController.php:67
 * @route '/college/{college}/users/{user}'
 */
    const updateForm = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeUserController::update
 * @see app/Http/Controllers/CollegeUserController.php:67
 * @route '/college/{college}/users/{user}'
 */
        updateForm.patch = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CollegeUserController::status
 * @see app/Http/Controllers/CollegeUserController.php:48
 * @route '/college/{college}/users/{user}/status'
 */
export const status = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

status.definition = {
    methods: ["patch"],
    url: '/college/{college}/users/{user}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeUserController::status
 * @see app/Http/Controllers/CollegeUserController.php:48
 * @route '/college/{college}/users/{user}/status'
 */
status.url = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    user: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return status.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeUserController::status
 * @see app/Http/Controllers/CollegeUserController.php:48
 * @route '/college/{college}/users/{user}/status'
 */
status.patch = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeUserController::status
 * @see app/Http/Controllers/CollegeUserController.php:48
 * @route '/college/{college}/users/{user}/status'
 */
    const statusForm = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: status.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeUserController::status
 * @see app/Http/Controllers/CollegeUserController.php:48
 * @route '/college/{college}/users/{user}/status'
 */
        statusForm.patch = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: status.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    status.form = statusForm
/**
* @see \App\Http\Controllers\CollegeUserController::resetPassword
 * @see app/Http/Controllers/CollegeUserController.php:77
 * @route '/college/{college}/users/{user}/password-reset'
 */
export const resetPassword = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetPassword.url(args, options),
    method: 'post',
})

resetPassword.definition = {
    methods: ["post"],
    url: '/college/{college}/users/{user}/password-reset',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CollegeUserController::resetPassword
 * @see app/Http/Controllers/CollegeUserController.php:77
 * @route '/college/{college}/users/{user}/password-reset'
 */
resetPassword.url = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    user: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return resetPassword.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeUserController::resetPassword
 * @see app/Http/Controllers/CollegeUserController.php:77
 * @route '/college/{college}/users/{user}/password-reset'
 */
resetPassword.post = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetPassword.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CollegeUserController::resetPassword
 * @see app/Http/Controllers/CollegeUserController.php:77
 * @route '/college/{college}/users/{user}/password-reset'
 */
    const resetPasswordForm = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resetPassword.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeUserController::resetPassword
 * @see app/Http/Controllers/CollegeUserController.php:77
 * @route '/college/{college}/users/{user}/password-reset'
 */
        resetPasswordForm.post = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resetPassword.url(args, options),
            method: 'post',
        })
    
    resetPassword.form = resetPasswordForm
const CollegeUserController = { index, create, store, edit, update, status, resetPassword }

export default CollegeUserController