import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CollegeUserRoleController::edit
 * @see app/Http/Controllers/CollegeUserRoleController.php:18
 * @route '/college/{college}/users/{user}/roles'
 */
export const edit = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/college/{college}/users/{user}/roles',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CollegeUserRoleController::edit
 * @see app/Http/Controllers/CollegeUserRoleController.php:18
 * @route '/college/{college}/users/{user}/roles'
 */
edit.url = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    user: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return edit.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeUserRoleController::edit
 * @see app/Http/Controllers/CollegeUserRoleController.php:18
 * @route '/college/{college}/users/{user}/roles'
 */
edit.get = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CollegeUserRoleController::edit
 * @see app/Http/Controllers/CollegeUserRoleController.php:18
 * @route '/college/{college}/users/{user}/roles'
 */
edit.head = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CollegeUserRoleController::edit
 * @see app/Http/Controllers/CollegeUserRoleController.php:18
 * @route '/college/{college}/users/{user}/roles'
 */
    const editForm = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CollegeUserRoleController::edit
 * @see app/Http/Controllers/CollegeUserRoleController.php:18
 * @route '/college/{college}/users/{user}/roles'
 */
        editForm.get = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CollegeUserRoleController::edit
 * @see app/Http/Controllers/CollegeUserRoleController.php:18
 * @route '/college/{college}/users/{user}/roles'
 */
        editForm.head = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\CollegeUserRoleController::store
 * @see app/Http/Controllers/CollegeUserRoleController.php:29
 * @route '/college/{college}/users/{user}/roles'
 */
export const store = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/college/{college}/users/{user}/roles',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CollegeUserRoleController::store
 * @see app/Http/Controllers/CollegeUserRoleController.php:29
 * @route '/college/{college}/users/{user}/roles'
 */
store.url = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    user: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return store.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeUserRoleController::store
 * @see app/Http/Controllers/CollegeUserRoleController.php:29
 * @route '/college/{college}/users/{user}/roles'
 */
store.post = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CollegeUserRoleController::store
 * @see app/Http/Controllers/CollegeUserRoleController.php:29
 * @route '/college/{college}/users/{user}/roles'
 */
    const storeForm = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeUserRoleController::store
 * @see app/Http/Controllers/CollegeUserRoleController.php:29
 * @route '/college/{college}/users/{user}/roles'
 */
        storeForm.post = (args: { college: number | { id: number }, user: number | { id: number } } | [college: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CollegeUserRoleController::destroy
 * @see app/Http/Controllers/CollegeUserRoleController.php:43
 * @route '/college/{college}/users/{user}/roles/{assignment}'
 */
export const destroy = (args: { college: number | { id: number }, user: number | { id: number }, assignment: number | { id: number } } | [college: number | { id: number }, user: number | { id: number }, assignment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/college/{college}/users/{user}/roles/{assignment}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CollegeUserRoleController::destroy
 * @see app/Http/Controllers/CollegeUserRoleController.php:43
 * @route '/college/{college}/users/{user}/roles/{assignment}'
 */
destroy.url = (args: { college: number | { id: number }, user: number | { id: number }, assignment: number | { id: number } } | [college: number | { id: number }, user: number | { id: number }, assignment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    user: args[1],
                    assignment: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                                assignment: typeof args.assignment === 'object'
                ? args.assignment.id
                : args.assignment,
                }

    return destroy.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{user}', parsedArgs.user.toString())
            .replace('{assignment}', parsedArgs.assignment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeUserRoleController::destroy
 * @see app/Http/Controllers/CollegeUserRoleController.php:43
 * @route '/college/{college}/users/{user}/roles/{assignment}'
 */
destroy.delete = (args: { college: number | { id: number }, user: number | { id: number }, assignment: number | { id: number } } | [college: number | { id: number }, user: number | { id: number }, assignment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CollegeUserRoleController::destroy
 * @see app/Http/Controllers/CollegeUserRoleController.php:43
 * @route '/college/{college}/users/{user}/roles/{assignment}'
 */
    const destroyForm = (args: { college: number | { id: number }, user: number | { id: number }, assignment: number | { id: number } } | [college: number | { id: number }, user: number | { id: number }, assignment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeUserRoleController::destroy
 * @see app/Http/Controllers/CollegeUserRoleController.php:43
 * @route '/college/{college}/users/{user}/roles/{assignment}'
 */
        destroyForm.delete = (args: { college: number | { id: number }, user: number | { id: number }, assignment: number | { id: number } } | [college: number | { id: number }, user: number | { id: number }, assignment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\CollegeUserRoleController::updateScope
 * @see app/Http/Controllers/CollegeUserRoleController.php:53
 * @route '/college/{college}/users/{user}/roles/{assignment}/scope'
 */
export const updateScope = (args: { college: number | { id: number }, user: number | { id: number }, assignment: number | { id: number } } | [college: number | { id: number }, user: number | { id: number }, assignment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateScope.url(args, options),
    method: 'patch',
})

updateScope.definition = {
    methods: ["patch"],
    url: '/college/{college}/users/{user}/roles/{assignment}/scope',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeUserRoleController::updateScope
 * @see app/Http/Controllers/CollegeUserRoleController.php:53
 * @route '/college/{college}/users/{user}/roles/{assignment}/scope'
 */
updateScope.url = (args: { college: number | { id: number }, user: number | { id: number }, assignment: number | { id: number } } | [college: number | { id: number }, user: number | { id: number }, assignment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    user: args[1],
                    assignment: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                                assignment: typeof args.assignment === 'object'
                ? args.assignment.id
                : args.assignment,
                }

    return updateScope.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{user}', parsedArgs.user.toString())
            .replace('{assignment}', parsedArgs.assignment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeUserRoleController::updateScope
 * @see app/Http/Controllers/CollegeUserRoleController.php:53
 * @route '/college/{college}/users/{user}/roles/{assignment}/scope'
 */
updateScope.patch = (args: { college: number | { id: number }, user: number | { id: number }, assignment: number | { id: number } } | [college: number | { id: number }, user: number | { id: number }, assignment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateScope.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeUserRoleController::updateScope
 * @see app/Http/Controllers/CollegeUserRoleController.php:53
 * @route '/college/{college}/users/{user}/roles/{assignment}/scope'
 */
    const updateScopeForm = (args: { college: number | { id: number }, user: number | { id: number }, assignment: number | { id: number } } | [college: number | { id: number }, user: number | { id: number }, assignment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateScope.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeUserRoleController::updateScope
 * @see app/Http/Controllers/CollegeUserRoleController.php:53
 * @route '/college/{college}/users/{user}/roles/{assignment}/scope'
 */
        updateScopeForm.patch = (args: { college: number | { id: number }, user: number | { id: number }, assignment: number | { id: number } } | [college: number | { id: number }, user: number | { id: number }, assignment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateScope.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateScope.form = updateScopeForm
const CollegeUserRoleController = { edit, store, destroy, updateScope }

export default CollegeUserRoleController