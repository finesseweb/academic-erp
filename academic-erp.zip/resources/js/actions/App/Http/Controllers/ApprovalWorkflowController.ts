import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ApprovalWorkflowController::index
 * @see app/Http/Controllers/ApprovalWorkflowController.php:19
 * @route '/admin/academic-approval/workflows'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/academic-approval/workflows',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::index
 * @see app/Http/Controllers/ApprovalWorkflowController.php:19
 * @route '/admin/academic-approval/workflows'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::index
 * @see app/Http/Controllers/ApprovalWorkflowController.php:19
 * @route '/admin/academic-approval/workflows'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ApprovalWorkflowController::index
 * @see app/Http/Controllers/ApprovalWorkflowController.php:19
 * @route '/admin/academic-approval/workflows'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ApprovalWorkflowController::index
 * @see app/Http/Controllers/ApprovalWorkflowController.php:19
 * @route '/admin/academic-approval/workflows'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ApprovalWorkflowController::index
 * @see app/Http/Controllers/ApprovalWorkflowController.php:19
 * @route '/admin/academic-approval/workflows'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ApprovalWorkflowController::index
 * @see app/Http/Controllers/ApprovalWorkflowController.php:19
 * @route '/admin/academic-approval/workflows'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ApprovalWorkflowController::store
 * @see app/Http/Controllers/ApprovalWorkflowController.php:47
 * @route '/admin/academic-approval/workflows'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/academic-approval/workflows',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::store
 * @see app/Http/Controllers/ApprovalWorkflowController.php:47
 * @route '/admin/academic-approval/workflows'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::store
 * @see app/Http/Controllers/ApprovalWorkflowController.php:47
 * @route '/admin/academic-approval/workflows'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ApprovalWorkflowController::store
 * @see app/Http/Controllers/ApprovalWorkflowController.php:47
 * @route '/admin/academic-approval/workflows'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ApprovalWorkflowController::store
 * @see app/Http/Controllers/ApprovalWorkflowController.php:47
 * @route '/admin/academic-approval/workflows'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ApprovalWorkflowController::storeStage
 * @see app/Http/Controllers/ApprovalWorkflowController.php:75
 * @route '/admin/academic-approval/workflows/{workflow}/stages'
 */
export const storeStage = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeStage.url(args, options),
    method: 'post',
})

storeStage.definition = {
    methods: ["post"],
    url: '/admin/academic-approval/workflows/{workflow}/stages',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::storeStage
 * @see app/Http/Controllers/ApprovalWorkflowController.php:75
 * @route '/admin/academic-approval/workflows/{workflow}/stages'
 */
storeStage.url = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { workflow: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { workflow: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    workflow: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        workflow: typeof args.workflow === 'object'
                ? args.workflow.id
                : args.workflow,
                }

    return storeStage.definition.url
            .replace('{workflow}', parsedArgs.workflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::storeStage
 * @see app/Http/Controllers/ApprovalWorkflowController.php:75
 * @route '/admin/academic-approval/workflows/{workflow}/stages'
 */
storeStage.post = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeStage.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ApprovalWorkflowController::storeStage
 * @see app/Http/Controllers/ApprovalWorkflowController.php:75
 * @route '/admin/academic-approval/workflows/{workflow}/stages'
 */
    const storeStageForm = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeStage.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ApprovalWorkflowController::storeStage
 * @see app/Http/Controllers/ApprovalWorkflowController.php:75
 * @route '/admin/academic-approval/workflows/{workflow}/stages'
 */
        storeStageForm.post = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeStage.url(args, options),
            method: 'post',
        })
    
    storeStage.form = storeStageForm
/**
* @see \App\Http\Controllers\ApprovalWorkflowController::status
 * @see app/Http/Controllers/ApprovalWorkflowController.php:102
 * @route '/admin/academic-approval/workflows/{workflow}/status'
 */
export const status = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

status.definition = {
    methods: ["patch"],
    url: '/admin/academic-approval/workflows/{workflow}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::status
 * @see app/Http/Controllers/ApprovalWorkflowController.php:102
 * @route '/admin/academic-approval/workflows/{workflow}/status'
 */
status.url = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { workflow: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { workflow: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    workflow: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        workflow: typeof args.workflow === 'object'
                ? args.workflow.id
                : args.workflow,
                }

    return status.definition.url
            .replace('{workflow}', parsedArgs.workflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ApprovalWorkflowController::status
 * @see app/Http/Controllers/ApprovalWorkflowController.php:102
 * @route '/admin/academic-approval/workflows/{workflow}/status'
 */
status.patch = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\ApprovalWorkflowController::status
 * @see app/Http/Controllers/ApprovalWorkflowController.php:102
 * @route '/admin/academic-approval/workflows/{workflow}/status'
 */
    const statusForm = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: status.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ApprovalWorkflowController::status
 * @see app/Http/Controllers/ApprovalWorkflowController.php:102
 * @route '/admin/academic-approval/workflows/{workflow}/status'
 */
        statusForm.patch = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: status.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    status.form = statusForm
const ApprovalWorkflowController = { index, store, storeStage, status }

export default ApprovalWorkflowController