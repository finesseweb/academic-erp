import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CollegeProgramOfferingController::index
 * @see app/Http/Controllers/CollegeProgramOfferingController.php:19
 * @route '/college/{college}/program-offerings'
 */
export const index = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/college/{college}/program-offerings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CollegeProgramOfferingController::index
 * @see app/Http/Controllers/CollegeProgramOfferingController.php:19
 * @route '/college/{college}/program-offerings'
 */
index.url = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { college: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { college: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                }

    return index.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeProgramOfferingController::index
 * @see app/Http/Controllers/CollegeProgramOfferingController.php:19
 * @route '/college/{college}/program-offerings'
 */
index.get = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CollegeProgramOfferingController::index
 * @see app/Http/Controllers/CollegeProgramOfferingController.php:19
 * @route '/college/{college}/program-offerings'
 */
index.head = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CollegeProgramOfferingController::index
 * @see app/Http/Controllers/CollegeProgramOfferingController.php:19
 * @route '/college/{college}/program-offerings'
 */
    const indexForm = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CollegeProgramOfferingController::index
 * @see app/Http/Controllers/CollegeProgramOfferingController.php:19
 * @route '/college/{college}/program-offerings'
 */
        indexForm.get = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CollegeProgramOfferingController::index
 * @see app/Http/Controllers/CollegeProgramOfferingController.php:19
 * @route '/college/{college}/program-offerings'
 */
        indexForm.head = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CollegeProgramOfferingController::store
 * @see app/Http/Controllers/CollegeProgramOfferingController.php:101
 * @route '/college/{college}/program-offerings'
 */
export const store = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/college/{college}/program-offerings',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CollegeProgramOfferingController::store
 * @see app/Http/Controllers/CollegeProgramOfferingController.php:101
 * @route '/college/{college}/program-offerings'
 */
store.url = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { college: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { college: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                }

    return store.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeProgramOfferingController::store
 * @see app/Http/Controllers/CollegeProgramOfferingController.php:101
 * @route '/college/{college}/program-offerings'
 */
store.post = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CollegeProgramOfferingController::store
 * @see app/Http/Controllers/CollegeProgramOfferingController.php:101
 * @route '/college/{college}/program-offerings'
 */
    const storeForm = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeProgramOfferingController::store
 * @see app/Http/Controllers/CollegeProgramOfferingController.php:101
 * @route '/college/{college}/program-offerings'
 */
        storeForm.post = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CollegeProgramOfferingController::update
 * @see app/Http/Controllers/CollegeProgramOfferingController.php:114
 * @route '/college/{college}/program-offerings/{offering}'
 */
export const update = (args: { college: number | { id: number }, offering: number | { id: number } } | [college: number | { id: number }, offering: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/college/{college}/program-offerings/{offering}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeProgramOfferingController::update
 * @see app/Http/Controllers/CollegeProgramOfferingController.php:114
 * @route '/college/{college}/program-offerings/{offering}'
 */
update.url = (args: { college: number | { id: number }, offering: number | { id: number } } | [college: number | { id: number }, offering: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    offering: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                offering: typeof args.offering === 'object'
                ? args.offering.id
                : args.offering,
                }

    return update.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{offering}', parsedArgs.offering.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeProgramOfferingController::update
 * @see app/Http/Controllers/CollegeProgramOfferingController.php:114
 * @route '/college/{college}/program-offerings/{offering}'
 */
update.patch = (args: { college: number | { id: number }, offering: number | { id: number } } | [college: number | { id: number }, offering: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeProgramOfferingController::update
 * @see app/Http/Controllers/CollegeProgramOfferingController.php:114
 * @route '/college/{college}/program-offerings/{offering}'
 */
    const updateForm = (args: { college: number | { id: number }, offering: number | { id: number } } | [college: number | { id: number }, offering: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeProgramOfferingController::update
 * @see app/Http/Controllers/CollegeProgramOfferingController.php:114
 * @route '/college/{college}/program-offerings/{offering}'
 */
        updateForm.patch = (args: { college: number | { id: number }, offering: number | { id: number } } | [college: number | { id: number }, offering: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CollegeProgramOfferingController::status
 * @see app/Http/Controllers/CollegeProgramOfferingController.php:128
 * @route '/college/{college}/program-offerings/{offering}/status'
 */
export const status = (args: { college: number | { id: number }, offering: number | { id: number } } | [college: number | { id: number }, offering: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

status.definition = {
    methods: ["patch"],
    url: '/college/{college}/program-offerings/{offering}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeProgramOfferingController::status
 * @see app/Http/Controllers/CollegeProgramOfferingController.php:128
 * @route '/college/{college}/program-offerings/{offering}/status'
 */
status.url = (args: { college: number | { id: number }, offering: number | { id: number } } | [college: number | { id: number }, offering: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    offering: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                offering: typeof args.offering === 'object'
                ? args.offering.id
                : args.offering,
                }

    return status.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{offering}', parsedArgs.offering.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeProgramOfferingController::status
 * @see app/Http/Controllers/CollegeProgramOfferingController.php:128
 * @route '/college/{college}/program-offerings/{offering}/status'
 */
status.patch = (args: { college: number | { id: number }, offering: number | { id: number } } | [college: number | { id: number }, offering: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeProgramOfferingController::status
 * @see app/Http/Controllers/CollegeProgramOfferingController.php:128
 * @route '/college/{college}/program-offerings/{offering}/status'
 */
    const statusForm = (args: { college: number | { id: number }, offering: number | { id: number } } | [college: number | { id: number }, offering: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: status.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeProgramOfferingController::status
 * @see app/Http/Controllers/CollegeProgramOfferingController.php:128
 * @route '/college/{college}/program-offerings/{offering}/status'
 */
        statusForm.patch = (args: { college: number | { id: number }, offering: number | { id: number } } | [college: number | { id: number }, offering: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: status.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    status.form = statusForm
const CollegeProgramOfferingController = { index, store, update, status }

export default CollegeProgramOfferingController