import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CollegeAdmissionSelectionRuleController::index
 * @see app/Http/Controllers/CollegeAdmissionSelectionRuleController.php:22
 * @route '/college/{college}/admission-selection-rules'
 */
export const index = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/college/{college}/admission-selection-rules',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionSelectionRuleController::index
 * @see app/Http/Controllers/CollegeAdmissionSelectionRuleController.php:22
 * @route '/college/{college}/admission-selection-rules'
 */
index.url = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { college: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { college: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                }

    return index.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionSelectionRuleController::index
 * @see app/Http/Controllers/CollegeAdmissionSelectionRuleController.php:22
 * @route '/college/{college}/admission-selection-rules'
 */
index.get = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CollegeAdmissionSelectionRuleController::index
 * @see app/Http/Controllers/CollegeAdmissionSelectionRuleController.php:22
 * @route '/college/{college}/admission-selection-rules'
 */
index.head = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionSelectionRuleController::index
 * @see app/Http/Controllers/CollegeAdmissionSelectionRuleController.php:22
 * @route '/college/{college}/admission-selection-rules'
 */
    const indexForm = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionSelectionRuleController::index
 * @see app/Http/Controllers/CollegeAdmissionSelectionRuleController.php:22
 * @route '/college/{college}/admission-selection-rules'
 */
        indexForm.get = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CollegeAdmissionSelectionRuleController::index
 * @see app/Http/Controllers/CollegeAdmissionSelectionRuleController.php:22
 * @route '/college/{college}/admission-selection-rules'
 */
        indexForm.head = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CollegeAdmissionSelectionRuleController::store
 * @see app/Http/Controllers/CollegeAdmissionSelectionRuleController.php:127
 * @route '/college/{college}/admission-selection-rules'
 */
export const store = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/college/{college}/admission-selection-rules',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionSelectionRuleController::store
 * @see app/Http/Controllers/CollegeAdmissionSelectionRuleController.php:127
 * @route '/college/{college}/admission-selection-rules'
 */
store.url = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { college: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { college: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                }

    return store.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionSelectionRuleController::store
 * @see app/Http/Controllers/CollegeAdmissionSelectionRuleController.php:127
 * @route '/college/{college}/admission-selection-rules'
 */
store.post = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionSelectionRuleController::store
 * @see app/Http/Controllers/CollegeAdmissionSelectionRuleController.php:127
 * @route '/college/{college}/admission-selection-rules'
 */
    const storeForm = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionSelectionRuleController::store
 * @see app/Http/Controllers/CollegeAdmissionSelectionRuleController.php:127
 * @route '/college/{college}/admission-selection-rules'
 */
        storeForm.post = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CollegeAdmissionSelectionRuleController::update
 * @see app/Http/Controllers/CollegeAdmissionSelectionRuleController.php:133
 * @route '/college/{college}/admission-selection-rules/{rule}'
 */
export const update = (args: { college: number | { id: number }, rule: number | { id: number } } | [college: number | { id: number }, rule: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/college/{college}/admission-selection-rules/{rule}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionSelectionRuleController::update
 * @see app/Http/Controllers/CollegeAdmissionSelectionRuleController.php:133
 * @route '/college/{college}/admission-selection-rules/{rule}'
 */
update.url = (args: { college: number | { id: number }, rule: number | { id: number } } | [college: number | { id: number }, rule: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    rule: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                rule: typeof args.rule === 'object'
                ? args.rule.id
                : args.rule,
                }

    return update.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{rule}', parsedArgs.rule.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionSelectionRuleController::update
 * @see app/Http/Controllers/CollegeAdmissionSelectionRuleController.php:133
 * @route '/college/{college}/admission-selection-rules/{rule}'
 */
update.patch = (args: { college: number | { id: number }, rule: number | { id: number } } | [college: number | { id: number }, rule: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionSelectionRuleController::update
 * @see app/Http/Controllers/CollegeAdmissionSelectionRuleController.php:133
 * @route '/college/{college}/admission-selection-rules/{rule}'
 */
    const updateForm = (args: { college: number | { id: number }, rule: number | { id: number } } | [college: number | { id: number }, rule: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionSelectionRuleController::update
 * @see app/Http/Controllers/CollegeAdmissionSelectionRuleController.php:133
 * @route '/college/{college}/admission-selection-rules/{rule}'
 */
        updateForm.patch = (args: { college: number | { id: number }, rule: number | { id: number } } | [college: number | { id: number }, rule: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CollegeAdmissionSelectionRuleController::activate
 * @see app/Http/Controllers/CollegeAdmissionSelectionRuleController.php:139
 * @route '/college/{college}/admission-selection-rules/{rule}/activate'
 */
export const activate = (args: { college: number | { id: number }, rule: number | { id: number } } | [college: number | { id: number }, rule: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: activate.url(args, options),
    method: 'patch',
})

activate.definition = {
    methods: ["patch"],
    url: '/college/{college}/admission-selection-rules/{rule}/activate',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionSelectionRuleController::activate
 * @see app/Http/Controllers/CollegeAdmissionSelectionRuleController.php:139
 * @route '/college/{college}/admission-selection-rules/{rule}/activate'
 */
activate.url = (args: { college: number | { id: number }, rule: number | { id: number } } | [college: number | { id: number }, rule: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    rule: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                rule: typeof args.rule === 'object'
                ? args.rule.id
                : args.rule,
                }

    return activate.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{rule}', parsedArgs.rule.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionSelectionRuleController::activate
 * @see app/Http/Controllers/CollegeAdmissionSelectionRuleController.php:139
 * @route '/college/{college}/admission-selection-rules/{rule}/activate'
 */
activate.patch = (args: { college: number | { id: number }, rule: number | { id: number } } | [college: number | { id: number }, rule: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: activate.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionSelectionRuleController::activate
 * @see app/Http/Controllers/CollegeAdmissionSelectionRuleController.php:139
 * @route '/college/{college}/admission-selection-rules/{rule}/activate'
 */
    const activateForm = (args: { college: number | { id: number }, rule: number | { id: number } } | [college: number | { id: number }, rule: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: activate.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionSelectionRuleController::activate
 * @see app/Http/Controllers/CollegeAdmissionSelectionRuleController.php:139
 * @route '/college/{college}/admission-selection-rules/{rule}/activate'
 */
        activateForm.patch = (args: { college: number | { id: number }, rule: number | { id: number } } | [college: number | { id: number }, rule: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: activate.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    activate.form = activateForm
/**
* @see \App\Http\Controllers\CollegeAdmissionSelectionRuleController::retire
 * @see app/Http/Controllers/CollegeAdmissionSelectionRuleController.php:146
 * @route '/college/{college}/admission-selection-rules/{rule}/retire'
 */
export const retire = (args: { college: number | { id: number }, rule: number | { id: number } } | [college: number | { id: number }, rule: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: retire.url(args, options),
    method: 'patch',
})

retire.definition = {
    methods: ["patch"],
    url: '/college/{college}/admission-selection-rules/{rule}/retire',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionSelectionRuleController::retire
 * @see app/Http/Controllers/CollegeAdmissionSelectionRuleController.php:146
 * @route '/college/{college}/admission-selection-rules/{rule}/retire'
 */
retire.url = (args: { college: number | { id: number }, rule: number | { id: number } } | [college: number | { id: number }, rule: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    rule: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                rule: typeof args.rule === 'object'
                ? args.rule.id
                : args.rule,
                }

    return retire.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{rule}', parsedArgs.rule.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionSelectionRuleController::retire
 * @see app/Http/Controllers/CollegeAdmissionSelectionRuleController.php:146
 * @route '/college/{college}/admission-selection-rules/{rule}/retire'
 */
retire.patch = (args: { college: number | { id: number }, rule: number | { id: number } } | [college: number | { id: number }, rule: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: retire.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionSelectionRuleController::retire
 * @see app/Http/Controllers/CollegeAdmissionSelectionRuleController.php:146
 * @route '/college/{college}/admission-selection-rules/{rule}/retire'
 */
    const retireForm = (args: { college: number | { id: number }, rule: number | { id: number } } | [college: number | { id: number }, rule: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: retire.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionSelectionRuleController::retire
 * @see app/Http/Controllers/CollegeAdmissionSelectionRuleController.php:146
 * @route '/college/{college}/admission-selection-rules/{rule}/retire'
 */
        retireForm.patch = (args: { college: number | { id: number }, rule: number | { id: number } } | [college: number | { id: number }, rule: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: retire.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    retire.form = retireForm
const CollegeAdmissionSelectionRuleController = { index, store, update, activate, retire }

export default CollegeAdmissionSelectionRuleController