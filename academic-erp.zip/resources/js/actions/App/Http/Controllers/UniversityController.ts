import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\UniversityController::show
 * @see app/Http/Controllers/UniversityController.php:15
 * @route '/admin/university'
 */
export const show = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/university',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UniversityController::show
 * @see app/Http/Controllers/UniversityController.php:15
 * @route '/admin/university'
 */
show.url = (options?: RouteQueryOptions) => {
    return show.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UniversityController::show
 * @see app/Http/Controllers/UniversityController.php:15
 * @route '/admin/university'
 */
show.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\UniversityController::show
 * @see app/Http/Controllers/UniversityController.php:15
 * @route '/admin/university'
 */
show.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\UniversityController::show
 * @see app/Http/Controllers/UniversityController.php:15
 * @route '/admin/university'
 */
    const showForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\UniversityController::show
 * @see app/Http/Controllers/UniversityController.php:15
 * @route '/admin/university'
 */
        showForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\UniversityController::show
 * @see app/Http/Controllers/UniversityController.php:15
 * @route '/admin/university'
 */
        showForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\UniversityController::update
 * @see app/Http/Controllers/UniversityController.php:28
 * @route '/admin/university/{university}'
 */
export const update = (args: { university: number | { id: number } } | [university: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/university/{university}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\UniversityController::update
 * @see app/Http/Controllers/UniversityController.php:28
 * @route '/admin/university/{university}'
 */
update.url = (args: { university: number | { id: number } } | [university: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { university: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { university: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    university: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        university: typeof args.university === 'object'
                ? args.university.id
                : args.university,
                }

    return update.definition.url
            .replace('{university}', parsedArgs.university.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UniversityController::update
 * @see app/Http/Controllers/UniversityController.php:28
 * @route '/admin/university/{university}'
 */
update.patch = (args: { university: number | { id: number } } | [university: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\UniversityController::update
 * @see app/Http/Controllers/UniversityController.php:28
 * @route '/admin/university/{university}'
 */
    const updateForm = (args: { university: number | { id: number } } | [university: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UniversityController::update
 * @see app/Http/Controllers/UniversityController.php:28
 * @route '/admin/university/{university}'
 */
        updateForm.patch = (args: { university: number | { id: number } } | [university: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const UniversityController = { show, update }

export default UniversityController