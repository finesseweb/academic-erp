import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DegreeController::index
 * @see app/Http/Controllers/DegreeController.php:19
 * @route '/admin/degrees'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/degrees',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DegreeController::index
 * @see app/Http/Controllers/DegreeController.php:19
 * @route '/admin/degrees'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DegreeController::index
 * @see app/Http/Controllers/DegreeController.php:19
 * @route '/admin/degrees'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DegreeController::index
 * @see app/Http/Controllers/DegreeController.php:19
 * @route '/admin/degrees'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DegreeController::index
 * @see app/Http/Controllers/DegreeController.php:19
 * @route '/admin/degrees'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DegreeController::index
 * @see app/Http/Controllers/DegreeController.php:19
 * @route '/admin/degrees'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DegreeController::index
 * @see app/Http/Controllers/DegreeController.php:19
 * @route '/admin/degrees'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\DegreeController::store
 * @see app/Http/Controllers/DegreeController.php:27
 * @route '/admin/degrees'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/degrees',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DegreeController::store
 * @see app/Http/Controllers/DegreeController.php:27
 * @route '/admin/degrees'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DegreeController::store
 * @see app/Http/Controllers/DegreeController.php:27
 * @route '/admin/degrees'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DegreeController::store
 * @see app/Http/Controllers/DegreeController.php:27
 * @route '/admin/degrees'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DegreeController::store
 * @see app/Http/Controllers/DegreeController.php:27
 * @route '/admin/degrees'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\DegreeController::update
 * @see app/Http/Controllers/DegreeController.php:36
 * @route '/admin/degrees/{degree}'
 */
export const update = (args: { degree: number | { id: number } } | [degree: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/degrees/{degree}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\DegreeController::update
 * @see app/Http/Controllers/DegreeController.php:36
 * @route '/admin/degrees/{degree}'
 */
update.url = (args: { degree: number | { id: number } } | [degree: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { degree: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { degree: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    degree: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        degree: typeof args.degree === 'object'
                ? args.degree.id
                : args.degree,
                }

    return update.definition.url
            .replace('{degree}', parsedArgs.degree.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DegreeController::update
 * @see app/Http/Controllers/DegreeController.php:36
 * @route '/admin/degrees/{degree}'
 */
update.patch = (args: { degree: number | { id: number } } | [degree: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DegreeController::update
 * @see app/Http/Controllers/DegreeController.php:36
 * @route '/admin/degrees/{degree}'
 */
    const updateForm = (args: { degree: number | { id: number } } | [degree: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DegreeController::update
 * @see app/Http/Controllers/DegreeController.php:36
 * @route '/admin/degrees/{degree}'
 */
        updateForm.patch = (args: { degree: number | { id: number } } | [degree: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\DegreeController::status
 * @see app/Http/Controllers/DegreeController.php:45
 * @route '/admin/degrees/{degree}/status'
 */
export const status = (args: { degree: number | { id: number } } | [degree: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

status.definition = {
    methods: ["patch"],
    url: '/admin/degrees/{degree}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\DegreeController::status
 * @see app/Http/Controllers/DegreeController.php:45
 * @route '/admin/degrees/{degree}/status'
 */
status.url = (args: { degree: number | { id: number } } | [degree: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { degree: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { degree: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    degree: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        degree: typeof args.degree === 'object'
                ? args.degree.id
                : args.degree,
                }

    return status.definition.url
            .replace('{degree}', parsedArgs.degree.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DegreeController::status
 * @see app/Http/Controllers/DegreeController.php:45
 * @route '/admin/degrees/{degree}/status'
 */
status.patch = (args: { degree: number | { id: number } } | [degree: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DegreeController::status
 * @see app/Http/Controllers/DegreeController.php:45
 * @route '/admin/degrees/{degree}/status'
 */
    const statusForm = (args: { degree: number | { id: number } } | [degree: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: status.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DegreeController::status
 * @see app/Http/Controllers/DegreeController.php:45
 * @route '/admin/degrees/{degree}/status'
 */
        statusForm.patch = (args: { degree: number | { id: number } } | [degree: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: status.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    status.form = statusForm
const DegreeController = { index, store, update, status }

export default DegreeController