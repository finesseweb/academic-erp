import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AcademicDisciplineController::index
 * @see app/Http/Controllers/AcademicDisciplineController.php:19
 * @route '/admin/disciplines'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/disciplines',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AcademicDisciplineController::index
 * @see app/Http/Controllers/AcademicDisciplineController.php:19
 * @route '/admin/disciplines'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AcademicDisciplineController::index
 * @see app/Http/Controllers/AcademicDisciplineController.php:19
 * @route '/admin/disciplines'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AcademicDisciplineController::index
 * @see app/Http/Controllers/AcademicDisciplineController.php:19
 * @route '/admin/disciplines'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AcademicDisciplineController::index
 * @see app/Http/Controllers/AcademicDisciplineController.php:19
 * @route '/admin/disciplines'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AcademicDisciplineController::index
 * @see app/Http/Controllers/AcademicDisciplineController.php:19
 * @route '/admin/disciplines'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AcademicDisciplineController::index
 * @see app/Http/Controllers/AcademicDisciplineController.php:19
 * @route '/admin/disciplines'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\AcademicDisciplineController::store
 * @see app/Http/Controllers/AcademicDisciplineController.php:28
 * @route '/admin/disciplines'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/disciplines',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AcademicDisciplineController::store
 * @see app/Http/Controllers/AcademicDisciplineController.php:28
 * @route '/admin/disciplines'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AcademicDisciplineController::store
 * @see app/Http/Controllers/AcademicDisciplineController.php:28
 * @route '/admin/disciplines'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AcademicDisciplineController::store
 * @see app/Http/Controllers/AcademicDisciplineController.php:28
 * @route '/admin/disciplines'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AcademicDisciplineController::store
 * @see app/Http/Controllers/AcademicDisciplineController.php:28
 * @route '/admin/disciplines'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\AcademicDisciplineController::update
 * @see app/Http/Controllers/AcademicDisciplineController.php:38
 * @route '/admin/disciplines/{discipline}'
 */
export const update = (args: { discipline: number | { id: number } } | [discipline: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/disciplines/{discipline}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\AcademicDisciplineController::update
 * @see app/Http/Controllers/AcademicDisciplineController.php:38
 * @route '/admin/disciplines/{discipline}'
 */
update.url = (args: { discipline: number | { id: number } } | [discipline: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { discipline: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { discipline: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    discipline: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        discipline: typeof args.discipline === 'object'
                ? args.discipline.id
                : args.discipline,
                }

    return update.definition.url
            .replace('{discipline}', parsedArgs.discipline.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AcademicDisciplineController::update
 * @see app/Http/Controllers/AcademicDisciplineController.php:38
 * @route '/admin/disciplines/{discipline}'
 */
update.patch = (args: { discipline: number | { id: number } } | [discipline: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\AcademicDisciplineController::update
 * @see app/Http/Controllers/AcademicDisciplineController.php:38
 * @route '/admin/disciplines/{discipline}'
 */
    const updateForm = (args: { discipline: number | { id: number } } | [discipline: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AcademicDisciplineController::update
 * @see app/Http/Controllers/AcademicDisciplineController.php:38
 * @route '/admin/disciplines/{discipline}'
 */
        updateForm.patch = (args: { discipline: number | { id: number } } | [discipline: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\AcademicDisciplineController::status
 * @see app/Http/Controllers/AcademicDisciplineController.php:47
 * @route '/admin/disciplines/{discipline}/status'
 */
export const status = (args: { discipline: number | { id: number } } | [discipline: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

status.definition = {
    methods: ["patch"],
    url: '/admin/disciplines/{discipline}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\AcademicDisciplineController::status
 * @see app/Http/Controllers/AcademicDisciplineController.php:47
 * @route '/admin/disciplines/{discipline}/status'
 */
status.url = (args: { discipline: number | { id: number } } | [discipline: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { discipline: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { discipline: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    discipline: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        discipline: typeof args.discipline === 'object'
                ? args.discipline.id
                : args.discipline,
                }

    return status.definition.url
            .replace('{discipline}', parsedArgs.discipline.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AcademicDisciplineController::status
 * @see app/Http/Controllers/AcademicDisciplineController.php:47
 * @route '/admin/disciplines/{discipline}/status'
 */
status.patch = (args: { discipline: number | { id: number } } | [discipline: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\AcademicDisciplineController::status
 * @see app/Http/Controllers/AcademicDisciplineController.php:47
 * @route '/admin/disciplines/{discipline}/status'
 */
    const statusForm = (args: { discipline: number | { id: number } } | [discipline: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: status.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AcademicDisciplineController::status
 * @see app/Http/Controllers/AcademicDisciplineController.php:47
 * @route '/admin/disciplines/{discipline}/status'
 */
        statusForm.patch = (args: { discipline: number | { id: number } } | [discipline: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: status.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    status.form = statusForm
const AcademicDisciplineController = { index, store, update, status }

export default AcademicDisciplineController