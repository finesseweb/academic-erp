import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CurriculumStructureController::terms
 * @see app/Http/Controllers/CurriculumStructureController.php:43
 * @route '/admin/curricula/{curriculum}/structure/terms'
 */
export const terms = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: terms.url(args, options),
    method: 'get',
})

terms.definition = {
    methods: ["get","head"],
    url: '/admin/curricula/{curriculum}/structure/terms',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CurriculumStructureController::terms
 * @see app/Http/Controllers/CurriculumStructureController.php:43
 * @route '/admin/curricula/{curriculum}/structure/terms'
 */
terms.url = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { curriculum: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { curriculum: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                }

    return terms.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumStructureController::terms
 * @see app/Http/Controllers/CurriculumStructureController.php:43
 * @route '/admin/curricula/{curriculum}/structure/terms'
 */
terms.get = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: terms.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CurriculumStructureController::terms
 * @see app/Http/Controllers/CurriculumStructureController.php:43
 * @route '/admin/curricula/{curriculum}/structure/terms'
 */
terms.head = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: terms.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CurriculumStructureController::terms
 * @see app/Http/Controllers/CurriculumStructureController.php:43
 * @route '/admin/curricula/{curriculum}/structure/terms'
 */
    const termsForm = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: terms.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CurriculumStructureController::terms
 * @see app/Http/Controllers/CurriculumStructureController.php:43
 * @route '/admin/curricula/{curriculum}/structure/terms'
 */
        termsForm.get = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: terms.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CurriculumStructureController::terms
 * @see app/Http/Controllers/CurriculumStructureController.php:43
 * @route '/admin/curricula/{curriculum}/structure/terms'
 */
        termsForm.head = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: terms.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    terms.form = termsForm
/**
* @see \App\Http\Controllers\CurriculumStructureController::cloneTargetTerms
 * @see app/Http/Controllers/CurriculumStructureController.php:750
 * @route '/admin/curricula/{curriculum}/clone-targets/{targetCurriculum}/terms'
 */
export const cloneTargetTerms = (args: { curriculum: number | { id: number }, targetCurriculum: number | { id: number } } | [curriculum: number | { id: number }, targetCurriculum: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cloneTargetTerms.url(args, options),
    method: 'get',
})

cloneTargetTerms.definition = {
    methods: ["get","head"],
    url: '/admin/curricula/{curriculum}/clone-targets/{targetCurriculum}/terms',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CurriculumStructureController::cloneTargetTerms
 * @see app/Http/Controllers/CurriculumStructureController.php:750
 * @route '/admin/curricula/{curriculum}/clone-targets/{targetCurriculum}/terms'
 */
cloneTargetTerms.url = (args: { curriculum: number | { id: number }, targetCurriculum: number | { id: number } } | [curriculum: number | { id: number }, targetCurriculum: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                    targetCurriculum: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                                targetCurriculum: typeof args.targetCurriculum === 'object'
                ? args.targetCurriculum.id
                : args.targetCurriculum,
                }

    return cloneTargetTerms.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace('{targetCurriculum}', parsedArgs.targetCurriculum.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumStructureController::cloneTargetTerms
 * @see app/Http/Controllers/CurriculumStructureController.php:750
 * @route '/admin/curricula/{curriculum}/clone-targets/{targetCurriculum}/terms'
 */
cloneTargetTerms.get = (args: { curriculum: number | { id: number }, targetCurriculum: number | { id: number } } | [curriculum: number | { id: number }, targetCurriculum: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cloneTargetTerms.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CurriculumStructureController::cloneTargetTerms
 * @see app/Http/Controllers/CurriculumStructureController.php:750
 * @route '/admin/curricula/{curriculum}/clone-targets/{targetCurriculum}/terms'
 */
cloneTargetTerms.head = (args: { curriculum: number | { id: number }, targetCurriculum: number | { id: number } } | [curriculum: number | { id: number }, targetCurriculum: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: cloneTargetTerms.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CurriculumStructureController::cloneTargetTerms
 * @see app/Http/Controllers/CurriculumStructureController.php:750
 * @route '/admin/curricula/{curriculum}/clone-targets/{targetCurriculum}/terms'
 */
    const cloneTargetTermsForm = (args: { curriculum: number | { id: number }, targetCurriculum: number | { id: number } } | [curriculum: number | { id: number }, targetCurriculum: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: cloneTargetTerms.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CurriculumStructureController::cloneTargetTerms
 * @see app/Http/Controllers/CurriculumStructureController.php:750
 * @route '/admin/curricula/{curriculum}/clone-targets/{targetCurriculum}/terms'
 */
        cloneTargetTermsForm.get = (args: { curriculum: number | { id: number }, targetCurriculum: number | { id: number } } | [curriculum: number | { id: number }, targetCurriculum: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: cloneTargetTerms.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CurriculumStructureController::cloneTargetTerms
 * @see app/Http/Controllers/CurriculumStructureController.php:750
 * @route '/admin/curricula/{curriculum}/clone-targets/{targetCurriculum}/terms'
 */
        cloneTargetTermsForm.head = (args: { curriculum: number | { id: number }, targetCurriculum: number | { id: number } } | [curriculum: number | { id: number }, targetCurriculum: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: cloneTargetTerms.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    cloneTargetTerms.form = cloneTargetTermsForm
/**
* @see \App\Http\Controllers\CurriculumStructureController::storeTerm
 * @see app/Http/Controllers/CurriculumStructureController.php:92
 * @route '/admin/curricula/{curriculum}/structure/terms'
 */
export const storeTerm = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeTerm.url(args, options),
    method: 'post',
})

storeTerm.definition = {
    methods: ["post"],
    url: '/admin/curricula/{curriculum}/structure/terms',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CurriculumStructureController::storeTerm
 * @see app/Http/Controllers/CurriculumStructureController.php:92
 * @route '/admin/curricula/{curriculum}/structure/terms'
 */
storeTerm.url = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { curriculum: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { curriculum: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                }

    return storeTerm.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumStructureController::storeTerm
 * @see app/Http/Controllers/CurriculumStructureController.php:92
 * @route '/admin/curricula/{curriculum}/structure/terms'
 */
storeTerm.post = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeTerm.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CurriculumStructureController::storeTerm
 * @see app/Http/Controllers/CurriculumStructureController.php:92
 * @route '/admin/curricula/{curriculum}/structure/terms'
 */
    const storeTermForm = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeTerm.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CurriculumStructureController::storeTerm
 * @see app/Http/Controllers/CurriculumStructureController.php:92
 * @route '/admin/curricula/{curriculum}/structure/terms'
 */
        storeTermForm.post = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeTerm.url(args, options),
            method: 'post',
        })
    
    storeTerm.form = storeTermForm
/**
* @see \App\Http\Controllers\CurriculumStructureController::cloneTerm
 * @see app/Http/Controllers/CurriculumStructureController.php:656
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/clone'
 */
export const cloneTerm = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cloneTerm.url(args, options),
    method: 'post',
})

cloneTerm.definition = {
    methods: ["post"],
    url: '/admin/curricula/{curriculum}/structure/terms/{term}/clone',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CurriculumStructureController::cloneTerm
 * @see app/Http/Controllers/CurriculumStructureController.php:656
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/clone'
 */
cloneTerm.url = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                    term: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                                term: typeof args.term === 'object'
                ? args.term.id
                : args.term,
                }

    return cloneTerm.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace('{term}', parsedArgs.term.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumStructureController::cloneTerm
 * @see app/Http/Controllers/CurriculumStructureController.php:656
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/clone'
 */
cloneTerm.post = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cloneTerm.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CurriculumStructureController::cloneTerm
 * @see app/Http/Controllers/CurriculumStructureController.php:656
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/clone'
 */
    const cloneTermForm = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cloneTerm.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CurriculumStructureController::cloneTerm
 * @see app/Http/Controllers/CurriculumStructureController.php:656
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/clone'
 */
        cloneTermForm.post = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cloneTerm.url(args, options),
            method: 'post',
        })
    
    cloneTerm.form = cloneTermForm
/**
* @see \App\Http\Controllers\CurriculumStructureController::updateTerm
 * @see app/Http/Controllers/CurriculumStructureController.php:105
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}'
 */
export const updateTerm = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateTerm.url(args, options),
    method: 'patch',
})

updateTerm.definition = {
    methods: ["patch"],
    url: '/admin/curricula/{curriculum}/structure/terms/{term}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CurriculumStructureController::updateTerm
 * @see app/Http/Controllers/CurriculumStructureController.php:105
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}'
 */
updateTerm.url = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                    term: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                                term: typeof args.term === 'object'
                ? args.term.id
                : args.term,
                }

    return updateTerm.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace('{term}', parsedArgs.term.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumStructureController::updateTerm
 * @see app/Http/Controllers/CurriculumStructureController.php:105
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}'
 */
updateTerm.patch = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateTerm.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CurriculumStructureController::updateTerm
 * @see app/Http/Controllers/CurriculumStructureController.php:105
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}'
 */
    const updateTermForm = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateTerm.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CurriculumStructureController::updateTerm
 * @see app/Http/Controllers/CurriculumStructureController.php:105
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}'
 */
        updateTermForm.patch = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateTerm.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateTerm.form = updateTermForm
/**
* @see \App\Http\Controllers\CurriculumStructureController::statusTerm
 * @see app/Http/Controllers/CurriculumStructureController.php:120
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/status'
 */
export const statusTerm = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: statusTerm.url(args, options),
    method: 'patch',
})

statusTerm.definition = {
    methods: ["patch"],
    url: '/admin/curricula/{curriculum}/structure/terms/{term}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CurriculumStructureController::statusTerm
 * @see app/Http/Controllers/CurriculumStructureController.php:120
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/status'
 */
statusTerm.url = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                    term: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                                term: typeof args.term === 'object'
                ? args.term.id
                : args.term,
                }

    return statusTerm.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace('{term}', parsedArgs.term.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumStructureController::statusTerm
 * @see app/Http/Controllers/CurriculumStructureController.php:120
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/status'
 */
statusTerm.patch = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: statusTerm.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CurriculumStructureController::statusTerm
 * @see app/Http/Controllers/CurriculumStructureController.php:120
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/status'
 */
    const statusTermForm = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: statusTerm.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CurriculumStructureController::statusTerm
 * @see app/Http/Controllers/CurriculumStructureController.php:120
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/status'
 */
        statusTermForm.patch = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: statusTerm.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    statusTerm.form = statusTermForm
/**
* @see \App\Http\Controllers\CurriculumStructureController::deleteTerm
 * @see app/Http/Controllers/CurriculumStructureController.php:696
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}'
 */
export const deleteTerm = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteTerm.url(args, options),
    method: 'delete',
})

deleteTerm.definition = {
    methods: ["delete"],
    url: '/admin/curricula/{curriculum}/structure/terms/{term}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CurriculumStructureController::deleteTerm
 * @see app/Http/Controllers/CurriculumStructureController.php:696
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}'
 */
deleteTerm.url = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                    term: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                                term: typeof args.term === 'object'
                ? args.term.id
                : args.term,
                }

    return deleteTerm.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace('{term}', parsedArgs.term.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumStructureController::deleteTerm
 * @see app/Http/Controllers/CurriculumStructureController.php:696
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}'
 */
deleteTerm.delete = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteTerm.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CurriculumStructureController::deleteTerm
 * @see app/Http/Controllers/CurriculumStructureController.php:696
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}'
 */
    const deleteTermForm = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: deleteTerm.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CurriculumStructureController::deleteTerm
 * @see app/Http/Controllers/CurriculumStructureController.php:696
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}'
 */
        deleteTermForm.delete = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: deleteTerm.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    deleteTerm.form = deleteTermForm
/**
* @see \App\Http\Controllers\CurriculumStructureController::slots
 * @see app/Http/Controllers/CurriculumStructureController.php:144
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots'
 */
export const slots = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: slots.url(args, options),
    method: 'get',
})

slots.definition = {
    methods: ["get","head"],
    url: '/admin/curricula/{curriculum}/structure/terms/{term}/slots',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CurriculumStructureController::slots
 * @see app/Http/Controllers/CurriculumStructureController.php:144
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots'
 */
slots.url = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                    term: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                                term: typeof args.term === 'object'
                ? args.term.id
                : args.term,
                }

    return slots.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace('{term}', parsedArgs.term.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumStructureController::slots
 * @see app/Http/Controllers/CurriculumStructureController.php:144
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots'
 */
slots.get = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: slots.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CurriculumStructureController::slots
 * @see app/Http/Controllers/CurriculumStructureController.php:144
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots'
 */
slots.head = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: slots.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CurriculumStructureController::slots
 * @see app/Http/Controllers/CurriculumStructureController.php:144
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots'
 */
    const slotsForm = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: slots.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CurriculumStructureController::slots
 * @see app/Http/Controllers/CurriculumStructureController.php:144
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots'
 */
        slotsForm.get = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: slots.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CurriculumStructureController::slots
 * @see app/Http/Controllers/CurriculumStructureController.php:144
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots'
 */
        slotsForm.head = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: slots.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    slots.form = slotsForm
/**
* @see \App\Http\Controllers\CurriculumStructureController::storeSlot
 * @see app/Http/Controllers/CurriculumStructureController.php:272
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots'
 */
export const storeSlot = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSlot.url(args, options),
    method: 'post',
})

storeSlot.definition = {
    methods: ["post"],
    url: '/admin/curricula/{curriculum}/structure/terms/{term}/slots',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CurriculumStructureController::storeSlot
 * @see app/Http/Controllers/CurriculumStructureController.php:272
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots'
 */
storeSlot.url = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                    term: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                                term: typeof args.term === 'object'
                ? args.term.id
                : args.term,
                }

    return storeSlot.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace('{term}', parsedArgs.term.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumStructureController::storeSlot
 * @see app/Http/Controllers/CurriculumStructureController.php:272
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots'
 */
storeSlot.post = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSlot.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CurriculumStructureController::storeSlot
 * @see app/Http/Controllers/CurriculumStructureController.php:272
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots'
 */
    const storeSlotForm = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeSlot.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CurriculumStructureController::storeSlot
 * @see app/Http/Controllers/CurriculumStructureController.php:272
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots'
 */
        storeSlotForm.post = (args: { curriculum: number | { id: number }, term: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeSlot.url(args, options),
            method: 'post',
        })
    
    storeSlot.form = storeSlotForm
/**
* @see \App\Http\Controllers\CurriculumStructureController::cloneSlot
 * @see app/Http/Controllers/CurriculumStructureController.php:675
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/clone'
 */
export const cloneSlot = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cloneSlot.url(args, options),
    method: 'post',
})

cloneSlot.definition = {
    methods: ["post"],
    url: '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/clone',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CurriculumStructureController::cloneSlot
 * @see app/Http/Controllers/CurriculumStructureController.php:675
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/clone'
 */
cloneSlot.url = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                    term: args[1],
                    slot: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                                term: typeof args.term === 'object'
                ? args.term.id
                : args.term,
                                slot: typeof args.slot === 'object'
                ? args.slot.id
                : args.slot,
                }

    return cloneSlot.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace('{term}', parsedArgs.term.toString())
            .replace('{slot}', parsedArgs.slot.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumStructureController::cloneSlot
 * @see app/Http/Controllers/CurriculumStructureController.php:675
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/clone'
 */
cloneSlot.post = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cloneSlot.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CurriculumStructureController::cloneSlot
 * @see app/Http/Controllers/CurriculumStructureController.php:675
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/clone'
 */
    const cloneSlotForm = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cloneSlot.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CurriculumStructureController::cloneSlot
 * @see app/Http/Controllers/CurriculumStructureController.php:675
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/clone'
 */
        cloneSlotForm.post = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cloneSlot.url(args, options),
            method: 'post',
        })
    
    cloneSlot.form = cloneSlotForm
/**
* @see \App\Http\Controllers\CurriculumStructureController::updateSlot
 * @see app/Http/Controllers/CurriculumStructureController.php:287
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}'
 */
export const updateSlot = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateSlot.url(args, options),
    method: 'patch',
})

updateSlot.definition = {
    methods: ["patch"],
    url: '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CurriculumStructureController::updateSlot
 * @see app/Http/Controllers/CurriculumStructureController.php:287
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}'
 */
updateSlot.url = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                    term: args[1],
                    slot: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                                term: typeof args.term === 'object'
                ? args.term.id
                : args.term,
                                slot: typeof args.slot === 'object'
                ? args.slot.id
                : args.slot,
                }

    return updateSlot.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace('{term}', parsedArgs.term.toString())
            .replace('{slot}', parsedArgs.slot.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumStructureController::updateSlot
 * @see app/Http/Controllers/CurriculumStructureController.php:287
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}'
 */
updateSlot.patch = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateSlot.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CurriculumStructureController::updateSlot
 * @see app/Http/Controllers/CurriculumStructureController.php:287
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}'
 */
    const updateSlotForm = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateSlot.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CurriculumStructureController::updateSlot
 * @see app/Http/Controllers/CurriculumStructureController.php:287
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}'
 */
        updateSlotForm.patch = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateSlot.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateSlot.form = updateSlotForm
/**
* @see \App\Http\Controllers\CurriculumStructureController::statusSlot
 * @see app/Http/Controllers/CurriculumStructureController.php:304
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/status'
 */
export const statusSlot = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: statusSlot.url(args, options),
    method: 'patch',
})

statusSlot.definition = {
    methods: ["patch"],
    url: '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CurriculumStructureController::statusSlot
 * @see app/Http/Controllers/CurriculumStructureController.php:304
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/status'
 */
statusSlot.url = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                    term: args[1],
                    slot: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                                term: typeof args.term === 'object'
                ? args.term.id
                : args.term,
                                slot: typeof args.slot === 'object'
                ? args.slot.id
                : args.slot,
                }

    return statusSlot.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace('{term}', parsedArgs.term.toString())
            .replace('{slot}', parsedArgs.slot.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumStructureController::statusSlot
 * @see app/Http/Controllers/CurriculumStructureController.php:304
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/status'
 */
statusSlot.patch = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: statusSlot.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CurriculumStructureController::statusSlot
 * @see app/Http/Controllers/CurriculumStructureController.php:304
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/status'
 */
    const statusSlotForm = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: statusSlot.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CurriculumStructureController::statusSlot
 * @see app/Http/Controllers/CurriculumStructureController.php:304
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/status'
 */
        statusSlotForm.patch = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: statusSlot.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    statusSlot.form = statusSlotForm
/**
* @see \App\Http\Controllers\CurriculumStructureController::deleteSlot
 * @see app/Http/Controllers/CurriculumStructureController.php:712
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}'
 */
export const deleteSlot = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteSlot.url(args, options),
    method: 'delete',
})

deleteSlot.definition = {
    methods: ["delete"],
    url: '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CurriculumStructureController::deleteSlot
 * @see app/Http/Controllers/CurriculumStructureController.php:712
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}'
 */
deleteSlot.url = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                    term: args[1],
                    slot: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                                term: typeof args.term === 'object'
                ? args.term.id
                : args.term,
                                slot: typeof args.slot === 'object'
                ? args.slot.id
                : args.slot,
                }

    return deleteSlot.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace('{term}', parsedArgs.term.toString())
            .replace('{slot}', parsedArgs.slot.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumStructureController::deleteSlot
 * @see app/Http/Controllers/CurriculumStructureController.php:712
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}'
 */
deleteSlot.delete = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteSlot.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CurriculumStructureController::deleteSlot
 * @see app/Http/Controllers/CurriculumStructureController.php:712
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}'
 */
    const deleteSlotForm = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: deleteSlot.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CurriculumStructureController::deleteSlot
 * @see app/Http/Controllers/CurriculumStructureController.php:712
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}'
 */
        deleteSlotForm.delete = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: deleteSlot.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    deleteSlot.form = deleteSlotForm
/**
* @see \App\Http\Controllers\CurriculumStructureController::courseMappings
 * @see app/Http/Controllers/CurriculumStructureController.php:331
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings'
 */
export const courseMappings = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: courseMappings.url(args, options),
    method: 'get',
})

courseMappings.definition = {
    methods: ["get","head"],
    url: '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CurriculumStructureController::courseMappings
 * @see app/Http/Controllers/CurriculumStructureController.php:331
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings'
 */
courseMappings.url = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                    term: args[1],
                    slot: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                                term: typeof args.term === 'object'
                ? args.term.id
                : args.term,
                                slot: typeof args.slot === 'object'
                ? args.slot.id
                : args.slot,
                }

    return courseMappings.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace('{term}', parsedArgs.term.toString())
            .replace('{slot}', parsedArgs.slot.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumStructureController::courseMappings
 * @see app/Http/Controllers/CurriculumStructureController.php:331
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings'
 */
courseMappings.get = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: courseMappings.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CurriculumStructureController::courseMappings
 * @see app/Http/Controllers/CurriculumStructureController.php:331
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings'
 */
courseMappings.head = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: courseMappings.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CurriculumStructureController::courseMappings
 * @see app/Http/Controllers/CurriculumStructureController.php:331
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings'
 */
    const courseMappingsForm = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: courseMappings.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CurriculumStructureController::courseMappings
 * @see app/Http/Controllers/CurriculumStructureController.php:331
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings'
 */
        courseMappingsForm.get = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: courseMappings.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CurriculumStructureController::courseMappings
 * @see app/Http/Controllers/CurriculumStructureController.php:331
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings'
 */
        courseMappingsForm.head = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: courseMappings.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    courseMappings.form = courseMappingsForm
/**
* @see \App\Http\Controllers\CurriculumStructureController::validateStructure
 * @see app/Http/Controllers/CurriculumStructureController.php:638
 * @route '/admin/curricula/{curriculum}/structure/validate'
 */
export const validateStructure = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: validateStructure.url(args, options),
    method: 'get',
})

validateStructure.definition = {
    methods: ["get","head"],
    url: '/admin/curricula/{curriculum}/structure/validate',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CurriculumStructureController::validateStructure
 * @see app/Http/Controllers/CurriculumStructureController.php:638
 * @route '/admin/curricula/{curriculum}/structure/validate'
 */
validateStructure.url = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { curriculum: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { curriculum: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                }

    return validateStructure.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumStructureController::validateStructure
 * @see app/Http/Controllers/CurriculumStructureController.php:638
 * @route '/admin/curricula/{curriculum}/structure/validate'
 */
validateStructure.get = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: validateStructure.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CurriculumStructureController::validateStructure
 * @see app/Http/Controllers/CurriculumStructureController.php:638
 * @route '/admin/curricula/{curriculum}/structure/validate'
 */
validateStructure.head = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: validateStructure.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CurriculumStructureController::validateStructure
 * @see app/Http/Controllers/CurriculumStructureController.php:638
 * @route '/admin/curricula/{curriculum}/structure/validate'
 */
    const validateStructureForm = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: validateStructure.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CurriculumStructureController::validateStructure
 * @see app/Http/Controllers/CurriculumStructureController.php:638
 * @route '/admin/curricula/{curriculum}/structure/validate'
 */
        validateStructureForm.get = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: validateStructure.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CurriculumStructureController::validateStructure
 * @see app/Http/Controllers/CurriculumStructureController.php:638
 * @route '/admin/curricula/{curriculum}/structure/validate'
 */
        validateStructureForm.head = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: validateStructure.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    validateStructure.form = validateStructureForm
/**
* @see \App\Http\Controllers\CurriculumStructureController::storeCourseMapping
 * @see app/Http/Controllers/CurriculumStructureController.php:532
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings'
 */
export const storeCourseMapping = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCourseMapping.url(args, options),
    method: 'post',
})

storeCourseMapping.definition = {
    methods: ["post"],
    url: '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CurriculumStructureController::storeCourseMapping
 * @see app/Http/Controllers/CurriculumStructureController.php:532
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings'
 */
storeCourseMapping.url = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                    term: args[1],
                    slot: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                                term: typeof args.term === 'object'
                ? args.term.id
                : args.term,
                                slot: typeof args.slot === 'object'
                ? args.slot.id
                : args.slot,
                }

    return storeCourseMapping.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace('{term}', parsedArgs.term.toString())
            .replace('{slot}', parsedArgs.slot.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumStructureController::storeCourseMapping
 * @see app/Http/Controllers/CurriculumStructureController.php:532
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings'
 */
storeCourseMapping.post = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCourseMapping.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CurriculumStructureController::storeCourseMapping
 * @see app/Http/Controllers/CurriculumStructureController.php:532
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings'
 */
    const storeCourseMappingForm = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeCourseMapping.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CurriculumStructureController::storeCourseMapping
 * @see app/Http/Controllers/CurriculumStructureController.php:532
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings'
 */
        storeCourseMappingForm.post = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeCourseMapping.url(args, options),
            method: 'post',
        })
    
    storeCourseMapping.form = storeCourseMappingForm
/**
* @see \App\Http\Controllers\CurriculumStructureController::updateCourseMapping
 * @see app/Http/Controllers/CurriculumStructureController.php:613
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings/{mapping}'
 */
export const updateCourseMapping = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateCourseMapping.url(args, options),
    method: 'patch',
})

updateCourseMapping.definition = {
    methods: ["patch"],
    url: '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings/{mapping}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CurriculumStructureController::updateCourseMapping
 * @see app/Http/Controllers/CurriculumStructureController.php:613
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings/{mapping}'
 */
updateCourseMapping.url = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                    term: args[1],
                    slot: args[2],
                    mapping: args[3],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                                term: typeof args.term === 'object'
                ? args.term.id
                : args.term,
                                slot: typeof args.slot === 'object'
                ? args.slot.id
                : args.slot,
                                mapping: typeof args.mapping === 'object'
                ? args.mapping.id
                : args.mapping,
                }

    return updateCourseMapping.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace('{term}', parsedArgs.term.toString())
            .replace('{slot}', parsedArgs.slot.toString())
            .replace('{mapping}', parsedArgs.mapping.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumStructureController::updateCourseMapping
 * @see app/Http/Controllers/CurriculumStructureController.php:613
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings/{mapping}'
 */
updateCourseMapping.patch = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateCourseMapping.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CurriculumStructureController::updateCourseMapping
 * @see app/Http/Controllers/CurriculumStructureController.php:613
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings/{mapping}'
 */
    const updateCourseMappingForm = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateCourseMapping.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CurriculumStructureController::updateCourseMapping
 * @see app/Http/Controllers/CurriculumStructureController.php:613
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings/{mapping}'
 */
        updateCourseMappingForm.patch = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateCourseMapping.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateCourseMapping.form = updateCourseMappingForm
/**
* @see \App\Http\Controllers\CurriculumStructureController::statusCourseMapping
 * @see app/Http/Controllers/CurriculumStructureController.php:558
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings/{mapping}/status'
 */
export const statusCourseMapping = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: statusCourseMapping.url(args, options),
    method: 'patch',
})

statusCourseMapping.definition = {
    methods: ["patch"],
    url: '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings/{mapping}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CurriculumStructureController::statusCourseMapping
 * @see app/Http/Controllers/CurriculumStructureController.php:558
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings/{mapping}/status'
 */
statusCourseMapping.url = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                    term: args[1],
                    slot: args[2],
                    mapping: args[3],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                                term: typeof args.term === 'object'
                ? args.term.id
                : args.term,
                                slot: typeof args.slot === 'object'
                ? args.slot.id
                : args.slot,
                                mapping: typeof args.mapping === 'object'
                ? args.mapping.id
                : args.mapping,
                }

    return statusCourseMapping.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace('{term}', parsedArgs.term.toString())
            .replace('{slot}', parsedArgs.slot.toString())
            .replace('{mapping}', parsedArgs.mapping.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumStructureController::statusCourseMapping
 * @see app/Http/Controllers/CurriculumStructureController.php:558
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings/{mapping}/status'
 */
statusCourseMapping.patch = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: statusCourseMapping.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CurriculumStructureController::statusCourseMapping
 * @see app/Http/Controllers/CurriculumStructureController.php:558
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings/{mapping}/status'
 */
    const statusCourseMappingForm = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: statusCourseMapping.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CurriculumStructureController::statusCourseMapping
 * @see app/Http/Controllers/CurriculumStructureController.php:558
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings/{mapping}/status'
 */
        statusCourseMappingForm.patch = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: statusCourseMapping.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    statusCourseMapping.form = statusCourseMappingForm
/**
* @see \App\Http\Controllers\CurriculumStructureController::deleteCourseMapping
 * @see app/Http/Controllers/CurriculumStructureController.php:730
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings/{mapping}'
 */
export const deleteCourseMapping = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteCourseMapping.url(args, options),
    method: 'delete',
})

deleteCourseMapping.definition = {
    methods: ["delete"],
    url: '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings/{mapping}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CurriculumStructureController::deleteCourseMapping
 * @see app/Http/Controllers/CurriculumStructureController.php:730
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings/{mapping}'
 */
deleteCourseMapping.url = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                    term: args[1],
                    slot: args[2],
                    mapping: args[3],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                                term: typeof args.term === 'object'
                ? args.term.id
                : args.term,
                                slot: typeof args.slot === 'object'
                ? args.slot.id
                : args.slot,
                                mapping: typeof args.mapping === 'object'
                ? args.mapping.id
                : args.mapping,
                }

    return deleteCourseMapping.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace('{term}', parsedArgs.term.toString())
            .replace('{slot}', parsedArgs.slot.toString())
            .replace('{mapping}', parsedArgs.mapping.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumStructureController::deleteCourseMapping
 * @see app/Http/Controllers/CurriculumStructureController.php:730
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings/{mapping}'
 */
deleteCourseMapping.delete = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteCourseMapping.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CurriculumStructureController::deleteCourseMapping
 * @see app/Http/Controllers/CurriculumStructureController.php:730
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings/{mapping}'
 */
    const deleteCourseMappingForm = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: deleteCourseMapping.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CurriculumStructureController::deleteCourseMapping
 * @see app/Http/Controllers/CurriculumStructureController.php:730
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings/{mapping}'
 */
        deleteCourseMappingForm.delete = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: deleteCourseMapping.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    deleteCourseMapping.form = deleteCourseMappingForm
/**
* @see \App\Http\Controllers\CurriculumStructureController::updateCourseMappingOrder
 * @see app/Http/Controllers/CurriculumStructureController.php:590
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings/{mapping}/order'
 */
export const updateCourseMappingOrder = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateCourseMappingOrder.url(args, options),
    method: 'patch',
})

updateCourseMappingOrder.definition = {
    methods: ["patch"],
    url: '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings/{mapping}/order',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CurriculumStructureController::updateCourseMappingOrder
 * @see app/Http/Controllers/CurriculumStructureController.php:590
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings/{mapping}/order'
 */
updateCourseMappingOrder.url = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                    term: args[1],
                    slot: args[2],
                    mapping: args[3],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                                term: typeof args.term === 'object'
                ? args.term.id
                : args.term,
                                slot: typeof args.slot === 'object'
                ? args.slot.id
                : args.slot,
                                mapping: typeof args.mapping === 'object'
                ? args.mapping.id
                : args.mapping,
                }

    return updateCourseMappingOrder.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace('{term}', parsedArgs.term.toString())
            .replace('{slot}', parsedArgs.slot.toString())
            .replace('{mapping}', parsedArgs.mapping.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CurriculumStructureController::updateCourseMappingOrder
 * @see app/Http/Controllers/CurriculumStructureController.php:590
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings/{mapping}/order'
 */
updateCourseMappingOrder.patch = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateCourseMappingOrder.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CurriculumStructureController::updateCourseMappingOrder
 * @see app/Http/Controllers/CurriculumStructureController.php:590
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings/{mapping}/order'
 */
    const updateCourseMappingOrderForm = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateCourseMappingOrder.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CurriculumStructureController::updateCourseMappingOrder
 * @see app/Http/Controllers/CurriculumStructureController.php:590
 * @route '/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings/{mapping}/order'
 */
        updateCourseMappingOrderForm.patch = (args: { curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } } | [curriculum: number | { id: number }, term: number | { id: number }, slot: number | { id: number }, mapping: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateCourseMappingOrder.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateCourseMappingOrder.form = updateCourseMappingOrderForm
const CurriculumStructureController = { terms, cloneTargetTerms, storeTerm, cloneTerm, updateTerm, statusTerm, deleteTerm, slots, storeSlot, cloneSlot, updateSlot, statusSlot, deleteSlot, courseMappings, validateStructure, storeCourseMapping, updateCourseMapping, statusCourseMapping, deleteCourseMapping, updateCourseMappingOrder }

export default CurriculumStructureController