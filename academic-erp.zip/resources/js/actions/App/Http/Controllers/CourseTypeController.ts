import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CourseTypeController::index
 * @see app/Http/Controllers/CourseTypeController.php:18
 * @route '/admin/course-types'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/course-types',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CourseTypeController::index
 * @see app/Http/Controllers/CourseTypeController.php:18
 * @route '/admin/course-types'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CourseTypeController::index
 * @see app/Http/Controllers/CourseTypeController.php:18
 * @route '/admin/course-types'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CourseTypeController::index
 * @see app/Http/Controllers/CourseTypeController.php:18
 * @route '/admin/course-types'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CourseTypeController::index
 * @see app/Http/Controllers/CourseTypeController.php:18
 * @route '/admin/course-types'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CourseTypeController::index
 * @see app/Http/Controllers/CourseTypeController.php:18
 * @route '/admin/course-types'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CourseTypeController::index
 * @see app/Http/Controllers/CourseTypeController.php:18
 * @route '/admin/course-types'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CourseTypeController::store
 * @see app/Http/Controllers/CourseTypeController.php:33
 * @route '/admin/course-types'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/course-types',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CourseTypeController::store
 * @see app/Http/Controllers/CourseTypeController.php:33
 * @route '/admin/course-types'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CourseTypeController::store
 * @see app/Http/Controllers/CourseTypeController.php:33
 * @route '/admin/course-types'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CourseTypeController::store
 * @see app/Http/Controllers/CourseTypeController.php:33
 * @route '/admin/course-types'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CourseTypeController::store
 * @see app/Http/Controllers/CourseTypeController.php:33
 * @route '/admin/course-types'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CourseTypeController::update
 * @see app/Http/Controllers/CourseTypeController.php:51
 * @route '/admin/course-types/{courseType}'
 */
export const update = (args: { courseType: number | { id: number } } | [courseType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/course-types/{courseType}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CourseTypeController::update
 * @see app/Http/Controllers/CourseTypeController.php:51
 * @route '/admin/course-types/{courseType}'
 */
update.url = (args: { courseType: number | { id: number } } | [courseType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { courseType: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { courseType: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    courseType: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        courseType: typeof args.courseType === 'object'
                ? args.courseType.id
                : args.courseType,
                }

    return update.definition.url
            .replace('{courseType}', parsedArgs.courseType.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CourseTypeController::update
 * @see app/Http/Controllers/CourseTypeController.php:51
 * @route '/admin/course-types/{courseType}'
 */
update.patch = (args: { courseType: number | { id: number } } | [courseType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CourseTypeController::update
 * @see app/Http/Controllers/CourseTypeController.php:51
 * @route '/admin/course-types/{courseType}'
 */
    const updateForm = (args: { courseType: number | { id: number } } | [courseType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CourseTypeController::update
 * @see app/Http/Controllers/CourseTypeController.php:51
 * @route '/admin/course-types/{courseType}'
 */
        updateForm.patch = (args: { courseType: number | { id: number } } | [courseType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CourseTypeController::status
 * @see app/Http/Controllers/CourseTypeController.php:68
 * @route '/admin/course-types/{courseType}/status'
 */
export const status = (args: { courseType: number | { id: number } } | [courseType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

status.definition = {
    methods: ["patch"],
    url: '/admin/course-types/{courseType}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CourseTypeController::status
 * @see app/Http/Controllers/CourseTypeController.php:68
 * @route '/admin/course-types/{courseType}/status'
 */
status.url = (args: { courseType: number | { id: number } } | [courseType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { courseType: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { courseType: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    courseType: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        courseType: typeof args.courseType === 'object'
                ? args.courseType.id
                : args.courseType,
                }

    return status.definition.url
            .replace('{courseType}', parsedArgs.courseType.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CourseTypeController::status
 * @see app/Http/Controllers/CourseTypeController.php:68
 * @route '/admin/course-types/{courseType}/status'
 */
status.patch = (args: { courseType: number | { id: number } } | [courseType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CourseTypeController::status
 * @see app/Http/Controllers/CourseTypeController.php:68
 * @route '/admin/course-types/{courseType}/status'
 */
    const statusForm = (args: { courseType: number | { id: number } } | [courseType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: status.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CourseTypeController::status
 * @see app/Http/Controllers/CourseTypeController.php:68
 * @route '/admin/course-types/{courseType}/status'
 */
        statusForm.patch = (args: { courseType: number | { id: number } } | [courseType: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: status.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    status.form = statusForm
const CourseTypeController = { index, store, update, status }

export default CourseTypeController