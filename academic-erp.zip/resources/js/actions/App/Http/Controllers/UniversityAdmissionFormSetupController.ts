import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::index
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:29
 * @route '/admin/admission-form-setup'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/admission-form-setup',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::index
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:29
 * @route '/admin/admission-form-setup'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::index
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:29
 * @route '/admin/admission-form-setup'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::index
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:29
 * @route '/admin/admission-form-setup'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::index
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:29
 * @route '/admin/admission-form-setup'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::index
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:29
 * @route '/admin/admission-form-setup'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::index
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:29
 * @route '/admin/admission-form-setup'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::storeTemplate
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:82
 * @route '/admin/admission-form-setup/templates'
 */
export const storeTemplate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeTemplate.url(options),
    method: 'post',
})

storeTemplate.definition = {
    methods: ["post"],
    url: '/admin/admission-form-setup/templates',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::storeTemplate
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:82
 * @route '/admin/admission-form-setup/templates'
 */
storeTemplate.url = (options?: RouteQueryOptions) => {
    return storeTemplate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::storeTemplate
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:82
 * @route '/admin/admission-form-setup/templates'
 */
storeTemplate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeTemplate.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::storeTemplate
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:82
 * @route '/admin/admission-form-setup/templates'
 */
    const storeTemplateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeTemplate.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::storeTemplate
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:82
 * @route '/admin/admission-form-setup/templates'
 */
        storeTemplateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeTemplate.url(options),
            method: 'post',
        })
    
    storeTemplate.form = storeTemplateForm
/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::updateTemplate
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:214
 * @route '/admin/admission-form-setup/templates/{template}'
 */
export const updateTemplate = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateTemplate.url(args, options),
    method: 'patch',
})

updateTemplate.definition = {
    methods: ["patch"],
    url: '/admin/admission-form-setup/templates/{template}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::updateTemplate
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:214
 * @route '/admin/admission-form-setup/templates/{template}'
 */
updateTemplate.url = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { template: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { template: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    template: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                }

    return updateTemplate.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::updateTemplate
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:214
 * @route '/admin/admission-form-setup/templates/{template}'
 */
updateTemplate.patch = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateTemplate.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::updateTemplate
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:214
 * @route '/admin/admission-form-setup/templates/{template}'
 */
    const updateTemplateForm = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateTemplate.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::updateTemplate
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:214
 * @route '/admin/admission-form-setup/templates/{template}'
 */
        updateTemplateForm.patch = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateTemplate.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateTemplate.form = updateTemplateForm
/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::destroyTemplate
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:228
 * @route '/admin/admission-form-setup/templates/{template}'
 */
export const destroyTemplate = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyTemplate.url(args, options),
    method: 'delete',
})

destroyTemplate.definition = {
    methods: ["delete"],
    url: '/admin/admission-form-setup/templates/{template}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::destroyTemplate
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:228
 * @route '/admin/admission-form-setup/templates/{template}'
 */
destroyTemplate.url = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { template: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { template: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    template: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                }

    return destroyTemplate.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::destroyTemplate
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:228
 * @route '/admin/admission-form-setup/templates/{template}'
 */
destroyTemplate.delete = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyTemplate.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::destroyTemplate
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:228
 * @route '/admin/admission-form-setup/templates/{template}'
 */
    const destroyTemplateForm = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyTemplate.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::destroyTemplate
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:228
 * @route '/admin/admission-form-setup/templates/{template}'
 */
        destroyTemplateForm.delete = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyTemplate.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyTemplate.form = destroyTemplateForm
/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::overrideControl
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:111
 * @route '/admin/admission-form-setup/templates/{template}/override-control'
 */
export const overrideControl = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: overrideControl.url(args, options),
    method: 'patch',
})

overrideControl.definition = {
    methods: ["patch"],
    url: '/admin/admission-form-setup/templates/{template}/override-control',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::overrideControl
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:111
 * @route '/admin/admission-form-setup/templates/{template}/override-control'
 */
overrideControl.url = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { template: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { template: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    template: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                }

    return overrideControl.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::overrideControl
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:111
 * @route '/admin/admission-form-setup/templates/{template}/override-control'
 */
overrideControl.patch = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: overrideControl.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::overrideControl
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:111
 * @route '/admin/admission-form-setup/templates/{template}/override-control'
 */
    const overrideControlForm = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: overrideControl.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::overrideControl
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:111
 * @route '/admin/admission-form-setup/templates/{template}/override-control'
 */
        overrideControlForm.patch = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: overrideControl.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    overrideControl.form = overrideControlForm
/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::statusTemplate
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:136
 * @route '/admin/admission-form-setup/templates/{template}/status'
 */
export const statusTemplate = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: statusTemplate.url(args, options),
    method: 'patch',
})

statusTemplate.definition = {
    methods: ["patch"],
    url: '/admin/admission-form-setup/templates/{template}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::statusTemplate
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:136
 * @route '/admin/admission-form-setup/templates/{template}/status'
 */
statusTemplate.url = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { template: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { template: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    template: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                }

    return statusTemplate.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::statusTemplate
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:136
 * @route '/admin/admission-form-setup/templates/{template}/status'
 */
statusTemplate.patch = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: statusTemplate.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::statusTemplate
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:136
 * @route '/admin/admission-form-setup/templates/{template}/status'
 */
    const statusTemplateForm = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: statusTemplate.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::statusTemplate
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:136
 * @route '/admin/admission-form-setup/templates/{template}/status'
 */
        statusTemplateForm.patch = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: statusTemplate.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    statusTemplate.form = statusTemplateForm
/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::updateStep
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:237
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}'
 */
export const updateStep = (args: { template: number | { id: number }, step: number | { id: number } } | [template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStep.url(args, options),
    method: 'patch',
})

updateStep.definition = {
    methods: ["patch"],
    url: '/admin/admission-form-setup/templates/{template}/steps/{step}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::updateStep
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:237
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}'
 */
updateStep.url = (args: { template: number | { id: number }, step: number | { id: number } } | [template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    template: args[0],
                    step: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                                step: typeof args.step === 'object'
                ? args.step.id
                : args.step,
                }

    return updateStep.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace('{step}', parsedArgs.step.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::updateStep
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:237
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}'
 */
updateStep.patch = (args: { template: number | { id: number }, step: number | { id: number } } | [template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStep.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::updateStep
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:237
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}'
 */
    const updateStepForm = (args: { template: number | { id: number }, step: number | { id: number } } | [template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateStep.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::updateStep
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:237
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}'
 */
        updateStepForm.patch = (args: { template: number | { id: number }, step: number | { id: number } } | [template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateStep.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateStep.form = updateStepForm
/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::destroyStep
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:246
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}'
 */
export const destroyStep = (args: { template: number | { id: number }, step: number | { id: number } } | [template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyStep.url(args, options),
    method: 'delete',
})

destroyStep.definition = {
    methods: ["delete"],
    url: '/admin/admission-form-setup/templates/{template}/steps/{step}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::destroyStep
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:246
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}'
 */
destroyStep.url = (args: { template: number | { id: number }, step: number | { id: number } } | [template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    template: args[0],
                    step: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                                step: typeof args.step === 'object'
                ? args.step.id
                : args.step,
                }

    return destroyStep.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace('{step}', parsedArgs.step.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::destroyStep
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:246
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}'
 */
destroyStep.delete = (args: { template: number | { id: number }, step: number | { id: number } } | [template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyStep.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::destroyStep
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:246
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}'
 */
    const destroyStepForm = (args: { template: number | { id: number }, step: number | { id: number } } | [template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyStep.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::destroyStep
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:246
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}'
 */
        destroyStepForm.delete = (args: { template: number | { id: number }, step: number | { id: number } } | [template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyStep.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyStep.form = destroyStepForm
/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::storePanel
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:253
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/panels'
 */
export const storePanel = (args: { template: number | { id: number }, step: number | { id: number } } | [template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storePanel.url(args, options),
    method: 'post',
})

storePanel.definition = {
    methods: ["post"],
    url: '/admin/admission-form-setup/templates/{template}/steps/{step}/panels',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::storePanel
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:253
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/panels'
 */
storePanel.url = (args: { template: number | { id: number }, step: number | { id: number } } | [template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    template: args[0],
                    step: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                                step: typeof args.step === 'object'
                ? args.step.id
                : args.step,
                }

    return storePanel.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace('{step}', parsedArgs.step.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::storePanel
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:253
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/panels'
 */
storePanel.post = (args: { template: number | { id: number }, step: number | { id: number } } | [template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storePanel.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::storePanel
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:253
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/panels'
 */
    const storePanelForm = (args: { template: number | { id: number }, step: number | { id: number } } | [template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storePanel.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::storePanel
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:253
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/panels'
 */
        storePanelForm.post = (args: { template: number | { id: number }, step: number | { id: number } } | [template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storePanel.url(args, options),
            method: 'post',
        })
    
    storePanel.form = storePanelForm
/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::updatePanel
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:262
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/panels/{panel}'
 */
export const updatePanel = (args: { template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } } | [template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updatePanel.url(args, options),
    method: 'patch',
})

updatePanel.definition = {
    methods: ["patch"],
    url: '/admin/admission-form-setup/templates/{template}/steps/{step}/panels/{panel}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::updatePanel
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:262
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/panels/{panel}'
 */
updatePanel.url = (args: { template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } } | [template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    template: args[0],
                    step: args[1],
                    panel: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                                step: typeof args.step === 'object'
                ? args.step.id
                : args.step,
                                panel: typeof args.panel === 'object'
                ? args.panel.id
                : args.panel,
                }

    return updatePanel.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace('{step}', parsedArgs.step.toString())
            .replace('{panel}', parsedArgs.panel.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::updatePanel
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:262
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/panels/{panel}'
 */
updatePanel.patch = (args: { template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } } | [template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updatePanel.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::updatePanel
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:262
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/panels/{panel}'
 */
    const updatePanelForm = (args: { template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } } | [template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updatePanel.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::updatePanel
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:262
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/panels/{panel}'
 */
        updatePanelForm.patch = (args: { template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } } | [template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updatePanel.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updatePanel.form = updatePanelForm
/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::destroyPanel
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:270
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/panels/{panel}'
 */
export const destroyPanel = (args: { template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } } | [template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyPanel.url(args, options),
    method: 'delete',
})

destroyPanel.definition = {
    methods: ["delete"],
    url: '/admin/admission-form-setup/templates/{template}/steps/{step}/panels/{panel}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::destroyPanel
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:270
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/panels/{panel}'
 */
destroyPanel.url = (args: { template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } } | [template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    template: args[0],
                    step: args[1],
                    panel: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                                step: typeof args.step === 'object'
                ? args.step.id
                : args.step,
                                panel: typeof args.panel === 'object'
                ? args.panel.id
                : args.panel,
                }

    return destroyPanel.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace('{step}', parsedArgs.step.toString())
            .replace('{panel}', parsedArgs.panel.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::destroyPanel
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:270
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/panels/{panel}'
 */
destroyPanel.delete = (args: { template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } } | [template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyPanel.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::destroyPanel
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:270
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/panels/{panel}'
 */
    const destroyPanelForm = (args: { template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } } | [template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyPanel.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::destroyPanel
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:270
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/panels/{panel}'
 */
        destroyPanelForm.delete = (args: { template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } } | [template: number | { id: number }, step: number | { id: number }, panel: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyPanel.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyPanel.form = destroyPanelForm
/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::storeStep
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:152
 * @route '/admin/admission-form-setup/templates/{template}/steps'
 */
export const storeStep = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeStep.url(args, options),
    method: 'post',
})

storeStep.definition = {
    methods: ["post"],
    url: '/admin/admission-form-setup/templates/{template}/steps',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::storeStep
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:152
 * @route '/admin/admission-form-setup/templates/{template}/steps'
 */
storeStep.url = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { template: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { template: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    template: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                }

    return storeStep.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::storeStep
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:152
 * @route '/admin/admission-form-setup/templates/{template}/steps'
 */
storeStep.post = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeStep.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::storeStep
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:152
 * @route '/admin/admission-form-setup/templates/{template}/steps'
 */
    const storeStepForm = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeStep.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::storeStep
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:152
 * @route '/admin/admission-form-setup/templates/{template}/steps'
 */
        storeStepForm.post = (args: { template: number | { id: number } } | [template: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeStep.url(args, options),
            method: 'post',
        })
    
    storeStep.form = storeStepForm
/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::storeField
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:165
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/fields'
 */
export const storeField = (args: { template: number | { id: number }, step: number | { id: number } } | [template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeField.url(args, options),
    method: 'post',
})

storeField.definition = {
    methods: ["post"],
    url: '/admin/admission-form-setup/templates/{template}/steps/{step}/fields',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::storeField
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:165
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/fields'
 */
storeField.url = (args: { template: number | { id: number }, step: number | { id: number } } | [template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    template: args[0],
                    step: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                                step: typeof args.step === 'object'
                ? args.step.id
                : args.step,
                }

    return storeField.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace('{step}', parsedArgs.step.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::storeField
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:165
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/fields'
 */
storeField.post = (args: { template: number | { id: number }, step: number | { id: number } } | [template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeField.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::storeField
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:165
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/fields'
 */
    const storeFieldForm = (args: { template: number | { id: number }, step: number | { id: number } } | [template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeField.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::storeField
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:165
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/fields'
 */
        storeFieldForm.post = (args: { template: number | { id: number }, step: number | { id: number } } | [template: number | { id: number }, step: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeField.url(args, options),
            method: 'post',
        })
    
    storeField.form = storeFieldForm
/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::updateField
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:277
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/fields/{field}'
 */
export const updateField = (args: { template: number | { id: number }, step: number | { id: number }, field: number | { id: number } } | [template: number | { id: number }, step: number | { id: number }, field: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateField.url(args, options),
    method: 'patch',
})

updateField.definition = {
    methods: ["patch"],
    url: '/admin/admission-form-setup/templates/{template}/steps/{step}/fields/{field}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::updateField
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:277
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/fields/{field}'
 */
updateField.url = (args: { template: number | { id: number }, step: number | { id: number }, field: number | { id: number } } | [template: number | { id: number }, step: number | { id: number }, field: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    template: args[0],
                    step: args[1],
                    field: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                                step: typeof args.step === 'object'
                ? args.step.id
                : args.step,
                                field: typeof args.field === 'object'
                ? args.field.id
                : args.field,
                }

    return updateField.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace('{step}', parsedArgs.step.toString())
            .replace('{field}', parsedArgs.field.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::updateField
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:277
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/fields/{field}'
 */
updateField.patch = (args: { template: number | { id: number }, step: number | { id: number }, field: number | { id: number } } | [template: number | { id: number }, step: number | { id: number }, field: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateField.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::updateField
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:277
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/fields/{field}'
 */
    const updateFieldForm = (args: { template: number | { id: number }, step: number | { id: number }, field: number | { id: number } } | [template: number | { id: number }, step: number | { id: number }, field: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateField.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::updateField
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:277
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/fields/{field}'
 */
        updateFieldForm.patch = (args: { template: number | { id: number }, step: number | { id: number }, field: number | { id: number } } | [template: number | { id: number }, step: number | { id: number }, field: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateField.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateField.form = updateFieldForm
/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::destroyField
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:286
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/fields/{field}'
 */
export const destroyField = (args: { template: number | { id: number }, step: number | { id: number }, field: number | { id: number } } | [template: number | { id: number }, step: number | { id: number }, field: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyField.url(args, options),
    method: 'delete',
})

destroyField.definition = {
    methods: ["delete"],
    url: '/admin/admission-form-setup/templates/{template}/steps/{step}/fields/{field}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::destroyField
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:286
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/fields/{field}'
 */
destroyField.url = (args: { template: number | { id: number }, step: number | { id: number }, field: number | { id: number } } | [template: number | { id: number }, step: number | { id: number }, field: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    template: args[0],
                    step: args[1],
                    field: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        template: typeof args.template === 'object'
                ? args.template.id
                : args.template,
                                step: typeof args.step === 'object'
                ? args.step.id
                : args.step,
                                field: typeof args.field === 'object'
                ? args.field.id
                : args.field,
                }

    return destroyField.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace('{step}', parsedArgs.step.toString())
            .replace('{field}', parsedArgs.field.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::destroyField
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:286
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/fields/{field}'
 */
destroyField.delete = (args: { template: number | { id: number }, step: number | { id: number }, field: number | { id: number } } | [template: number | { id: number }, step: number | { id: number }, field: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyField.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::destroyField
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:286
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/fields/{field}'
 */
    const destroyFieldForm = (args: { template: number | { id: number }, step: number | { id: number }, field: number | { id: number } } | [template: number | { id: number }, step: number | { id: number }, field: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyField.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::destroyField
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:286
 * @route '/admin/admission-form-setup/templates/{template}/steps/{step}/fields/{field}'
 */
        destroyFieldForm.delete = (args: { template: number | { id: number }, step: number | { id: number }, field: number | { id: number } } | [template: number | { id: number }, step: number | { id: number }, field: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyField.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyField.form = destroyFieldForm
/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::storeFeeRule
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:299
 * @route '/admin/admission-form-setup/fee-rules'
 */
export const storeFeeRule = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeFeeRule.url(options),
    method: 'post',
})

storeFeeRule.definition = {
    methods: ["post"],
    url: '/admin/admission-form-setup/fee-rules',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::storeFeeRule
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:299
 * @route '/admin/admission-form-setup/fee-rules'
 */
storeFeeRule.url = (options?: RouteQueryOptions) => {
    return storeFeeRule.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::storeFeeRule
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:299
 * @route '/admin/admission-form-setup/fee-rules'
 */
storeFeeRule.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeFeeRule.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::storeFeeRule
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:299
 * @route '/admin/admission-form-setup/fee-rules'
 */
    const storeFeeRuleForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeFeeRule.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UniversityAdmissionFormSetupController::storeFeeRule
 * @see app/Http/Controllers/UniversityAdmissionFormSetupController.php:299
 * @route '/admin/admission-form-setup/fee-rules'
 */
        storeFeeRuleForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeFeeRule.url(options),
            method: 'post',
        })
    
    storeFeeRule.form = storeFeeRuleForm
const UniversityAdmissionFormSetupController = { index, storeTemplate, updateTemplate, destroyTemplate, overrideControl, statusTemplate, updateStep, destroyStep, storePanel, updatePanel, destroyPanel, storeStep, storeField, updateField, destroyField, storeFeeRule }

export default UniversityAdmissionFormSetupController