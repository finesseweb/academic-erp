import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::index
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:25
 * @route '/college/{college}/admission-applications'
 */
export const index = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/college/{college}/admission-applications',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::index
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:25
 * @route '/college/{college}/admission-applications'
 */
index.url = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { college: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { college: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                }

    return index.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::index
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:25
 * @route '/college/{college}/admission-applications'
 */
index.get = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::index
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:25
 * @route '/college/{college}/admission-applications'
 */
index.head = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::index
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:25
 * @route '/college/{college}/admission-applications'
 */
    const indexForm = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::index
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:25
 * @route '/college/{college}/admission-applications'
 */
        indexForm.get = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::index
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:25
 * @route '/college/{college}/admission-applications'
 */
        indexForm.head = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::store
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:196
 * @route '/college/{college}/admission-applications'
 */
export const store = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/college/{college}/admission-applications',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::store
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:196
 * @route '/college/{college}/admission-applications'
 */
store.url = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { college: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { college: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                }

    return store.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::store
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:196
 * @route '/college/{college}/admission-applications'
 */
store.post = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::store
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:196
 * @route '/college/{college}/admission-applications'
 */
    const storeForm = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::store
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:196
 * @route '/college/{college}/admission-applications'
 */
        storeForm.post = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::update
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:202
 * @route '/college/{college}/admission-applications/{application}'
 */
export const update = (args: { college: number | { id: number }, application: number | { id: number } } | [college: number | { id: number }, application: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/college/{college}/admission-applications/{application}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::update
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:202
 * @route '/college/{college}/admission-applications/{application}'
 */
update.url = (args: { college: number | { id: number }, application: number | { id: number } } | [college: number | { id: number }, application: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    application: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                application: typeof args.application === 'object'
                ? args.application.id
                : args.application,
                }

    return update.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::update
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:202
 * @route '/college/{college}/admission-applications/{application}'
 */
update.patch = (args: { college: number | { id: number }, application: number | { id: number } } | [college: number | { id: number }, application: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::update
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:202
 * @route '/college/{college}/admission-applications/{application}'
 */
    const updateForm = (args: { college: number | { id: number }, application: number | { id: number } } | [college: number | { id: number }, application: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::update
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:202
 * @route '/college/{college}/admission-applications/{application}'
 */
        updateForm.patch = (args: { college: number | { id: number }, application: number | { id: number } } | [college: number | { id: number }, application: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::submit
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:208
 * @route '/college/{college}/admission-applications/{application}/submit'
 */
export const submit = (args: { college: number | { id: number }, application: number | { id: number } } | [college: number | { id: number }, application: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: submit.url(args, options),
    method: 'patch',
})

submit.definition = {
    methods: ["patch"],
    url: '/college/{college}/admission-applications/{application}/submit',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::submit
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:208
 * @route '/college/{college}/admission-applications/{application}/submit'
 */
submit.url = (args: { college: number | { id: number }, application: number | { id: number } } | [college: number | { id: number }, application: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    application: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                application: typeof args.application === 'object'
                ? args.application.id
                : args.application,
                }

    return submit.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::submit
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:208
 * @route '/college/{college}/admission-applications/{application}/submit'
 */
submit.patch = (args: { college: number | { id: number }, application: number | { id: number } } | [college: number | { id: number }, application: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: submit.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::submit
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:208
 * @route '/college/{college}/admission-applications/{application}/submit'
 */
    const submitForm = (args: { college: number | { id: number }, application: number | { id: number } } | [college: number | { id: number }, application: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: submit.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::submit
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:208
 * @route '/college/{college}/admission-applications/{application}/submit'
 */
        submitForm.patch = (args: { college: number | { id: number }, application: number | { id: number } } | [college: number | { id: number }, application: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: submit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    submit.form = submitForm
/**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::eligibility
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:218
 * @route '/college/{college}/admission-application-choices/{choice}/eligibility'
 */
export const eligibility = (args: { college: number | { id: number }, choice: number | { id: number } } | [college: number | { id: number }, choice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: eligibility.url(args, options),
    method: 'patch',
})

eligibility.definition = {
    methods: ["patch"],
    url: '/college/{college}/admission-application-choices/{choice}/eligibility',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::eligibility
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:218
 * @route '/college/{college}/admission-application-choices/{choice}/eligibility'
 */
eligibility.url = (args: { college: number | { id: number }, choice: number | { id: number } } | [college: number | { id: number }, choice: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    choice: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                choice: typeof args.choice === 'object'
                ? args.choice.id
                : args.choice,
                }

    return eligibility.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{choice}', parsedArgs.choice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::eligibility
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:218
 * @route '/college/{college}/admission-application-choices/{choice}/eligibility'
 */
eligibility.patch = (args: { college: number | { id: number }, choice: number | { id: number } } | [college: number | { id: number }, choice: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: eligibility.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::eligibility
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:218
 * @route '/college/{college}/admission-application-choices/{choice}/eligibility'
 */
    const eligibilityForm = (args: { college: number | { id: number }, choice: number | { id: number } } | [college: number | { id: number }, choice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: eligibility.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::eligibility
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:218
 * @route '/college/{college}/admission-application-choices/{choice}/eligibility'
 */
        eligibilityForm.patch = (args: { college: number | { id: number }, choice: number | { id: number } } | [college: number | { id: number }, choice: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: eligibility.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    eligibility.form = eligibilityForm
/**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::withdraw
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:229
 * @route '/college/{college}/admission-applications/{application}/withdraw'
 */
export const withdraw = (args: { college: number | { id: number }, application: number | { id: number } } | [college: number | { id: number }, application: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: withdraw.url(args, options),
    method: 'patch',
})

withdraw.definition = {
    methods: ["patch"],
    url: '/college/{college}/admission-applications/{application}/withdraw',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::withdraw
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:229
 * @route '/college/{college}/admission-applications/{application}/withdraw'
 */
withdraw.url = (args: { college: number | { id: number }, application: number | { id: number } } | [college: number | { id: number }, application: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    application: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                application: typeof args.application === 'object'
                ? args.application.id
                : args.application,
                }

    return withdraw.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::withdraw
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:229
 * @route '/college/{college}/admission-applications/{application}/withdraw'
 */
withdraw.patch = (args: { college: number | { id: number }, application: number | { id: number } } | [college: number | { id: number }, application: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: withdraw.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::withdraw
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:229
 * @route '/college/{college}/admission-applications/{application}/withdraw'
 */
    const withdrawForm = (args: { college: number | { id: number }, application: number | { id: number } } | [college: number | { id: number }, application: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: withdraw.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeAdmissionApplicationController::withdraw
 * @see app/Http/Controllers/CollegeAdmissionApplicationController.php:229
 * @route '/college/{college}/admission-applications/{application}/withdraw'
 */
        withdrawForm.patch = (args: { college: number | { id: number }, application: number | { id: number } } | [college: number | { id: number }, application: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: withdraw.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    withdraw.form = withdrawForm
const CollegeAdmissionApplicationController = { index, store, update, submit, eligibility, withdraw }

export default CollegeAdmissionApplicationController