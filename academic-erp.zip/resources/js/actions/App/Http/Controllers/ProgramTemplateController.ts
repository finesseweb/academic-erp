import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ProgramTemplateController::index
 * @see app/Http/Controllers/ProgramTemplateController.php:23
 * @route '/admin/program-templates'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/program-templates',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ProgramTemplateController::index
 * @see app/Http/Controllers/ProgramTemplateController.php:23
 * @route '/admin/program-templates'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProgramTemplateController::index
 * @see app/Http/Controllers/ProgramTemplateController.php:23
 * @route '/admin/program-templates'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ProgramTemplateController::index
 * @see app/Http/Controllers/ProgramTemplateController.php:23
 * @route '/admin/program-templates'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ProgramTemplateController::index
 * @see app/Http/Controllers/ProgramTemplateController.php:23
 * @route '/admin/program-templates'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ProgramTemplateController::index
 * @see app/Http/Controllers/ProgramTemplateController.php:23
 * @route '/admin/program-templates'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ProgramTemplateController::index
 * @see app/Http/Controllers/ProgramTemplateController.php:23
 * @route '/admin/program-templates'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ProgramTemplateController::store
 * @see app/Http/Controllers/ProgramTemplateController.php:61
 * @route '/admin/program-templates'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/program-templates',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProgramTemplateController::store
 * @see app/Http/Controllers/ProgramTemplateController.php:61
 * @route '/admin/program-templates'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProgramTemplateController::store
 * @see app/Http/Controllers/ProgramTemplateController.php:61
 * @route '/admin/program-templates'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ProgramTemplateController::store
 * @see app/Http/Controllers/ProgramTemplateController.php:61
 * @route '/admin/program-templates'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProgramTemplateController::store
 * @see app/Http/Controllers/ProgramTemplateController.php:61
 * @route '/admin/program-templates'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ProgramTemplateController::update
 * @see app/Http/Controllers/ProgramTemplateController.php:92
 * @route '/admin/program-templates/{programTemplate}'
 */
export const update = (args: { programTemplate: number | { id: number } } | [programTemplate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/program-templates/{programTemplate}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\ProgramTemplateController::update
 * @see app/Http/Controllers/ProgramTemplateController.php:92
 * @route '/admin/program-templates/{programTemplate}'
 */
update.url = (args: { programTemplate: number | { id: number } } | [programTemplate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { programTemplate: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { programTemplate: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    programTemplate: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        programTemplate: typeof args.programTemplate === 'object'
                ? args.programTemplate.id
                : args.programTemplate,
                }

    return update.definition.url
            .replace('{programTemplate}', parsedArgs.programTemplate.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProgramTemplateController::update
 * @see app/Http/Controllers/ProgramTemplateController.php:92
 * @route '/admin/program-templates/{programTemplate}'
 */
update.patch = (args: { programTemplate: number | { id: number } } | [programTemplate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\ProgramTemplateController::update
 * @see app/Http/Controllers/ProgramTemplateController.php:92
 * @route '/admin/program-templates/{programTemplate}'
 */
    const updateForm = (args: { programTemplate: number | { id: number } } | [programTemplate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProgramTemplateController::update
 * @see app/Http/Controllers/ProgramTemplateController.php:92
 * @route '/admin/program-templates/{programTemplate}'
 */
        updateForm.patch = (args: { programTemplate: number | { id: number } } | [programTemplate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\ProgramTemplateController::status
 * @see app/Http/Controllers/ProgramTemplateController.php:115
 * @route '/admin/program-templates/{programTemplate}/status'
 */
export const status = (args: { programTemplate: number | { id: number } } | [programTemplate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

status.definition = {
    methods: ["patch"],
    url: '/admin/program-templates/{programTemplate}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\ProgramTemplateController::status
 * @see app/Http/Controllers/ProgramTemplateController.php:115
 * @route '/admin/program-templates/{programTemplate}/status'
 */
status.url = (args: { programTemplate: number | { id: number } } | [programTemplate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { programTemplate: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { programTemplate: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    programTemplate: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        programTemplate: typeof args.programTemplate === 'object'
                ? args.programTemplate.id
                : args.programTemplate,
                }

    return status.definition.url
            .replace('{programTemplate}', parsedArgs.programTemplate.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProgramTemplateController::status
 * @see app/Http/Controllers/ProgramTemplateController.php:115
 * @route '/admin/program-templates/{programTemplate}/status'
 */
status.patch = (args: { programTemplate: number | { id: number } } | [programTemplate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\ProgramTemplateController::status
 * @see app/Http/Controllers/ProgramTemplateController.php:115
 * @route '/admin/program-templates/{programTemplate}/status'
 */
    const statusForm = (args: { programTemplate: number | { id: number } } | [programTemplate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: status.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProgramTemplateController::status
 * @see app/Http/Controllers/ProgramTemplateController.php:115
 * @route '/admin/program-templates/{programTemplate}/status'
 */
        statusForm.patch = (args: { programTemplate: number | { id: number } } | [programTemplate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: status.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    status.form = statusForm
const ProgramTemplateController = { index, store, update, status }

export default ProgramTemplateController