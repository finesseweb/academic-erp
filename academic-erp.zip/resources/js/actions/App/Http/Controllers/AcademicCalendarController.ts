import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AcademicCalendarController::index
 * @see app/Http/Controllers/AcademicCalendarController.php:24
 * @route '/admin/academic-calendars'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/academic-calendars',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AcademicCalendarController::index
 * @see app/Http/Controllers/AcademicCalendarController.php:24
 * @route '/admin/academic-calendars'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AcademicCalendarController::index
 * @see app/Http/Controllers/AcademicCalendarController.php:24
 * @route '/admin/academic-calendars'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AcademicCalendarController::index
 * @see app/Http/Controllers/AcademicCalendarController.php:24
 * @route '/admin/academic-calendars'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AcademicCalendarController::index
 * @see app/Http/Controllers/AcademicCalendarController.php:24
 * @route '/admin/academic-calendars'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AcademicCalendarController::index
 * @see app/Http/Controllers/AcademicCalendarController.php:24
 * @route '/admin/academic-calendars'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AcademicCalendarController::index
 * @see app/Http/Controllers/AcademicCalendarController.php:24
 * @route '/admin/academic-calendars'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\AcademicCalendarController::store
 * @see app/Http/Controllers/AcademicCalendarController.php:64
 * @route '/admin/academic-calendars'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/academic-calendars',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AcademicCalendarController::store
 * @see app/Http/Controllers/AcademicCalendarController.php:64
 * @route '/admin/academic-calendars'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AcademicCalendarController::store
 * @see app/Http/Controllers/AcademicCalendarController.php:64
 * @route '/admin/academic-calendars'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AcademicCalendarController::store
 * @see app/Http/Controllers/AcademicCalendarController.php:64
 * @route '/admin/academic-calendars'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AcademicCalendarController::store
 * @see app/Http/Controllers/AcademicCalendarController.php:64
 * @route '/admin/academic-calendars'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\AcademicCalendarController::update
 * @see app/Http/Controllers/AcademicCalendarController.php:78
 * @route '/admin/academic-calendars/{academicCalendar}'
 */
export const update = (args: { academicCalendar: number | { id: number } } | [academicCalendar: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/admin/academic-calendars/{academicCalendar}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\AcademicCalendarController::update
 * @see app/Http/Controllers/AcademicCalendarController.php:78
 * @route '/admin/academic-calendars/{academicCalendar}'
 */
update.url = (args: { academicCalendar: number | { id: number } } | [academicCalendar: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { academicCalendar: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { academicCalendar: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    academicCalendar: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        academicCalendar: typeof args.academicCalendar === 'object'
                ? args.academicCalendar.id
                : args.academicCalendar,
                }

    return update.definition.url
            .replace('{academicCalendar}', parsedArgs.academicCalendar.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AcademicCalendarController::update
 * @see app/Http/Controllers/AcademicCalendarController.php:78
 * @route '/admin/academic-calendars/{academicCalendar}'
 */
update.patch = (args: { academicCalendar: number | { id: number } } | [academicCalendar: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\AcademicCalendarController::update
 * @see app/Http/Controllers/AcademicCalendarController.php:78
 * @route '/admin/academic-calendars/{academicCalendar}'
 */
    const updateForm = (args: { academicCalendar: number | { id: number } } | [academicCalendar: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AcademicCalendarController::update
 * @see app/Http/Controllers/AcademicCalendarController.php:78
 * @route '/admin/academic-calendars/{academicCalendar}'
 */
        updateForm.patch = (args: { academicCalendar: number | { id: number } } | [academicCalendar: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\AcademicCalendarController::status
 * @see app/Http/Controllers/AcademicCalendarController.php:89
 * @route '/admin/academic-calendars/{academicCalendar}/status'
 */
export const status = (args: { academicCalendar: number | { id: number } } | [academicCalendar: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

status.definition = {
    methods: ["patch"],
    url: '/admin/academic-calendars/{academicCalendar}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\AcademicCalendarController::status
 * @see app/Http/Controllers/AcademicCalendarController.php:89
 * @route '/admin/academic-calendars/{academicCalendar}/status'
 */
status.url = (args: { academicCalendar: number | { id: number } } | [academicCalendar: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { academicCalendar: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { academicCalendar: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    academicCalendar: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        academicCalendar: typeof args.academicCalendar === 'object'
                ? args.academicCalendar.id
                : args.academicCalendar,
                }

    return status.definition.url
            .replace('{academicCalendar}', parsedArgs.academicCalendar.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AcademicCalendarController::status
 * @see app/Http/Controllers/AcademicCalendarController.php:89
 * @route '/admin/academic-calendars/{academicCalendar}/status'
 */
status.patch = (args: { academicCalendar: number | { id: number } } | [academicCalendar: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\AcademicCalendarController::status
 * @see app/Http/Controllers/AcademicCalendarController.php:89
 * @route '/admin/academic-calendars/{academicCalendar}/status'
 */
    const statusForm = (args: { academicCalendar: number | { id: number } } | [academicCalendar: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: status.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AcademicCalendarController::status
 * @see app/Http/Controllers/AcademicCalendarController.php:89
 * @route '/admin/academic-calendars/{academicCalendar}/status'
 */
        statusForm.patch = (args: { academicCalendar: number | { id: number } } | [academicCalendar: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: status.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    status.form = statusForm
/**
* @see \App\Http\Controllers\AcademicCalendarController::storeEvent
 * @see app/Http/Controllers/AcademicCalendarController.php:99
 * @route '/admin/academic-calendars/{academicCalendar}/events'
 */
export const storeEvent = (args: { academicCalendar: number | { id: number } } | [academicCalendar: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeEvent.url(args, options),
    method: 'post',
})

storeEvent.definition = {
    methods: ["post"],
    url: '/admin/academic-calendars/{academicCalendar}/events',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AcademicCalendarController::storeEvent
 * @see app/Http/Controllers/AcademicCalendarController.php:99
 * @route '/admin/academic-calendars/{academicCalendar}/events'
 */
storeEvent.url = (args: { academicCalendar: number | { id: number } } | [academicCalendar: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { academicCalendar: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { academicCalendar: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    academicCalendar: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        academicCalendar: typeof args.academicCalendar === 'object'
                ? args.academicCalendar.id
                : args.academicCalendar,
                }

    return storeEvent.definition.url
            .replace('{academicCalendar}', parsedArgs.academicCalendar.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AcademicCalendarController::storeEvent
 * @see app/Http/Controllers/AcademicCalendarController.php:99
 * @route '/admin/academic-calendars/{academicCalendar}/events'
 */
storeEvent.post = (args: { academicCalendar: number | { id: number } } | [academicCalendar: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeEvent.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AcademicCalendarController::storeEvent
 * @see app/Http/Controllers/AcademicCalendarController.php:99
 * @route '/admin/academic-calendars/{academicCalendar}/events'
 */
    const storeEventForm = (args: { academicCalendar: number | { id: number } } | [academicCalendar: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeEvent.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AcademicCalendarController::storeEvent
 * @see app/Http/Controllers/AcademicCalendarController.php:99
 * @route '/admin/academic-calendars/{academicCalendar}/events'
 */
        storeEventForm.post = (args: { academicCalendar: number | { id: number } } | [academicCalendar: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeEvent.url(args, options),
            method: 'post',
        })
    
    storeEvent.form = storeEventForm
/**
* @see \App\Http\Controllers\AcademicCalendarController::updateEvent
 * @see app/Http/Controllers/AcademicCalendarController.php:107
 * @route '/admin/academic-calendars/{academicCalendar}/events/{event}'
 */
export const updateEvent = (args: { academicCalendar: number | { id: number }, event: number | { id: number } } | [academicCalendar: number | { id: number }, event: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateEvent.url(args, options),
    method: 'patch',
})

updateEvent.definition = {
    methods: ["patch"],
    url: '/admin/academic-calendars/{academicCalendar}/events/{event}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\AcademicCalendarController::updateEvent
 * @see app/Http/Controllers/AcademicCalendarController.php:107
 * @route '/admin/academic-calendars/{academicCalendar}/events/{event}'
 */
updateEvent.url = (args: { academicCalendar: number | { id: number }, event: number | { id: number } } | [academicCalendar: number | { id: number }, event: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    academicCalendar: args[0],
                    event: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        academicCalendar: typeof args.academicCalendar === 'object'
                ? args.academicCalendar.id
                : args.academicCalendar,
                                event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return updateEvent.definition.url
            .replace('{academicCalendar}', parsedArgs.academicCalendar.toString())
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AcademicCalendarController::updateEvent
 * @see app/Http/Controllers/AcademicCalendarController.php:107
 * @route '/admin/academic-calendars/{academicCalendar}/events/{event}'
 */
updateEvent.patch = (args: { academicCalendar: number | { id: number }, event: number | { id: number } } | [academicCalendar: number | { id: number }, event: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateEvent.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\AcademicCalendarController::updateEvent
 * @see app/Http/Controllers/AcademicCalendarController.php:107
 * @route '/admin/academic-calendars/{academicCalendar}/events/{event}'
 */
    const updateEventForm = (args: { academicCalendar: number | { id: number }, event: number | { id: number } } | [academicCalendar: number | { id: number }, event: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateEvent.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AcademicCalendarController::updateEvent
 * @see app/Http/Controllers/AcademicCalendarController.php:107
 * @route '/admin/academic-calendars/{academicCalendar}/events/{event}'
 */
        updateEventForm.patch = (args: { academicCalendar: number | { id: number }, event: number | { id: number } } | [academicCalendar: number | { id: number }, event: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateEvent.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateEvent.form = updateEventForm
/**
* @see \App\Http\Controllers\AcademicCalendarController::eventStatus
 * @see app/Http/Controllers/AcademicCalendarController.php:115
 * @route '/admin/academic-calendars/{academicCalendar}/events/{event}/status'
 */
export const eventStatus = (args: { academicCalendar: number | { id: number }, event: number | { id: number } } | [academicCalendar: number | { id: number }, event: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: eventStatus.url(args, options),
    method: 'patch',
})

eventStatus.definition = {
    methods: ["patch"],
    url: '/admin/academic-calendars/{academicCalendar}/events/{event}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\AcademicCalendarController::eventStatus
 * @see app/Http/Controllers/AcademicCalendarController.php:115
 * @route '/admin/academic-calendars/{academicCalendar}/events/{event}/status'
 */
eventStatus.url = (args: { academicCalendar: number | { id: number }, event: number | { id: number } } | [academicCalendar: number | { id: number }, event: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    academicCalendar: args[0],
                    event: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        academicCalendar: typeof args.academicCalendar === 'object'
                ? args.academicCalendar.id
                : args.academicCalendar,
                                event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return eventStatus.definition.url
            .replace('{academicCalendar}', parsedArgs.academicCalendar.toString())
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AcademicCalendarController::eventStatus
 * @see app/Http/Controllers/AcademicCalendarController.php:115
 * @route '/admin/academic-calendars/{academicCalendar}/events/{event}/status'
 */
eventStatus.patch = (args: { academicCalendar: number | { id: number }, event: number | { id: number } } | [academicCalendar: number | { id: number }, event: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: eventStatus.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\AcademicCalendarController::eventStatus
 * @see app/Http/Controllers/AcademicCalendarController.php:115
 * @route '/admin/academic-calendars/{academicCalendar}/events/{event}/status'
 */
    const eventStatusForm = (args: { academicCalendar: number | { id: number }, event: number | { id: number } } | [academicCalendar: number | { id: number }, event: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: eventStatus.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AcademicCalendarController::eventStatus
 * @see app/Http/Controllers/AcademicCalendarController.php:115
 * @route '/admin/academic-calendars/{academicCalendar}/events/{event}/status'
 */
        eventStatusForm.patch = (args: { academicCalendar: number | { id: number }, event: number | { id: number } } | [academicCalendar: number | { id: number }, event: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: eventStatus.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    eventStatus.form = eventStatusForm
const AcademicCalendarController = { index, store, update, status, storeEvent, updateEvent, eventStatus }

export default AcademicCalendarController