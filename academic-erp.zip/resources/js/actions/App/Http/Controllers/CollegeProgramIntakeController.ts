import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CollegeProgramIntakeController::index
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:24
 * @route '/college/{college}/intakes'
 */
export const index = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/college/{college}/intakes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CollegeProgramIntakeController::index
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:24
 * @route '/college/{college}/intakes'
 */
index.url = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { college: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { college: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                }

    return index.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeProgramIntakeController::index
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:24
 * @route '/college/{college}/intakes'
 */
index.get = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CollegeProgramIntakeController::index
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:24
 * @route '/college/{college}/intakes'
 */
index.head = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CollegeProgramIntakeController::index
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:24
 * @route '/college/{college}/intakes'
 */
    const indexForm = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CollegeProgramIntakeController::index
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:24
 * @route '/college/{college}/intakes'
 */
        indexForm.get = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CollegeProgramIntakeController::index
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:24
 * @route '/college/{college}/intakes'
 */
        indexForm.head = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CollegeProgramIntakeController::store
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:138
 * @route '/college/{college}/intakes'
 */
export const store = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/college/{college}/intakes',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CollegeProgramIntakeController::store
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:138
 * @route '/college/{college}/intakes'
 */
store.url = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { college: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { college: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                }

    return store.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeProgramIntakeController::store
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:138
 * @route '/college/{college}/intakes'
 */
store.post = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CollegeProgramIntakeController::store
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:138
 * @route '/college/{college}/intakes'
 */
    const storeForm = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeProgramIntakeController::store
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:138
 * @route '/college/{college}/intakes'
 */
        storeForm.post = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CollegeProgramIntakeController::update
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:157
 * @route '/college/{college}/intakes/{intake}'
 */
export const update = (args: { college: number | { id: number }, intake: number | { id: number } } | [college: number | { id: number }, intake: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/college/{college}/intakes/{intake}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeProgramIntakeController::update
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:157
 * @route '/college/{college}/intakes/{intake}'
 */
update.url = (args: { college: number | { id: number }, intake: number | { id: number } } | [college: number | { id: number }, intake: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    intake: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                intake: typeof args.intake === 'object'
                ? args.intake.id
                : args.intake,
                }

    return update.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{intake}', parsedArgs.intake.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeProgramIntakeController::update
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:157
 * @route '/college/{college}/intakes/{intake}'
 */
update.patch = (args: { college: number | { id: number }, intake: number | { id: number } } | [college: number | { id: number }, intake: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeProgramIntakeController::update
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:157
 * @route '/college/{college}/intakes/{intake}'
 */
    const updateForm = (args: { college: number | { id: number }, intake: number | { id: number } } | [college: number | { id: number }, intake: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeProgramIntakeController::update
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:157
 * @route '/college/{college}/intakes/{intake}'
 */
        updateForm.patch = (args: { college: number | { id: number }, intake: number | { id: number } } | [college: number | { id: number }, intake: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CollegeProgramIntakeController::status
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:247
 * @route '/college/{college}/intakes/{intake}/status'
 */
export const status = (args: { college: number | { id: number }, intake: number | { id: number } } | [college: number | { id: number }, intake: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

status.definition = {
    methods: ["patch"],
    url: '/college/{college}/intakes/{intake}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeProgramIntakeController::status
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:247
 * @route '/college/{college}/intakes/{intake}/status'
 */
status.url = (args: { college: number | { id: number }, intake: number | { id: number } } | [college: number | { id: number }, intake: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    intake: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                intake: typeof args.intake === 'object'
                ? args.intake.id
                : args.intake,
                }

    return status.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{intake}', parsedArgs.intake.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeProgramIntakeController::status
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:247
 * @route '/college/{college}/intakes/{intake}/status'
 */
status.patch = (args: { college: number | { id: number }, intake: number | { id: number } } | [college: number | { id: number }, intake: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeProgramIntakeController::status
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:247
 * @route '/college/{college}/intakes/{intake}/status'
 */
    const statusForm = (args: { college: number | { id: number }, intake: number | { id: number } } | [college: number | { id: number }, intake: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: status.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeProgramIntakeController::status
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:247
 * @route '/college/{college}/intakes/{intake}/status'
 */
        statusForm.patch = (args: { college: number | { id: number }, intake: number | { id: number } } | [college: number | { id: number }, intake: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: status.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    status.form = statusForm
/**
* @see \App\Http\Controllers\CollegeProgramIntakeController::storeAllocation
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:177
 * @route '/college/{college}/intakes/{intake}/allocations'
 */
export const storeAllocation = (args: { college: number | { id: number }, intake: number | { id: number } } | [college: number | { id: number }, intake: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeAllocation.url(args, options),
    method: 'post',
})

storeAllocation.definition = {
    methods: ["post"],
    url: '/college/{college}/intakes/{intake}/allocations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CollegeProgramIntakeController::storeAllocation
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:177
 * @route '/college/{college}/intakes/{intake}/allocations'
 */
storeAllocation.url = (args: { college: number | { id: number }, intake: number | { id: number } } | [college: number | { id: number }, intake: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    intake: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                intake: typeof args.intake === 'object'
                ? args.intake.id
                : args.intake,
                }

    return storeAllocation.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{intake}', parsedArgs.intake.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeProgramIntakeController::storeAllocation
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:177
 * @route '/college/{college}/intakes/{intake}/allocations'
 */
storeAllocation.post = (args: { college: number | { id: number }, intake: number | { id: number } } | [college: number | { id: number }, intake: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeAllocation.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CollegeProgramIntakeController::storeAllocation
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:177
 * @route '/college/{college}/intakes/{intake}/allocations'
 */
    const storeAllocationForm = (args: { college: number | { id: number }, intake: number | { id: number } } | [college: number | { id: number }, intake: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeAllocation.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeProgramIntakeController::storeAllocation
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:177
 * @route '/college/{college}/intakes/{intake}/allocations'
 */
        storeAllocationForm.post = (args: { college: number | { id: number }, intake: number | { id: number } } | [college: number | { id: number }, intake: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeAllocation.url(args, options),
            method: 'post',
        })
    
    storeAllocation.form = storeAllocationForm
/**
* @see \App\Http\Controllers\CollegeProgramIntakeController::updateAllocation
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:198
 * @route '/college/{college}/intakes/{intake}/allocations/{allocation}'
 */
export const updateAllocation = (args: { college: number | { id: number }, intake: number | { id: number }, allocation: number | { id: number } } | [college: number | { id: number }, intake: number | { id: number }, allocation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateAllocation.url(args, options),
    method: 'patch',
})

updateAllocation.definition = {
    methods: ["patch"],
    url: '/college/{college}/intakes/{intake}/allocations/{allocation}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeProgramIntakeController::updateAllocation
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:198
 * @route '/college/{college}/intakes/{intake}/allocations/{allocation}'
 */
updateAllocation.url = (args: { college: number | { id: number }, intake: number | { id: number }, allocation: number | { id: number } } | [college: number | { id: number }, intake: number | { id: number }, allocation: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    intake: args[1],
                    allocation: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                intake: typeof args.intake === 'object'
                ? args.intake.id
                : args.intake,
                                allocation: typeof args.allocation === 'object'
                ? args.allocation.id
                : args.allocation,
                }

    return updateAllocation.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{intake}', parsedArgs.intake.toString())
            .replace('{allocation}', parsedArgs.allocation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeProgramIntakeController::updateAllocation
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:198
 * @route '/college/{college}/intakes/{intake}/allocations/{allocation}'
 */
updateAllocation.patch = (args: { college: number | { id: number }, intake: number | { id: number }, allocation: number | { id: number } } | [college: number | { id: number }, intake: number | { id: number }, allocation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateAllocation.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeProgramIntakeController::updateAllocation
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:198
 * @route '/college/{college}/intakes/{intake}/allocations/{allocation}'
 */
    const updateAllocationForm = (args: { college: number | { id: number }, intake: number | { id: number }, allocation: number | { id: number } } | [college: number | { id: number }, intake: number | { id: number }, allocation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateAllocation.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeProgramIntakeController::updateAllocation
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:198
 * @route '/college/{college}/intakes/{intake}/allocations/{allocation}'
 */
        updateAllocationForm.patch = (args: { college: number | { id: number }, intake: number | { id: number }, allocation: number | { id: number } } | [college: number | { id: number }, intake: number | { id: number }, allocation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateAllocation.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateAllocation.form = updateAllocationForm
/**
* @see \App\Http\Controllers\CollegeProgramIntakeController::destroyAllocation
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:220
 * @route '/college/{college}/intakes/{intake}/allocations/{allocation}'
 */
export const destroyAllocation = (args: { college: number | { id: number }, intake: number | { id: number }, allocation: number | { id: number } } | [college: number | { id: number }, intake: number | { id: number }, allocation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyAllocation.url(args, options),
    method: 'delete',
})

destroyAllocation.definition = {
    methods: ["delete"],
    url: '/college/{college}/intakes/{intake}/allocations/{allocation}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CollegeProgramIntakeController::destroyAllocation
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:220
 * @route '/college/{college}/intakes/{intake}/allocations/{allocation}'
 */
destroyAllocation.url = (args: { college: number | { id: number }, intake: number | { id: number }, allocation: number | { id: number } } | [college: number | { id: number }, intake: number | { id: number }, allocation: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    intake: args[1],
                    allocation: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                intake: typeof args.intake === 'object'
                ? args.intake.id
                : args.intake,
                                allocation: typeof args.allocation === 'object'
                ? args.allocation.id
                : args.allocation,
                }

    return destroyAllocation.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{intake}', parsedArgs.intake.toString())
            .replace('{allocation}', parsedArgs.allocation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeProgramIntakeController::destroyAllocation
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:220
 * @route '/college/{college}/intakes/{intake}/allocations/{allocation}'
 */
destroyAllocation.delete = (args: { college: number | { id: number }, intake: number | { id: number }, allocation: number | { id: number } } | [college: number | { id: number }, intake: number | { id: number }, allocation: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyAllocation.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CollegeProgramIntakeController::destroyAllocation
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:220
 * @route '/college/{college}/intakes/{intake}/allocations/{allocation}'
 */
    const destroyAllocationForm = (args: { college: number | { id: number }, intake: number | { id: number }, allocation: number | { id: number } } | [college: number | { id: number }, intake: number | { id: number }, allocation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyAllocation.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeProgramIntakeController::destroyAllocation
 * @see app/Http/Controllers/CollegeProgramIntakeController.php:220
 * @route '/college/{college}/intakes/{intake}/allocations/{allocation}'
 */
        destroyAllocationForm.delete = (args: { college: number | { id: number }, intake: number | { id: number }, allocation: number | { id: number } } | [college: number | { id: number }, intake: number | { id: number }, allocation: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyAllocation.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyAllocation.form = destroyAllocationForm
const CollegeProgramIntakeController = { index, store, update, status, storeAllocation, updateAllocation, destroyAllocation }

export default CollegeProgramIntakeController