import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\TestDataCleanupController::index
 * @see app/Http/Controllers/TestDataCleanupController.php:21
 * @route '/admin/system-maintenance/test-data-cleanup'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/system-maintenance/test-data-cleanup',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TestDataCleanupController::index
 * @see app/Http/Controllers/TestDataCleanupController.php:21
 * @route '/admin/system-maintenance/test-data-cleanup'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TestDataCleanupController::index
 * @see app/Http/Controllers/TestDataCleanupController.php:21
 * @route '/admin/system-maintenance/test-data-cleanup'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TestDataCleanupController::index
 * @see app/Http/Controllers/TestDataCleanupController.php:21
 * @route '/admin/system-maintenance/test-data-cleanup'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TestDataCleanupController::index
 * @see app/Http/Controllers/TestDataCleanupController.php:21
 * @route '/admin/system-maintenance/test-data-cleanup'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TestDataCleanupController::index
 * @see app/Http/Controllers/TestDataCleanupController.php:21
 * @route '/admin/system-maintenance/test-data-cleanup'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TestDataCleanupController::index
 * @see app/Http/Controllers/TestDataCleanupController.php:21
 * @route '/admin/system-maintenance/test-data-cleanup'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\TestDataCleanupController::fullReset
 * @see app/Http/Controllers/TestDataCleanupController.php:173
 * @route '/admin/system-maintenance/test-data-cleanup/full-reset'
 */
export const fullReset = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: fullReset.url(options),
    method: 'delete',
})

fullReset.definition = {
    methods: ["delete"],
    url: '/admin/system-maintenance/test-data-cleanup/full-reset',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\TestDataCleanupController::fullReset
 * @see app/Http/Controllers/TestDataCleanupController.php:173
 * @route '/admin/system-maintenance/test-data-cleanup/full-reset'
 */
fullReset.url = (options?: RouteQueryOptions) => {
    return fullReset.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TestDataCleanupController::fullReset
 * @see app/Http/Controllers/TestDataCleanupController.php:173
 * @route '/admin/system-maintenance/test-data-cleanup/full-reset'
 */
fullReset.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: fullReset.url(options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\TestDataCleanupController::fullReset
 * @see app/Http/Controllers/TestDataCleanupController.php:173
 * @route '/admin/system-maintenance/test-data-cleanup/full-reset'
 */
    const fullResetForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: fullReset.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TestDataCleanupController::fullReset
 * @see app/Http/Controllers/TestDataCleanupController.php:173
 * @route '/admin/system-maintenance/test-data-cleanup/full-reset'
 */
        fullResetForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: fullReset.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    fullReset.form = fullResetForm
/**
* @see \App\Http\Controllers\TestDataCleanupController::cleanupLegacyUnlinkedRegularApplications
 * @see app/Http/Controllers/TestDataCleanupController.php:213
 * @route '/admin/system-maintenance/test-data-cleanup/legacy-unlinked-regular-applications'
 */
export const cleanupLegacyUnlinkedRegularApplications = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: cleanupLegacyUnlinkedRegularApplications.url(options),
    method: 'delete',
})

cleanupLegacyUnlinkedRegularApplications.definition = {
    methods: ["delete"],
    url: '/admin/system-maintenance/test-data-cleanup/legacy-unlinked-regular-applications',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\TestDataCleanupController::cleanupLegacyUnlinkedRegularApplications
 * @see app/Http/Controllers/TestDataCleanupController.php:213
 * @route '/admin/system-maintenance/test-data-cleanup/legacy-unlinked-regular-applications'
 */
cleanupLegacyUnlinkedRegularApplications.url = (options?: RouteQueryOptions) => {
    return cleanupLegacyUnlinkedRegularApplications.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TestDataCleanupController::cleanupLegacyUnlinkedRegularApplications
 * @see app/Http/Controllers/TestDataCleanupController.php:213
 * @route '/admin/system-maintenance/test-data-cleanup/legacy-unlinked-regular-applications'
 */
cleanupLegacyUnlinkedRegularApplications.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: cleanupLegacyUnlinkedRegularApplications.url(options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\TestDataCleanupController::cleanupLegacyUnlinkedRegularApplications
 * @see app/Http/Controllers/TestDataCleanupController.php:213
 * @route '/admin/system-maintenance/test-data-cleanup/legacy-unlinked-regular-applications'
 */
    const cleanupLegacyUnlinkedRegularApplicationsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cleanupLegacyUnlinkedRegularApplications.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TestDataCleanupController::cleanupLegacyUnlinkedRegularApplications
 * @see app/Http/Controllers/TestDataCleanupController.php:213
 * @route '/admin/system-maintenance/test-data-cleanup/legacy-unlinked-regular-applications'
 */
        cleanupLegacyUnlinkedRegularApplicationsForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cleanupLegacyUnlinkedRegularApplications.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    cleanupLegacyUnlinkedRegularApplications.form = cleanupLegacyUnlinkedRegularApplicationsForm
/**
* @see \App\Http\Controllers\TestDataCleanupController::destroyCurriculum
 * @see app/Http/Controllers/TestDataCleanupController.php:110
 * @route '/admin/system-maintenance/test-data-cleanup/curricula/{curriculum}'
 */
export const destroyCurriculum = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCurriculum.url(args, options),
    method: 'delete',
})

destroyCurriculum.definition = {
    methods: ["delete"],
    url: '/admin/system-maintenance/test-data-cleanup/curricula/{curriculum}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\TestDataCleanupController::destroyCurriculum
 * @see app/Http/Controllers/TestDataCleanupController.php:110
 * @route '/admin/system-maintenance/test-data-cleanup/curricula/{curriculum}'
 */
destroyCurriculum.url = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { curriculum: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { curriculum: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                }

    return destroyCurriculum.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TestDataCleanupController::destroyCurriculum
 * @see app/Http/Controllers/TestDataCleanupController.php:110
 * @route '/admin/system-maintenance/test-data-cleanup/curricula/{curriculum}'
 */
destroyCurriculum.delete = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCurriculum.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\TestDataCleanupController::destroyCurriculum
 * @see app/Http/Controllers/TestDataCleanupController.php:110
 * @route '/admin/system-maintenance/test-data-cleanup/curricula/{curriculum}'
 */
    const destroyCurriculumForm = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyCurriculum.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TestDataCleanupController::destroyCurriculum
 * @see app/Http/Controllers/TestDataCleanupController.php:110
 * @route '/admin/system-maintenance/test-data-cleanup/curricula/{curriculum}'
 */
        destroyCurriculumForm.delete = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyCurriculum.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyCurriculum.form = destroyCurriculumForm
/**
* @see \App\Http\Controllers\TestDataCleanupController::resetCurriculumApproval
 * @see app/Http/Controllers/TestDataCleanupController.php:89
 * @route '/admin/system-maintenance/test-data-cleanup/curricula/{curriculum}/reset-approval'
 */
export const resetCurriculumApproval = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetCurriculumApproval.url(args, options),
    method: 'post',
})

resetCurriculumApproval.definition = {
    methods: ["post"],
    url: '/admin/system-maintenance/test-data-cleanup/curricula/{curriculum}/reset-approval',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TestDataCleanupController::resetCurriculumApproval
 * @see app/Http/Controllers/TestDataCleanupController.php:89
 * @route '/admin/system-maintenance/test-data-cleanup/curricula/{curriculum}/reset-approval'
 */
resetCurriculumApproval.url = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { curriculum: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { curriculum: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    curriculum: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        curriculum: typeof args.curriculum === 'object'
                ? args.curriculum.id
                : args.curriculum,
                }

    return resetCurriculumApproval.definition.url
            .replace('{curriculum}', parsedArgs.curriculum.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TestDataCleanupController::resetCurriculumApproval
 * @see app/Http/Controllers/TestDataCleanupController.php:89
 * @route '/admin/system-maintenance/test-data-cleanup/curricula/{curriculum}/reset-approval'
 */
resetCurriculumApproval.post = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetCurriculumApproval.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TestDataCleanupController::resetCurriculumApproval
 * @see app/Http/Controllers/TestDataCleanupController.php:89
 * @route '/admin/system-maintenance/test-data-cleanup/curricula/{curriculum}/reset-approval'
 */
    const resetCurriculumApprovalForm = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resetCurriculumApproval.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TestDataCleanupController::resetCurriculumApproval
 * @see app/Http/Controllers/TestDataCleanupController.php:89
 * @route '/admin/system-maintenance/test-data-cleanup/curricula/{curriculum}/reset-approval'
 */
        resetCurriculumApprovalForm.post = (args: { curriculum: number | { id: number } } | [curriculum: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resetCurriculumApproval.url(args, options),
            method: 'post',
        })
    
    resetCurriculumApproval.form = resetCurriculumApprovalForm
/**
* @see \App\Http\Controllers\TestDataCleanupController::destroyAcademicPolicy
 * @see app/Http/Controllers/TestDataCleanupController.php:152
 * @route '/admin/system-maintenance/test-data-cleanup/academic-policies/{academicPolicy}'
 */
export const destroyAcademicPolicy = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyAcademicPolicy.url(args, options),
    method: 'delete',
})

destroyAcademicPolicy.definition = {
    methods: ["delete"],
    url: '/admin/system-maintenance/test-data-cleanup/academic-policies/{academicPolicy}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\TestDataCleanupController::destroyAcademicPolicy
 * @see app/Http/Controllers/TestDataCleanupController.php:152
 * @route '/admin/system-maintenance/test-data-cleanup/academic-policies/{academicPolicy}'
 */
destroyAcademicPolicy.url = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { academicPolicy: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { academicPolicy: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    academicPolicy: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        academicPolicy: typeof args.academicPolicy === 'object'
                ? args.academicPolicy.id
                : args.academicPolicy,
                }

    return destroyAcademicPolicy.definition.url
            .replace('{academicPolicy}', parsedArgs.academicPolicy.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TestDataCleanupController::destroyAcademicPolicy
 * @see app/Http/Controllers/TestDataCleanupController.php:152
 * @route '/admin/system-maintenance/test-data-cleanup/academic-policies/{academicPolicy}'
 */
destroyAcademicPolicy.delete = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyAcademicPolicy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\TestDataCleanupController::destroyAcademicPolicy
 * @see app/Http/Controllers/TestDataCleanupController.php:152
 * @route '/admin/system-maintenance/test-data-cleanup/academic-policies/{academicPolicy}'
 */
    const destroyAcademicPolicyForm = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyAcademicPolicy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TestDataCleanupController::destroyAcademicPolicy
 * @see app/Http/Controllers/TestDataCleanupController.php:152
 * @route '/admin/system-maintenance/test-data-cleanup/academic-policies/{academicPolicy}'
 */
        destroyAcademicPolicyForm.delete = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyAcademicPolicy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyAcademicPolicy.form = destroyAcademicPolicyForm
/**
* @see \App\Http\Controllers\TestDataCleanupController::resetAcademicPolicyApproval
 * @see app/Http/Controllers/TestDataCleanupController.php:131
 * @route '/admin/system-maintenance/test-data-cleanup/academic-policies/{academicPolicy}/reset-approval'
 */
export const resetAcademicPolicyApproval = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetAcademicPolicyApproval.url(args, options),
    method: 'post',
})

resetAcademicPolicyApproval.definition = {
    methods: ["post"],
    url: '/admin/system-maintenance/test-data-cleanup/academic-policies/{academicPolicy}/reset-approval',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TestDataCleanupController::resetAcademicPolicyApproval
 * @see app/Http/Controllers/TestDataCleanupController.php:131
 * @route '/admin/system-maintenance/test-data-cleanup/academic-policies/{academicPolicy}/reset-approval'
 */
resetAcademicPolicyApproval.url = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { academicPolicy: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { academicPolicy: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    academicPolicy: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        academicPolicy: typeof args.academicPolicy === 'object'
                ? args.academicPolicy.id
                : args.academicPolicy,
                }

    return resetAcademicPolicyApproval.definition.url
            .replace('{academicPolicy}', parsedArgs.academicPolicy.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TestDataCleanupController::resetAcademicPolicyApproval
 * @see app/Http/Controllers/TestDataCleanupController.php:131
 * @route '/admin/system-maintenance/test-data-cleanup/academic-policies/{academicPolicy}/reset-approval'
 */
resetAcademicPolicyApproval.post = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetAcademicPolicyApproval.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TestDataCleanupController::resetAcademicPolicyApproval
 * @see app/Http/Controllers/TestDataCleanupController.php:131
 * @route '/admin/system-maintenance/test-data-cleanup/academic-policies/{academicPolicy}/reset-approval'
 */
    const resetAcademicPolicyApprovalForm = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resetAcademicPolicyApproval.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TestDataCleanupController::resetAcademicPolicyApproval
 * @see app/Http/Controllers/TestDataCleanupController.php:131
 * @route '/admin/system-maintenance/test-data-cleanup/academic-policies/{academicPolicy}/reset-approval'
 */
        resetAcademicPolicyApprovalForm.post = (args: { academicPolicy: number | { id: number } } | [academicPolicy: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resetAcademicPolicyApproval.url(args, options),
            method: 'post',
        })
    
    resetAcademicPolicyApproval.form = resetAcademicPolicyApprovalForm
/**
* @see \App\Http\Controllers\TestDataCleanupController::destroyMaster
 * @see app/Http/Controllers/TestDataCleanupController.php:245
 * @route '/admin/system-maintenance/test-data-cleanup/{type}/{id}'
 */
export const destroyMaster = (args: { type: string | number, id: string | number } | [type: string | number, id: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyMaster.url(args, options),
    method: 'delete',
})

destroyMaster.definition = {
    methods: ["delete"],
    url: '/admin/system-maintenance/test-data-cleanup/{type}/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\TestDataCleanupController::destroyMaster
 * @see app/Http/Controllers/TestDataCleanupController.php:245
 * @route '/admin/system-maintenance/test-data-cleanup/{type}/{id}'
 */
destroyMaster.url = (args: { type: string | number, id: string | number } | [type: string | number, id: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    type: args[0],
                    id: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        type: args.type,
                                id: args.id,
                }

    return destroyMaster.definition.url
            .replace('{type}', parsedArgs.type.toString())
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TestDataCleanupController::destroyMaster
 * @see app/Http/Controllers/TestDataCleanupController.php:245
 * @route '/admin/system-maintenance/test-data-cleanup/{type}/{id}'
 */
destroyMaster.delete = (args: { type: string | number, id: string | number } | [type: string | number, id: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyMaster.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\TestDataCleanupController::destroyMaster
 * @see app/Http/Controllers/TestDataCleanupController.php:245
 * @route '/admin/system-maintenance/test-data-cleanup/{type}/{id}'
 */
    const destroyMasterForm = (args: { type: string | number, id: string | number } | [type: string | number, id: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyMaster.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TestDataCleanupController::destroyMaster
 * @see app/Http/Controllers/TestDataCleanupController.php:245
 * @route '/admin/system-maintenance/test-data-cleanup/{type}/{id}'
 */
        destroyMasterForm.delete = (args: { type: string | number, id: string | number } | [type: string | number, id: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyMaster.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyMaster.form = destroyMasterForm
const TestDataCleanupController = { index, fullReset, cleanupLegacyUnlinkedRegularApplications, destroyCurriculum, resetCurriculumApproval, destroyAcademicPolicy, resetAcademicPolicyApproval, destroyMaster }

export default TestDataCleanupController