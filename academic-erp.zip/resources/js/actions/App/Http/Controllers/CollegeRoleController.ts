import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CollegeRoleController::index
 * @see app/Http/Controllers/CollegeRoleController.php:21
 * @route '/college/{college}/roles'
 */
export const index = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/college/{college}/roles',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CollegeRoleController::index
 * @see app/Http/Controllers/CollegeRoleController.php:21
 * @route '/college/{college}/roles'
 */
index.url = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { college: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { college: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                }

    return index.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeRoleController::index
 * @see app/Http/Controllers/CollegeRoleController.php:21
 * @route '/college/{college}/roles'
 */
index.get = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CollegeRoleController::index
 * @see app/Http/Controllers/CollegeRoleController.php:21
 * @route '/college/{college}/roles'
 */
index.head = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CollegeRoleController::index
 * @see app/Http/Controllers/CollegeRoleController.php:21
 * @route '/college/{college}/roles'
 */
    const indexForm = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CollegeRoleController::index
 * @see app/Http/Controllers/CollegeRoleController.php:21
 * @route '/college/{college}/roles'
 */
        indexForm.get = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CollegeRoleController::index
 * @see app/Http/Controllers/CollegeRoleController.php:21
 * @route '/college/{college}/roles'
 */
        indexForm.head = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CollegeRoleController::store
 * @see app/Http/Controllers/CollegeRoleController.php:28
 * @route '/college/{college}/roles'
 */
export const store = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/college/{college}/roles',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CollegeRoleController::store
 * @see app/Http/Controllers/CollegeRoleController.php:28
 * @route '/college/{college}/roles'
 */
store.url = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { college: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { college: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                }

    return store.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeRoleController::store
 * @see app/Http/Controllers/CollegeRoleController.php:28
 * @route '/college/{college}/roles'
 */
store.post = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CollegeRoleController::store
 * @see app/Http/Controllers/CollegeRoleController.php:28
 * @route '/college/{college}/roles'
 */
    const storeForm = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeRoleController::store
 * @see app/Http/Controllers/CollegeRoleController.php:28
 * @route '/college/{college}/roles'
 */
        storeForm.post = (args: { college: number | { id: number } } | [college: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CollegeRoleController::edit
 * @see app/Http/Controllers/CollegeRoleController.php:37
 * @route '/college/{college}/roles/{role}/edit'
 */
export const edit = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/college/{college}/roles/{role}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CollegeRoleController::edit
 * @see app/Http/Controllers/CollegeRoleController.php:37
 * @route '/college/{college}/roles/{role}/edit'
 */
edit.url = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    role: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                role: typeof args.role === 'object'
                ? args.role.id
                : args.role,
                }

    return edit.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{role}', parsedArgs.role.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeRoleController::edit
 * @see app/Http/Controllers/CollegeRoleController.php:37
 * @route '/college/{college}/roles/{role}/edit'
 */
edit.get = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CollegeRoleController::edit
 * @see app/Http/Controllers/CollegeRoleController.php:37
 * @route '/college/{college}/roles/{role}/edit'
 */
edit.head = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CollegeRoleController::edit
 * @see app/Http/Controllers/CollegeRoleController.php:37
 * @route '/college/{college}/roles/{role}/edit'
 */
    const editForm = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CollegeRoleController::edit
 * @see app/Http/Controllers/CollegeRoleController.php:37
 * @route '/college/{college}/roles/{role}/edit'
 */
        editForm.get = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CollegeRoleController::edit
 * @see app/Http/Controllers/CollegeRoleController.php:37
 * @route '/college/{college}/roles/{role}/edit'
 */
        editForm.head = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\CollegeRoleController::update
 * @see app/Http/Controllers/CollegeRoleController.php:45
 * @route '/college/{college}/roles/{role}'
 */
export const update = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/college/{college}/roles/{role}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeRoleController::update
 * @see app/Http/Controllers/CollegeRoleController.php:45
 * @route '/college/{college}/roles/{role}'
 */
update.url = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    role: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                role: typeof args.role === 'object'
                ? args.role.id
                : args.role,
                }

    return update.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{role}', parsedArgs.role.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeRoleController::update
 * @see app/Http/Controllers/CollegeRoleController.php:45
 * @route '/college/{college}/roles/{role}'
 */
update.patch = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeRoleController::update
 * @see app/Http/Controllers/CollegeRoleController.php:45
 * @route '/college/{college}/roles/{role}'
 */
    const updateForm = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeRoleController::update
 * @see app/Http/Controllers/CollegeRoleController.php:45
 * @route '/college/{college}/roles/{role}'
 */
        updateForm.patch = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CollegeRoleController::status
 * @see app/Http/Controllers/CollegeRoleController.php:55
 * @route '/college/{college}/roles/{role}/status'
 */
export const status = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

status.definition = {
    methods: ["patch"],
    url: '/college/{college}/roles/{role}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CollegeRoleController::status
 * @see app/Http/Controllers/CollegeRoleController.php:55
 * @route '/college/{college}/roles/{role}/status'
 */
status.url = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    college: args[0],
                    role: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        college: typeof args.college === 'object'
                ? args.college.id
                : args.college,
                                role: typeof args.role === 'object'
                ? args.role.id
                : args.role,
                }

    return status.definition.url
            .replace('{college}', parsedArgs.college.toString())
            .replace('{role}', parsedArgs.role.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CollegeRoleController::status
 * @see app/Http/Controllers/CollegeRoleController.php:55
 * @route '/college/{college}/roles/{role}/status'
 */
status.patch = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: status.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CollegeRoleController::status
 * @see app/Http/Controllers/CollegeRoleController.php:55
 * @route '/college/{college}/roles/{role}/status'
 */
    const statusForm = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: status.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CollegeRoleController::status
 * @see app/Http/Controllers/CollegeRoleController.php:55
 * @route '/college/{college}/roles/{role}/status'
 */
        statusForm.patch = (args: { college: number | { id: number }, role: number | { id: number } } | [college: number | { id: number }, role: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: status.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    status.form = statusForm
const CollegeRoleController = { index, store, edit, update, status }

export default CollegeRoleController