import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/university'
 */
const RedirectControllercf6bef7e0081d095aa50e96c9c60133b = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: RedirectControllercf6bef7e0081d095aa50e96c9c60133b.url(options),
    method: 'get',
})

RedirectControllercf6bef7e0081d095aa50e96c9c60133b.definition = {
    methods: ["get","head","post","put","patch","delete","options"],
    url: '/super-admin/university',
} satisfies RouteDefinition<["get","head","post","put","patch","delete","options"]>

/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/university'
 */
RedirectControllercf6bef7e0081d095aa50e96c9c60133b.url = (options?: RouteQueryOptions) => {
    return RedirectControllercf6bef7e0081d095aa50e96c9c60133b.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/university'
 */
RedirectControllercf6bef7e0081d095aa50e96c9c60133b.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: RedirectControllercf6bef7e0081d095aa50e96c9c60133b.url(options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/university'
 */
RedirectControllercf6bef7e0081d095aa50e96c9c60133b.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: RedirectControllercf6bef7e0081d095aa50e96c9c60133b.url(options),
    method: 'head',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/university'
 */
RedirectControllercf6bef7e0081d095aa50e96c9c60133b.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: RedirectControllercf6bef7e0081d095aa50e96c9c60133b.url(options),
    method: 'post',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/university'
 */
RedirectControllercf6bef7e0081d095aa50e96c9c60133b.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: RedirectControllercf6bef7e0081d095aa50e96c9c60133b.url(options),
    method: 'put',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/university'
 */
RedirectControllercf6bef7e0081d095aa50e96c9c60133b.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: RedirectControllercf6bef7e0081d095aa50e96c9c60133b.url(options),
    method: 'patch',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/university'
 */
RedirectControllercf6bef7e0081d095aa50e96c9c60133b.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: RedirectControllercf6bef7e0081d095aa50e96c9c60133b.url(options),
    method: 'delete',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/university'
 */
RedirectControllercf6bef7e0081d095aa50e96c9c60133b.options = (options?: RouteQueryOptions): RouteDefinition<'options'> => ({
    url: RedirectControllercf6bef7e0081d095aa50e96c9c60133b.url(options),
    method: 'options',
})

    /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/university'
 */
    const RedirectControllercf6bef7e0081d095aa50e96c9c60133bForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: RedirectControllercf6bef7e0081d095aa50e96c9c60133b.url(options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/university'
 */
        RedirectControllercf6bef7e0081d095aa50e96c9c60133bForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: RedirectControllercf6bef7e0081d095aa50e96c9c60133b.url(options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/university'
 */
        RedirectControllercf6bef7e0081d095aa50e96c9c60133bForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: RedirectControllercf6bef7e0081d095aa50e96c9c60133b.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/university'
 */
        RedirectControllercf6bef7e0081d095aa50e96c9c60133bForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectControllercf6bef7e0081d095aa50e96c9c60133b.url(options),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/university'
 */
        RedirectControllercf6bef7e0081d095aa50e96c9c60133bForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectControllercf6bef7e0081d095aa50e96c9c60133b.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/university'
 */
        RedirectControllercf6bef7e0081d095aa50e96c9c60133bForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectControllercf6bef7e0081d095aa50e96c9c60133b.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/university'
 */
        RedirectControllercf6bef7e0081d095aa50e96c9c60133bForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectControllercf6bef7e0081d095aa50e96c9c60133b.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/university'
 */
        RedirectControllercf6bef7e0081d095aa50e96c9c60133bForm.options = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: RedirectControllercf6bef7e0081d095aa50e96c9c60133b.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'OPTIONS',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    RedirectControllercf6bef7e0081d095aa50e96c9c60133b.form = RedirectControllercf6bef7e0081d095aa50e96c9c60133bForm
    /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/colleges'
 */
const RedirectController6fbcc48e205a039f09671e2f8ab52468 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: RedirectController6fbcc48e205a039f09671e2f8ab52468.url(options),
    method: 'get',
})

RedirectController6fbcc48e205a039f09671e2f8ab52468.definition = {
    methods: ["get","head","post","put","patch","delete","options"],
    url: '/super-admin/colleges',
} satisfies RouteDefinition<["get","head","post","put","patch","delete","options"]>

/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/colleges'
 */
RedirectController6fbcc48e205a039f09671e2f8ab52468.url = (options?: RouteQueryOptions) => {
    return RedirectController6fbcc48e205a039f09671e2f8ab52468.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/colleges'
 */
RedirectController6fbcc48e205a039f09671e2f8ab52468.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: RedirectController6fbcc48e205a039f09671e2f8ab52468.url(options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/colleges'
 */
RedirectController6fbcc48e205a039f09671e2f8ab52468.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: RedirectController6fbcc48e205a039f09671e2f8ab52468.url(options),
    method: 'head',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/colleges'
 */
RedirectController6fbcc48e205a039f09671e2f8ab52468.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: RedirectController6fbcc48e205a039f09671e2f8ab52468.url(options),
    method: 'post',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/colleges'
 */
RedirectController6fbcc48e205a039f09671e2f8ab52468.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: RedirectController6fbcc48e205a039f09671e2f8ab52468.url(options),
    method: 'put',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/colleges'
 */
RedirectController6fbcc48e205a039f09671e2f8ab52468.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: RedirectController6fbcc48e205a039f09671e2f8ab52468.url(options),
    method: 'patch',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/colleges'
 */
RedirectController6fbcc48e205a039f09671e2f8ab52468.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: RedirectController6fbcc48e205a039f09671e2f8ab52468.url(options),
    method: 'delete',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/colleges'
 */
RedirectController6fbcc48e205a039f09671e2f8ab52468.options = (options?: RouteQueryOptions): RouteDefinition<'options'> => ({
    url: RedirectController6fbcc48e205a039f09671e2f8ab52468.url(options),
    method: 'options',
})

    /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/colleges'
 */
    const RedirectController6fbcc48e205a039f09671e2f8ab52468Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: RedirectController6fbcc48e205a039f09671e2f8ab52468.url(options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/colleges'
 */
        RedirectController6fbcc48e205a039f09671e2f8ab52468Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: RedirectController6fbcc48e205a039f09671e2f8ab52468.url(options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/colleges'
 */
        RedirectController6fbcc48e205a039f09671e2f8ab52468Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: RedirectController6fbcc48e205a039f09671e2f8ab52468.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/colleges'
 */
        RedirectController6fbcc48e205a039f09671e2f8ab52468Form.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectController6fbcc48e205a039f09671e2f8ab52468.url(options),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/colleges'
 */
        RedirectController6fbcc48e205a039f09671e2f8ab52468Form.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectController6fbcc48e205a039f09671e2f8ab52468.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/colleges'
 */
        RedirectController6fbcc48e205a039f09671e2f8ab52468Form.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectController6fbcc48e205a039f09671e2f8ab52468.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/colleges'
 */
        RedirectController6fbcc48e205a039f09671e2f8ab52468Form.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectController6fbcc48e205a039f09671e2f8ab52468.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/colleges'
 */
        RedirectController6fbcc48e205a039f09671e2f8ab52468Form.options = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: RedirectController6fbcc48e205a039f09671e2f8ab52468.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'OPTIONS',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    RedirectController6fbcc48e205a039f09671e2f8ab52468.form = RedirectController6fbcc48e205a039f09671e2f8ab52468Form
    /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/users'
 */
const RedirectController0b8c53335e78df00214e305223cfb8a3 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: RedirectController0b8c53335e78df00214e305223cfb8a3.url(options),
    method: 'get',
})

RedirectController0b8c53335e78df00214e305223cfb8a3.definition = {
    methods: ["get","head","post","put","patch","delete","options"],
    url: '/super-admin/users',
} satisfies RouteDefinition<["get","head","post","put","patch","delete","options"]>

/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/users'
 */
RedirectController0b8c53335e78df00214e305223cfb8a3.url = (options?: RouteQueryOptions) => {
    return RedirectController0b8c53335e78df00214e305223cfb8a3.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/users'
 */
RedirectController0b8c53335e78df00214e305223cfb8a3.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: RedirectController0b8c53335e78df00214e305223cfb8a3.url(options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/users'
 */
RedirectController0b8c53335e78df00214e305223cfb8a3.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: RedirectController0b8c53335e78df00214e305223cfb8a3.url(options),
    method: 'head',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/users'
 */
RedirectController0b8c53335e78df00214e305223cfb8a3.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: RedirectController0b8c53335e78df00214e305223cfb8a3.url(options),
    method: 'post',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/users'
 */
RedirectController0b8c53335e78df00214e305223cfb8a3.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: RedirectController0b8c53335e78df00214e305223cfb8a3.url(options),
    method: 'put',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/users'
 */
RedirectController0b8c53335e78df00214e305223cfb8a3.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: RedirectController0b8c53335e78df00214e305223cfb8a3.url(options),
    method: 'patch',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/users'
 */
RedirectController0b8c53335e78df00214e305223cfb8a3.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: RedirectController0b8c53335e78df00214e305223cfb8a3.url(options),
    method: 'delete',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/users'
 */
RedirectController0b8c53335e78df00214e305223cfb8a3.options = (options?: RouteQueryOptions): RouteDefinition<'options'> => ({
    url: RedirectController0b8c53335e78df00214e305223cfb8a3.url(options),
    method: 'options',
})

    /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/users'
 */
    const RedirectController0b8c53335e78df00214e305223cfb8a3Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: RedirectController0b8c53335e78df00214e305223cfb8a3.url(options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/users'
 */
        RedirectController0b8c53335e78df00214e305223cfb8a3Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: RedirectController0b8c53335e78df00214e305223cfb8a3.url(options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/users'
 */
        RedirectController0b8c53335e78df00214e305223cfb8a3Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: RedirectController0b8c53335e78df00214e305223cfb8a3.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/users'
 */
        RedirectController0b8c53335e78df00214e305223cfb8a3Form.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectController0b8c53335e78df00214e305223cfb8a3.url(options),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/users'
 */
        RedirectController0b8c53335e78df00214e305223cfb8a3Form.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectController0b8c53335e78df00214e305223cfb8a3.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/users'
 */
        RedirectController0b8c53335e78df00214e305223cfb8a3Form.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectController0b8c53335e78df00214e305223cfb8a3.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/users'
 */
        RedirectController0b8c53335e78df00214e305223cfb8a3Form.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectController0b8c53335e78df00214e305223cfb8a3.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/users'
 */
        RedirectController0b8c53335e78df00214e305223cfb8a3Form.options = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: RedirectController0b8c53335e78df00214e305223cfb8a3.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'OPTIONS',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    RedirectController0b8c53335e78df00214e305223cfb8a3.form = RedirectController0b8c53335e78df00214e305223cfb8a3Form
    /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/roles'
 */
const RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf.url(options),
    method: 'get',
})

RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf.definition = {
    methods: ["get","head","post","put","patch","delete","options"],
    url: '/super-admin/roles',
} satisfies RouteDefinition<["get","head","post","put","patch","delete","options"]>

/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/roles'
 */
RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf.url = (options?: RouteQueryOptions) => {
    return RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/roles'
 */
RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf.url(options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/roles'
 */
RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf.url(options),
    method: 'head',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/roles'
 */
RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf.url(options),
    method: 'post',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/roles'
 */
RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf.url(options),
    method: 'put',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/roles'
 */
RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf.url(options),
    method: 'patch',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/roles'
 */
RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf.url(options),
    method: 'delete',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/roles'
 */
RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf.options = (options?: RouteQueryOptions): RouteDefinition<'options'> => ({
    url: RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf.url(options),
    method: 'options',
})

    /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/roles'
 */
    const RedirectController26b64b4d378d2f07eaf21a3ac1bfffbfForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf.url(options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/roles'
 */
        RedirectController26b64b4d378d2f07eaf21a3ac1bfffbfForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf.url(options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/roles'
 */
        RedirectController26b64b4d378d2f07eaf21a3ac1bfffbfForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/roles'
 */
        RedirectController26b64b4d378d2f07eaf21a3ac1bfffbfForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf.url(options),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/roles'
 */
        RedirectController26b64b4d378d2f07eaf21a3ac1bfffbfForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/roles'
 */
        RedirectController26b64b4d378d2f07eaf21a3ac1bfffbfForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/roles'
 */
        RedirectController26b64b4d378d2f07eaf21a3ac1bfffbfForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/roles'
 */
        RedirectController26b64b4d378d2f07eaf21a3ac1bfffbfForm.options = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'OPTIONS',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf.form = RedirectController26b64b4d378d2f07eaf21a3ac1bfffbfForm
    /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/permissions'
 */
const RedirectControllerb22628530477b744c444e6a06b76b2b9 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: RedirectControllerb22628530477b744c444e6a06b76b2b9.url(options),
    method: 'get',
})

RedirectControllerb22628530477b744c444e6a06b76b2b9.definition = {
    methods: ["get","head","post","put","patch","delete","options"],
    url: '/super-admin/permissions',
} satisfies RouteDefinition<["get","head","post","put","patch","delete","options"]>

/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/permissions'
 */
RedirectControllerb22628530477b744c444e6a06b76b2b9.url = (options?: RouteQueryOptions) => {
    return RedirectControllerb22628530477b744c444e6a06b76b2b9.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/permissions'
 */
RedirectControllerb22628530477b744c444e6a06b76b2b9.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: RedirectControllerb22628530477b744c444e6a06b76b2b9.url(options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/permissions'
 */
RedirectControllerb22628530477b744c444e6a06b76b2b9.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: RedirectControllerb22628530477b744c444e6a06b76b2b9.url(options),
    method: 'head',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/permissions'
 */
RedirectControllerb22628530477b744c444e6a06b76b2b9.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: RedirectControllerb22628530477b744c444e6a06b76b2b9.url(options),
    method: 'post',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/permissions'
 */
RedirectControllerb22628530477b744c444e6a06b76b2b9.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: RedirectControllerb22628530477b744c444e6a06b76b2b9.url(options),
    method: 'put',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/permissions'
 */
RedirectControllerb22628530477b744c444e6a06b76b2b9.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: RedirectControllerb22628530477b744c444e6a06b76b2b9.url(options),
    method: 'patch',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/permissions'
 */
RedirectControllerb22628530477b744c444e6a06b76b2b9.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: RedirectControllerb22628530477b744c444e6a06b76b2b9.url(options),
    method: 'delete',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/permissions'
 */
RedirectControllerb22628530477b744c444e6a06b76b2b9.options = (options?: RouteQueryOptions): RouteDefinition<'options'> => ({
    url: RedirectControllerb22628530477b744c444e6a06b76b2b9.url(options),
    method: 'options',
})

    /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/permissions'
 */
    const RedirectControllerb22628530477b744c444e6a06b76b2b9Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: RedirectControllerb22628530477b744c444e6a06b76b2b9.url(options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/permissions'
 */
        RedirectControllerb22628530477b744c444e6a06b76b2b9Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: RedirectControllerb22628530477b744c444e6a06b76b2b9.url(options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/permissions'
 */
        RedirectControllerb22628530477b744c444e6a06b76b2b9Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: RedirectControllerb22628530477b744c444e6a06b76b2b9.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/permissions'
 */
        RedirectControllerb22628530477b744c444e6a06b76b2b9Form.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectControllerb22628530477b744c444e6a06b76b2b9.url(options),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/permissions'
 */
        RedirectControllerb22628530477b744c444e6a06b76b2b9Form.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectControllerb22628530477b744c444e6a06b76b2b9.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/permissions'
 */
        RedirectControllerb22628530477b744c444e6a06b76b2b9Form.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectControllerb22628530477b744c444e6a06b76b2b9.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/permissions'
 */
        RedirectControllerb22628530477b744c444e6a06b76b2b9Form.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectControllerb22628530477b744c444e6a06b76b2b9.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/permissions'
 */
        RedirectControllerb22628530477b744c444e6a06b76b2b9Form.options = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: RedirectControllerb22628530477b744c444e6a06b76b2b9.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'OPTIONS',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    RedirectControllerb22628530477b744c444e6a06b76b2b9.form = RedirectControllerb22628530477b744c444e6a06b76b2b9Form
    /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/audit-logs'
 */
const RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3.url(options),
    method: 'get',
})

RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3.definition = {
    methods: ["get","head","post","put","patch","delete","options"],
    url: '/super-admin/audit-logs',
} satisfies RouteDefinition<["get","head","post","put","patch","delete","options"]>

/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/audit-logs'
 */
RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3.url = (options?: RouteQueryOptions) => {
    return RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/audit-logs'
 */
RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3.url(options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/audit-logs'
 */
RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3.url(options),
    method: 'head',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/audit-logs'
 */
RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3.url(options),
    method: 'post',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/audit-logs'
 */
RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3.url(options),
    method: 'put',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/audit-logs'
 */
RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3.url(options),
    method: 'patch',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/audit-logs'
 */
RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3.url(options),
    method: 'delete',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/audit-logs'
 */
RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3.options = (options?: RouteQueryOptions): RouteDefinition<'options'> => ({
    url: RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3.url(options),
    method: 'options',
})

    /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/audit-logs'
 */
    const RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3.url(options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/audit-logs'
 */
        RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3.url(options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/audit-logs'
 */
        RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/audit-logs'
 */
        RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3Form.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3.url(options),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/audit-logs'
 */
        RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3Form.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/audit-logs'
 */
        RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3Form.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/audit-logs'
 */
        RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3Form.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/super-admin/audit-logs'
 */
        RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3Form.options = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'OPTIONS',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3.form = RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3Form
    /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/settings'
 */
const RedirectController4b87d2df7e3aa853f6720faea796e36c = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: RedirectController4b87d2df7e3aa853f6720faea796e36c.url(options),
    method: 'get',
})

RedirectController4b87d2df7e3aa853f6720faea796e36c.definition = {
    methods: ["get","head","post","put","patch","delete","options"],
    url: '/settings',
} satisfies RouteDefinition<["get","head","post","put","patch","delete","options"]>

/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/settings'
 */
RedirectController4b87d2df7e3aa853f6720faea796e36c.url = (options?: RouteQueryOptions) => {
    return RedirectController4b87d2df7e3aa853f6720faea796e36c.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/settings'
 */
RedirectController4b87d2df7e3aa853f6720faea796e36c.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: RedirectController4b87d2df7e3aa853f6720faea796e36c.url(options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/settings'
 */
RedirectController4b87d2df7e3aa853f6720faea796e36c.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: RedirectController4b87d2df7e3aa853f6720faea796e36c.url(options),
    method: 'head',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/settings'
 */
RedirectController4b87d2df7e3aa853f6720faea796e36c.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: RedirectController4b87d2df7e3aa853f6720faea796e36c.url(options),
    method: 'post',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/settings'
 */
RedirectController4b87d2df7e3aa853f6720faea796e36c.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: RedirectController4b87d2df7e3aa853f6720faea796e36c.url(options),
    method: 'put',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/settings'
 */
RedirectController4b87d2df7e3aa853f6720faea796e36c.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: RedirectController4b87d2df7e3aa853f6720faea796e36c.url(options),
    method: 'patch',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/settings'
 */
RedirectController4b87d2df7e3aa853f6720faea796e36c.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: RedirectController4b87d2df7e3aa853f6720faea796e36c.url(options),
    method: 'delete',
})
/**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/settings'
 */
RedirectController4b87d2df7e3aa853f6720faea796e36c.options = (options?: RouteQueryOptions): RouteDefinition<'options'> => ({
    url: RedirectController4b87d2df7e3aa853f6720faea796e36c.url(options),
    method: 'options',
})

    /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/settings'
 */
    const RedirectController4b87d2df7e3aa853f6720faea796e36cForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: RedirectController4b87d2df7e3aa853f6720faea796e36c.url(options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/settings'
 */
        RedirectController4b87d2df7e3aa853f6720faea796e36cForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: RedirectController4b87d2df7e3aa853f6720faea796e36c.url(options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/settings'
 */
        RedirectController4b87d2df7e3aa853f6720faea796e36cForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: RedirectController4b87d2df7e3aa853f6720faea796e36c.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/settings'
 */
        RedirectController4b87d2df7e3aa853f6720faea796e36cForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectController4b87d2df7e3aa853f6720faea796e36c.url(options),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/settings'
 */
        RedirectController4b87d2df7e3aa853f6720faea796e36cForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectController4b87d2df7e3aa853f6720faea796e36c.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/settings'
 */
        RedirectController4b87d2df7e3aa853f6720faea796e36cForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectController4b87d2df7e3aa853f6720faea796e36c.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/settings'
 */
        RedirectController4b87d2df7e3aa853f6720faea796e36cForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: RedirectController4b87d2df7e3aa853f6720faea796e36c.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \Illuminate\Routing\RedirectController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/RedirectController.php:19
 * @route '/settings'
 */
        RedirectController4b87d2df7e3aa853f6720faea796e36cForm.options = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: RedirectController4b87d2df7e3aa853f6720faea796e36c.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'OPTIONS',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    RedirectController4b87d2df7e3aa853f6720faea796e36c.form = RedirectController4b87d2df7e3aa853f6720faea796e36cForm

/**
* Multiple routes resolve to \Illuminate\Routing\RedirectController::RedirectController, so this export is a
* dictionary keyed by URI rather than a callable. Call a specific route with `RedirectController['<uri>'](...)`,
* or import the route by name from your generated `routes/` directory.
*/
const RedirectController = {
    '/super-admin/university': RedirectControllercf6bef7e0081d095aa50e96c9c60133b,
    '/super-admin/colleges': RedirectController6fbcc48e205a039f09671e2f8ab52468,
    '/super-admin/users': RedirectController0b8c53335e78df00214e305223cfb8a3,
    '/super-admin/roles': RedirectController26b64b4d378d2f07eaf21a3ac1bfffbf,
    '/super-admin/permissions': RedirectControllerb22628530477b744c444e6a06b76b2b9,
    '/super-admin/audit-logs': RedirectControllerf28aa57d31cf4bc9e667dd5532ba7eb3,
    '/settings': RedirectController4b87d2df7e3aa853f6720faea796e36c,
}

export default RedirectController