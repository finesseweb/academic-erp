<?php

namespace App\Services;

use App\Models\AcademicDiscipline;
use App\Models\College;
use App\Models\CollegeProgramOffering;
use App\Models\Student;
use App\Models\StudentEnrollment;
use App\Models\StudentIdentitySetting;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class StudentImportService
{
    public const TARGETS=['full_name','date_of_birth','email','phone','student_uid','university_roll_no','class_roll_no','discipline_code'];

    private function dir(College $college,int $userId): string { return "student-imports/{$college->id}/{$userId}"; }
    private function csvPath(College $college,int $userId,string $token): string { return $this->dir($college,$userId)."/{$token}.csv"; }
    private function metaPath(College $college,int $userId,string $token): string { return $this->dir($college,$userId)."/{$token}.json"; }
    private function assertToken(string $token): void { if(!preg_match('/^[A-Za-z0-9]{40}$/',$token)) abort(404); }

    public function upload(College $college,int $userId,UploadedFile $file): string
    {
        $token=Str::random(40); $path=$this->csvPath($college,$userId,$token);
        Storage::disk('local')->put($path,file_get_contents($file->getRealPath()));
        return $token;
    }

    public function state(College $college,int $userId,?string $token): ?array
    {
        if(!$token) return null; $this->assertToken($token); $path=$this->csvPath($college,$userId,$token);
        if(!Storage::disk('local')->exists($path)) return null;
        $headers=$this->headers($path); $meta=null;
        $mp=$this->metaPath($college,$userId,$token);
        if(Storage::disk('local')->exists($mp)) $meta=json_decode(Storage::disk('local')->get($mp),true);
        return ['token'=>$token,'headers'=>$headers,'meta'=>$meta];
    }

    public function preview(College $college,int $userId,string $token,array $data): array
    {
        $this->assertToken($token); $path=$this->csvPath($college,$userId,$token); if(!Storage::disk('local')->exists($path)) abort(404);
        $headers=$this->headers($path); $mapping=array_filter($data['mapping']??[],fn($v)=>is_string($v)&&$v!=='');
        if(empty($mapping['full_name'])) throw ValidationException::withMessages(['mapping.full_name'=>'Full Name must be mapped.']);
        foreach($mapping as $target=>$header) if(!in_array($target,self::TARGETS,true)||!in_array($header,$headers,true)) throw ValidationException::withMessages(['mapping'=>'Invalid CSV column mapping.']);
        $offering=$this->offering($college,(int)$data['session_id'],(int)$data['offering_id']);
        [$rows,$total,$valid,$invalid]=$this->scan($college,$path,$headers,$mapping,$offering,20);
        $meta=['session_id'=>(int)$data['session_id'],'offering_id'=>(int)$offering->id,'mapping'=>$mapping,'preview'=>$rows,'total'=>$total,'valid'=>$valid,'invalid'=>$invalid,'validated_at'=>now()->toIso8601String()];
        Storage::disk('local')->put($this->metaPath($college,$userId,$token),json_encode($meta));
        return $meta;
    }

    public function import(College $college,int $userId,string $token,int $actorId,?string $ip): int
    {
        $this->assertToken($token); $path=$this->csvPath($college,$userId,$token); $mp=$this->metaPath($college,$userId,$token);
        if(!Storage::disk('local')->exists($path)||!Storage::disk('local')->exists($mp)) throw ValidationException::withMessages(['import'=>'Upload and validate the CSV before importing.']);
        $meta=json_decode(Storage::disk('local')->get($mp),true); $headers=$this->headers($path); $offering=$this->offering($college,(int)$meta['session_id'],(int)$meta['offering_id']);
        [, $total,$valid,$invalid,$allRows]=$this->scan($college,$path,$headers,$meta['mapping'],$offering,0,true);
        if($invalid>0) throw ValidationException::withMessages(['import'=>"Import blocked: {$invalid} row(s) contain validation errors. Validate the file again."]);
        $count=DB::transaction(function() use($allRows,$college,$offering,$actorId,$ip,$total){
            $created=0;
            foreach($allRows as $row){
                $v=$row['values'];
                $student=Student::create(['college_id'=>$college->id,'user_id'=>null,'admission_id'=>null,'college_admission_application_id'=>null,'source_type'=>'IMPORT','student_uid'=>$v['student_uid']?:null,'university_roll_no'=>$v['university_roll_no']?:null,'full_name'=>$v['full_name'],'date_of_birth'=>$v['date_of_birth']?:null,'email'=>$v['email']?:null,'phone'=>$v['phone']?:null,'status'=>'ACTIVE','created_by'=>$actorId,'updated_by'=>$actorId]);
                StudentEnrollment::create(['student_id'=>$student->id,'college_id'=>$college->id,'college_program_offering_id'=>$offering->id,'discipline_id'=>$row['discipline_id'],'admission_id'=>null,'class_roll_no'=>$v['class_roll_no']?:null,'class_roll_scope_key'=>$row['class_roll_scope_key'],'source_type'=>'IMPORT','status'=>'ENROLLED','enrolled_at'=>now(),'enrolled_by'=>$actorId]);
                $created++;
            }
            DB::table('audit_logs')->insert(['actor_user_id'=>$actorId,'event'=>'student.import.completed','resource_type'=>'student_import','resource_id'=>null,'scope_type'=>'COLLEGE','scope_reference'=>'college:'.$college->id,'before'=>null,'after'=>json_encode(['programme_offering_id'=>$offering->id,'rows_imported'=>$created,'source_type'=>'IMPORT']),'ip_address'=>$ip,'created_at'=>now()]);
            return $created;
        });
        Storage::disk('local')->delete([$path,$this->metaPath($college,$userId,$token)]);
        return $count;
    }

    private function offering(College $college,int $sessionId,int $offeringId): CollegeProgramOffering
    {
        $o=CollegeProgramOffering::query()->whereKey($offeringId)->where('college_id',$college->id)->where('academic_session_id',$sessionId)->first();
        if(!$o) throw ValidationException::withMessages(['offering_id'=>'Select a valid Programme Offering for the selected Session.']); return $o;
    }

    private function headers(string $path): array
    {
        $h=fopen(Storage::disk('local')->path($path),'r'); $row=fgetcsv($h); fclose($h); if(!$row) throw ValidationException::withMessages(['file'=>'CSV header row is missing.']);
        $row=array_map(fn($v)=>trim(preg_replace('/^\xEF\xBB\xBF/','',(string)$v)),$row);
        if(count($row)!==count(array_unique($row))) throw ValidationException::withMessages(['file'=>'CSV contains duplicate column headers.']); return $row;
    }

    private function scan(College $college,string $path,array $headers,array $mapping,CollegeProgramOffering $offering,int $previewLimit=20,bool $returnAll=false): array
    {
        $fh=fopen(Storage::disk('local')->path($path),'r'); fgetcsv($fh); $preview=[];$all=[];$total=0;$valid=0;$invalid=0;$seen=[];
        $programDisciplineIds=$offering->programTemplate()->with('disciplines:id')->first()?->disciplines?->pluck('id') ?? collect();
        $disciplines=AcademicDiscipline::query()->where('university_id',$college->university_id)->where('status','ACTIVE')->when($programDisciplineIds->isNotEmpty(),fn($q)=>$q->whereIn('id',$programDisciplineIds))->get(['id','code'])->keyBy(fn($d)=>strtoupper((string)$d->code));
        $identitySettings=StudentIdentitySetting::forCollege((int)$college->id);
        $existingStudentUids=Student::query()->where('college_id',$college->id)->whereNotNull('student_uid')->pluck('student_uid')->map(fn($v)=>strtoupper((string)$v))->flip();
        $existingUniversityRolls=Student::query()->where('college_id',$college->id)->whereNotNull('university_roll_no')->pluck('university_roll_no')->map(fn($v)=>strtoupper((string)$v))->flip();
        $existingClassRolls=StudentEnrollment::query()->where('college_id',$college->id)->whereNotNull('class_roll_no')->get(['class_roll_scope_key','class_roll_no'])->mapWithKeys(fn($e)=>[(string)$e->class_roll_scope_key.'|'.strtoupper((string)$e->class_roll_no)=>true]);
        while(($raw=fgetcsv($fh))!==false){ if(count(array_filter($raw,fn($x)=>trim((string)$x)!==''))===0) continue; $total++; $assoc=[]; foreach($headers as $i=>$h)$assoc[$h]=trim((string)($raw[$i]??'')); $v=[]; foreach(self::TARGETS as $t)$v[$t]=isset($mapping[$t])?($assoc[$mapping[$t]]??''):''; $errors=[];
            if($v['full_name']===''||mb_strlen($v['full_name'])>180)$errors[]='Full Name is required (max 180 characters).';
            if($v['date_of_birth']!==''&&!preg_match('/^\d{4}-\d{2}-\d{2}$/',$v['date_of_birth']))$errors[]='Date of Birth must use YYYY-MM-DD.';
            if($v['email']!==''&&!filter_var($v['email'],FILTER_VALIDATE_EMAIL))$errors[]='Email is invalid.';
            $disciplineId=null; if($v['discipline_code']!==''){ $d=$disciplines->get(strtoupper($v['discipline_code'])); if(!$d)$errors[]='Discipline Code was not found in this University.'; else $disciplineId=(int)$d->id; }
            foreach(['student_uid','university_roll_no'] as $k){ if($v[$k]!==''){ $key=$k.'|'.strtoupper($v[$k]); if(isset($seen[$key]))$errors[]=ucwords(str_replace('_',' ',$k)).' is duplicated in this CSV.'; $seen[$key]=true; }}
            if($v['student_uid']!==''&&isset($existingStudentUids[strtoupper($v['student_uid'])]))$errors[]='Student UID already exists.';
            if($v['university_roll_no']!==''&&isset($existingUniversityRolls[strtoupper($v['university_roll_no'])]))$errors[]='University Roll No. already exists.';
            if($v['class_roll_no']!=='' && $identitySettings->class_roll_scope==='DISCIPLINE' && !$disciplineId)$errors[]='Discipline Code is required when importing an existing Class Roll under Discipline scope.';
            $classScopeKey=$identitySettings->class_roll_scope==='DISCIPLINE'&&$disciplineId?'OFFERING:'.$offering->id.'|DISCIPLINE:'.$disciplineId:'OFFERING:'.$offering->id;
            if($v['class_roll_no']!==''){ $csvClassKey='class_roll_no|'.$classScopeKey.'|'.strtoupper($v['class_roll_no']); if(isset($seen[$csvClassKey]))$errors[]='Class Roll No. is duplicated in the same configured scope in this CSV.'; $seen[$csvClassKey]=true; }
            if($v['class_roll_no']!==''&&isset($existingClassRolls[$classScopeKey.'|'.strtoupper($v['class_roll_no'])]))$errors[]='Class Roll No. already exists in its configured scope.';
            $row=['row'=>$total+1,'values'=>$v,'discipline_id'=>$disciplineId,'class_roll_scope_key'=>$v['class_roll_no']!==''?$classScopeKey:null,'errors'=>$errors]; if($errors)$invalid++;else$valid++; if($previewLimit===0||count($preview)<$previewLimit)$preview[]=$row; if($returnAll)$all[]=$row;
        } fclose($fh); return [$preview,$total,$valid,$invalid,$all];
    }
}
