<?php

namespace App\Http\Controllers;

use App\Models\AcademicSession;
use App\Models\College;
use App\Models\CollegeProgramOffering;
use App\Services\StudentImportService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response as HttpResponse;
use Illuminate\Validation\Rule;
use Inertia\Inertia;
use Inertia\Response;

class CollegeStudentImportController extends Controller
{
    public function index(Request $request, College $college, StudentImportService $service): Response
    {
        abort_unless($request->user()->hasCollegePermission('college_student_import.view',$college->id),403);
        $sessions=AcademicSession::query()->where('university_id',$college->university_id)->where('status','ACTIVE')->orderByDesc('is_current')->orderByDesc('starts_on')->get(['id','name','code','is_current']);
        $sessionId=(int)$request->query('session_id',(int)($sessions->firstWhere('is_current',true)?->id??$sessions->first()?->id??0));
        $offerings=CollegeProgramOffering::query()->with('programTemplate:id,name,code')->where('college_id',$college->id)->when($sessionId,fn($q)=>$q->where('academic_session_id',$sessionId))->where('status','ACTIVE')->orderBy('program_template_id')->get(['id','program_template_id','academic_session_id'])->map(fn($o)=>['id'=>(int)$o->id,'name'=>$o->programTemplate?->name,'code'=>$o->programTemplate?->code])->values();
        return Inertia::render('college-student-imports/index',[
            'college'=>$college->only(['id','name','code']),'sessions'=>$sessions,'offerings'=>$offerings,'session_id'=>$sessionId,
            'importState'=>$service->state($college,(int)$request->user()->id,$request->query('token')),
            'targets'=>[['key'=>'full_name','label'=>'Full Name','required'=>true],['key'=>'date_of_birth','label'=>'Date of Birth (YYYY-MM-DD)'],['key'=>'email','label'=>'Email'],['key'=>'phone','label'=>'Phone'],['key'=>'student_uid','label'=>'Existing Student UID'],['key'=>'university_roll_no','label'=>'Existing University Roll No.'],['key'=>'class_roll_no','label'=>'Existing Class Roll No.'],['key'=>'discipline_code','label'=>'Discipline Code']],
            'can'=>['manage'=>$request->user()->hasCollegePermission('college_student_import.manage',$college->id)],
        ]);
    }

    public function template(Request $request, College $college): HttpResponse
    {
        abort_unless($request->user()->hasCollegePermission('college_student_import.view',$college->id),403);
        $csv="full_name,date_of_birth,email,phone,student_uid,university_roll_no,class_roll_no,discipline_code\n";
        $csv.="Example Student,2005-01-31,student@example.edu,9999999999,,,,\n";
        return response($csv,200,['Content-Type'=>'text/csv; charset=UTF-8','Content-Disposition'=>'attachment; filename="student-import-template.csv"']);
    }

    public function upload(Request $request, College $college, StudentImportService $service): RedirectResponse
    {
        abort_unless($request->user()->hasCollegePermission('college_student_import.manage',$college->id),403);
        $data=$request->validate(['file'=>['required','file','max:5120',Rule::extensions(['csv','txt'])]]);
        $token=$service->upload($college,(int)$request->user()->id,$data['file']);
        return redirect()->route('college-student-imports.index',['college'=>$college->id,'token'=>$token])->with('toast',['type'=>'success','message'=>'CSV uploaded. Map the columns and validate the preview.']);
    }

    public function preview(Request $request, College $college, StudentImportService $service): RedirectResponse
    {
        abort_unless($request->user()->hasCollegePermission('college_student_import.manage',$college->id),403);
        $data=$request->validate(['token'=>['required','string','size:40'],'session_id'=>['required','integer'],'offering_id'=>['required','integer'],'mapping'=>['required','array']]);
        $service->preview($college,(int)$request->user()->id,$data['token'],$data);
        return redirect()->route('college-student-imports.index',['college'=>$college->id,'token'=>$data['token'],'session_id'=>$data['session_id']])->with('toast',['type'=>'success','message'=>'CSV validation completed. Review the preview before import.']);
    }

    public function store(Request $request, College $college, StudentImportService $service): RedirectResponse
    {
        abort_unless($request->user()->hasCollegePermission('college_student_import.manage',$college->id),403);
        $data=$request->validate(['token'=>['required','string','size:40']]);
        $count=$service->import($college,(int)$request->user()->id,$data['token'],(int)$request->user()->id,$request->ip());
        return redirect()->route('college-student-imports.index',['college'=>$college->id])->with('toast',['type'=>'success','message'=>"{$count} student(s) imported successfully. Identity fields left blank remain Pending in Student Identity."]);
    }
}
