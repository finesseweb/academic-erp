# PAGE IMPLEMENTATION REGISTRY

## Rule
This registry contains both implemented and future page specifications. The
repository snapshot below is authoritative for implementation status. A page
listed under the older planned inventory is not `NOT_STARTED` when it also
appears in the implemented snapshot.

Default status for all entries:
- Documentation Status: APPROVED
- Implementation Status: NOT_STARTED
- Implementation Approval: REQUIRED
- Review Status: NOT_APPLICABLE

## Repository Implementation Snapshot (2026-09-20)

Verified from `routes/web.php`, controllers, and `resources/js/pages`.

### Platform, access, and settings

- Authentication: login, registration, password reset/confirmation, email verification, two-factor challenge, and applicant authentication gateway.
- Settings: profile, security/password/two-factor/passkeys, and appearance.
- University administration: dashboard, University Profile, Affiliated Colleges, Authorized Signatories, Users, Roles, Permissions, role-permission assignment, user-role assignment, scope assignment, and Audit Logs.
- College access: College Users, College Roles, College role permissions, College user-role assignment, and College Audit Logs.
- System maintenance: Test Data Cleanup Center.

### Academic and admissions

- Academic masters: Academic Sessions, Degree Levels, Degrees, Disciplines/Specializations, Program Templates, Course Categories, Course Types, Courses, and Reservation Categories.
- Curriculum: headers, terms, slots, course mappings, validation, approval submission/inbox, workflows, and amendment/versioning.
- Academic Policies: header, Credit & Completion, Attendance, Assessment/Examination, Grading, Progression, and approval lifecycle.
- Academic Calendars: University calendar and College calendar/overrides.
- College academic setup: Program Offerings, Intake/Seat Capacity, Reservation Seat Distribution, Batches, and Sections.
- Course Delivery: Course Offerings owner-QA passed; Faculty Allocation implemented and owner QA required.
- Admissions: cycles, selection rules, form setup, internal applications, score capture, interviews, merit generation, document verification, seat allocation, confirmation, and public/applicant application flows.
- Student portal: dashboard route and page shell.

### Finance and payments

- Fee Foundation at University and College scope: categories, heads, structures, structure items, period amounts/settings/exclusions, and College adoption of University structures.
- Scholarship schemes and College student benefit assignment/approval.
- Fee Demand generation (individual and bulk), installment schedules, and Late Fine rules/recalculation.
- Payment Collection & Allocation for offline receipts and TEST-only online checkout.
- College Payment Gateway credential profiles and Fee Head routing for Razorpay, Cashfree, and PayU.
- Provider TEST connectivity is implemented; Razorpay/Cashfree/PayU runtime webhook delivery QA remains pending.
- LIVE online checkout remains blocked by design.

Detailed acceptance and QA state remains in `CURRENT_IMPLEMENTATION_STATE.md`,
`NEXT_WORKFLOW.md`, and ADRs 177-188.

## Planned Page Specifications

- `PAGE_SPECS/AUTH/CHANGE_PASSWORD_PAGE.md`
- `PAGE_SPECS/AUTH/FORGOT_PASSWORD_PAGE.md`
- `PAGE_SPECS/AUTH/LOGIN_PAGE.md`
- `PAGE_SPECS/AUTH/PROFILE_PAGE.md`
- `PAGE_SPECS/AUTH/RESET_PASSWORD_PAGE.md`
- `PAGE_SPECS/COLLEGE_FINANCE/COLLEGE_FEE_STRUCTURE_PAGE.md`
- `PAGE_SPECS/COLLEGE_FINANCE/COLLEGE_FINANCE_DASHBOARD_PAGE.md`
- `PAGE_SPECS/COLLEGE_FINANCE/COLLEGE_FINANCE_REPORTS_PAGE.md`
- `PAGE_SPECS/COLLEGE_FINANCE/COLLEGE_INSTALLMENT_PLANS_PAGE.md`
- `PAGE_SPECS/COLLEGE_FINANCE/DISCOUNTS_WAIVERS_PAGE.md`
- `PAGE_SPECS/COLLEGE_FINANCE/DISCOUNT_CONCESSION_REQUESTS_PAGE.md`
- `PAGE_SPECS/COLLEGE_FINANCE/DUES_LATE_FEES_PAGE.md`
- `PAGE_SPECS/COLLEGE_FINANCE/FEE_COLLECTION_RECEIPTS_PAGE.md`
- `PAGE_SPECS/COLLEGE_FINANCE/FEE_DEMAND_INVOICE_PAGE.md`
- `PAGE_SPECS/COLLEGE_FINANCE/INSTALLMENT_RESCHEDULING_PAGE.md`
- `PAGE_SPECS/COLLEGE_FINANCE/QUOTA_CATEGORY_MAPPING_PAGE.md`
- `PAGE_SPECS/COLLEGE_FINANCE/REFUNDS_REVERSALS_PAGE.md`
- `PAGE_SPECS/COLLEGE_FINANCE/SCHOLARSHIP_ASSIGNMENT_PAGE.md`
- `PAGE_SPECS/COLLEGE_FINANCE/STUDENT_FEE_ASSIGNMENT_PAGE.md`
- `PAGE_SPECS/COLLEGE_FINANCE/WAIVER_REQUESTS_PAGE.md`
- `PAGE_SPECS/FINANCE/COLLEGE_INSTALLMENT_PLANS_PAGE.md`
- `PAGE_SPECS/PAGE_SPEC_TEMPLATE.md`
- `PAGE_SPECS/UNIVERSITY_ADMIN/AFFILIATED_COLLEGES_LIST_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_ADMIN/AFFILIATED_COLLEGE_CREATE_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_ADMIN/AFFILIATED_COLLEGE_EDIT_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_ADMIN/AUDIT_LOG_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_ADMIN/AUTHORIZED_SIGNATORIES_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_ADMIN/DASHBOARD_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_ADMIN/LOGIN_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_ADMIN/PERMISSIONS_LIST_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_ADMIN/ROLES_LIST_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_ADMIN/ROLE_CREATE_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_ADMIN/ROLE_EDIT_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_ADMIN/ROLE_PERMISSION_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_ADMIN/SCOPE_ASSIGNMENT_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_ADMIN/THEME_MANAGEMENT_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_ADMIN/UNIVERSITY_ACADEMIC_SETUP_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_ADMIN/UNIVERSITY_FINANCE_GOVERNANCE_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_ADMIN/UNIVERSITY_PROFILE_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_ADMIN/USERS_LIST_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_ADMIN/USER_CREATE_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_ADMIN/USER_EDIT_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_ADMIN/USER_ROLE_ASSIGNMENT_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_FINANCE/ADMISSION_FEE_QUOTAS_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_FINANCE/DISCOUNT_CONCESSION_RULES_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_FINANCE/FEE_HEADS_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_FINANCE/FEE_POLICIES_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_FINANCE/FINANCE_APPROVAL_RULES_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_FINANCE/LATE_FEE_PENALTY_RULES_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_FINANCE/SCHOLARSHIP_SCHEMES_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_FINANCE/STUDENT_CATEGORIES_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_FINANCE/UNIVERSITY_FINANCE_REPORTS_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_FINANCE/UNIVERSITY_FIXED_CHARGES_PAGE.md`
- `PAGE_SPECS/UNIVERSITY_FINANCE/WAIVER_RULES_PAGE.md`

## Workflow
When a page is approved, update that PAGE_SPEC's status block.
After implementation, mark IMPLEMENTED + PENDING_REVIEW.
After project-owner acceptance, mark Review Status: ACCEPTED.
Do not automatically approve or start the next page.

## Implemented / Pending Review

- `PAGE_SPECS/UNIVERSITY_ADMIN/DEGREES_PAGE.md` — IMPLEMENTED, PENDING_REVIEW (2026-08-21).
- `PAGE_SPECS/UNIVERSITY_ADMIN/DISCIPLINES_SPECIALIZATIONS_PAGE.md` — IMPLEMENTED, PENDING_REVIEW (2026-08-21).
- `PAGE_SPECS/UNIVERSITY_ADMIN/PROGRAM_TEMPLATES_PAGE.md` — IMPLEMENTED, PENDING_REVIEW (2026-08-21).
- `PAGE_SPECS/UNIVERSITY_ADMIN/COURSE_CATEGORIES_PAGE.md` — IMPLEMENTED, PENDING_REVIEW (2026-08-21).

- `PAGE_SPECS/COLLEGE_ACCESS_COLLEGE_ACCESS_AUDIT.md` — IMPLEMENTED, PENDING_REVIEW (2026-08-21).
- `PAGE_SPECS/UNIVERSITY_ADMIN/ACADEMIC_SESSIONS_PAGE.md` — IMPLEMENTED, PENDING_REVIEW (2026-08-21).
- `PAGE_SPECS/UNIVERSITY_ADMIN/DEGREE_LEVELS_PAGE.md` — IMPLEMENTED, PENDING_REVIEW (2026-08-21).

- `PAGE_SPECS/COLLEGE_ACCESS_COLLEGE_ADMIN_ASSIGNMENT.md` — IMPLEMENTED, PENDING_REVIEW (2026-08-20).
- `PAGE_SPECS/COLLEGE_ACCESS_COLLEGE_USERS.md` — IMPLEMENTED, PENDING_REVIEW (2026-08-20).
- `PAGE_SPECS/COLLEGE_ACCESS_COLLEGE_ROLES.md` — IMPLEMENTED, PENDING_REVIEW (2026-08-20).
- `PAGE_SPECS/COLLEGE_ACCESS_COLLEGE_ROLE_PERMISSIONS.md` — IMPLEMENTED, PENDING_REVIEW (2026-08-20).
- `PAGE_SPECS/COLLEGE_ACCESS_COLLEGE_USER_ROLE_ASSIGNMENT.md` — IMPLEMENTED, PENDING_REVIEW (2026-08-20).
- `PAGE_SPECS/COLLEGE_ACCESS_COLLEGE_SCOPE_ASSIGNMENT.md` — IMPLEMENTED, PENDING_REVIEW (2026-08-20).

- `PAGE_SPECS/UNIVERSITY_ADMIN/UNIVERSITY_PROFILE_PAGE.md` — IMPLEMENTED, PENDING_REVIEW (2026-08-18).
- `PAGE_SPECS/UNIVERSITY_ADMIN/AFFILIATED_COLLEGES_LIST_PAGE.md` — IMPLEMENTED, PENDING_REVIEW (2026-08-19).
- `PAGE_SPECS/UNIVERSITY_ADMIN/AFFILIATED_COLLEGE_CREATE_PAGE.md` — IMPLEMENTED, PENDING_REVIEW (2026-08-19).
- `PAGE_SPECS/UNIVERSITY_ADMIN/AFFILIATED_COLLEGE_EDIT_PAGE.md` — IMPLEMENTED, PENDING_REVIEW (2026-08-19).

## NEXT Workflow Selection Rule

Implemented 2026-08-19: `PAGE_SPECS/UNIVERSITY_ADMIN/AUTHORIZED_SIGNATORIES_PAGE.md` — IMPLEMENTED, PENDING_REVIEW.
Implemented 2026-08-19: Users list, create, and edit PAGE_SPECs — IMPLEMENTED, PENDING_REVIEW.
Implemented 2026-08-19: Roles list, create, and edit PAGE_SPECs — IMPLEMENTED, PENDING_REVIEW.
Implemented 2026-08-19: Permissions catalog PAGE_SPEC — IMPLEMENTED, PENDING_REVIEW.
Implemented 2026-08-20: Role Permission Matrix PAGE_SPEC — IMPLEMENTED, PENDING_REVIEW.
Implemented 2026-08-20: User Role Assignment PAGE_SPEC — IMPLEMENTED, PENDING_REVIEW.
Implemented 2026-08-20: Scope Assignment PAGE_SPEC — IMPLEMENTED, PENDING_REVIEW.

On `next` / `next N` / `nextN`:
- repository reality overrides stale status;
- MASTER_DEVELOPMENT_HIERARCHY.md determines sequence;
- PAGE_SPEC determines functional requirements;
- the earliest eligible incomplete milestone is implemented first;
- plain `next` advances exactly 1 newly completed milestone;
- `next N` / `nextN` advances exactly N newly completed eligible milestones sequentially in the same approved run;
- each milestone is validated and documented before the next milestone in the approved batch begins;
- already-completed milestones are skipped and do not consume the requested count.

## Course / Subject Master — implemented 2026-08-21

- Page: Course / Subject Master
- Route: `/admin/courses`
- Status: IMPLEMENTED
- UI pattern: shared `AcademicMasterPage`
- Permission gate: `course.view`
- Next dependent implementation: Curriculum / Course Mapping

| Curriculum Header | University Admin | `/admin/curricula` | `curriculum.view` | IMPLEMENTED_IN_REPLACEMENT_PACKAGE | 2026-08-22 |

| Curriculum Manage Structure — Terms / Semesters | University Admin | `/admin/curricula/{curriculum}/structure/terms` | `curriculum.view` / `curriculum.update` | IMPLEMENTED_IN_REPLACEMENT_PACKAGE | 2026-08-22 |

| Course / Paper Mapping | University Admin | `/admin/curricula/{curriculum}/structure/terms/{term}/slots/{slot}/course-mappings` | `curriculum.view` / `curriculum.update` | IMPLEMENTED_IN_REPLACEMENT_PACKAGE | 2026-08-22 |


## Curriculum Amendment / Versioning — 2026-08-24
- Page surface: existing `resources/js/pages/admin/curricula/index.tsx`
- Action: `More -> Amend Curriculum`
- Route: `POST /admin/curricula/{curriculum}/amend`
- Controller: `CurriculumController::amend`
- Service: `CurriculumAmendmentService`
- Request: `StoreCurriculumAmendmentRequest`
- Database: self-linked amendment metadata on `curricula`
- Status: IMPLEMENTED_IN_REPLACEMENT_PACKAGE; repository apply/QA required

- University Admin / Academic Policies — Phase 1 IMPLEMENTED (package): Header/Master + validation. Degree Level scope added in 2026-08-25 replacement package; QA pending.
- University Admin / Academic Policy / Credit & Completion — Phase 1 IMPLEMENTED (package).
- Academic Policy Approval Execution — IMPLEMENTED; common Inbox integration complete, QA gate pending.
- University Admin / Academic Policy / Attendance — Phase 2 IMPLEMENTED (package): configurable attendance threshold, calculation level, condonation, exam-eligibility flag, special exemption permission, rounding, validation integration.

| Academic Policy — Assessment / Examination | `/admin/academic-policies/{academicPolicy}/assessment-examination` | `resources/js/pages/admin/academic-policies/assessment-examination.tsx` | IMPLEMENTED — Phase 3 |

| Academic Policy — Grading | `/admin/academic-policies/{academicPolicy}/grading` | `resources/js/pages/admin/academic-policies/grading.tsx` | IMPLEMENTED — Phase 4 |

| Academic Policy — Promotion / Progression | `/admin/academic-policies/{academicPolicy}/progression` | `resources/js/pages/admin/academic-policies/progression.tsx` | IMPLEMENTED — Phase 5 |

## Academic Calendar — 2026-08-25
- `PAGE_SPECS/UNIVERSITY_ADMIN/ACADEMIC_CALENDAR_PAGE.md` — CORE_IMPLEMENTED, PENDING_REVIEW.
- Route: `/admin/academic-calendars`.
- Permission gate: `academic_calendar.view`.
- Database: `academic_calendars`, `academic_calendar_events`.
- Current gate: Academic Calendar QA in `NEXT_WORKFLOW.md`.



## College Program Offerings — 2026-08-25
- Route: `/college/{college}/program-offerings`
- Page: `college-program-offerings/index`
- Status: `IMPLEMENTED_IN_REPLACEMENT_PACKAGE / PENDING_REVIEW`
- Scope: College
- Source definitions: University Program Template + approved Curriculum + Academic Session
- Current gate: Program Offering QA in `NEXT_WORKFLOW.md`.

## Admission Form Configuration & Internal Entry — Stage 1 — 2026-08-27
- `PAGE_SPECS/COLLEGE_ADMISSION/ADMISSION_FORM_SETUP_AND_INTERNAL_ENTRY_PAGE.md` — IMPLEMENTED_IN_PACKAGE / OWNER_QA_REQUIRED.
- Setup route: `/college/{college}/admission-form-setup`.
- Internal entry route reused: `/college/{college}/admission-applications`.
- Permission gates: `college_admission_form.view`, `college_admission_form.manage`, `college_admission_form.map`, `college_application_fee.manage`.
- Resume after acceptance: Interview Scheduling / Evaluation QA -> Merit / Roster Generation.

## Student Fee Ledger — 2026-09-12
- PAGE_SPEC: `PAGE_SPECS/COLLEGE_FINANCE/STUDENT_FEE_LEDGER_PAGE.md`
- Route: `/college/{college}/fee-ledger`
- Page: `resources/js/pages/college-fee-ledger/index.tsx`
- Permission: `college_fee_ledger.view`
- Service: `FeeLedgerService`
- Status: IMPLEMENTED / OWNER_QA_REQUIRED
- Accounting model: read-only projection; no duplicate ledger transaction table.

## ADR 190 — Fee Adjustments / Reversal / Refund
- Page: `resources/js/pages/college-fee-adjustments/index.tsx`
- Route: `/college/{college}/fee-adjustments`
- Controller: `CollegeFeeAdjustmentController`
- Service: `FeeAdjustmentRefundService`
- Status: IMPLEMENTED / OWNER QA REQUIRED (2026-09-12)

## Fee Clearance — 2026-09-16
- PAGE_SPEC: `PAGE_SPECS/COLLEGE_FINANCE/FEE_CLEARANCE_PAGE.md`
- Route: `/college/{college}/fee-clearance`
- Page: `resources/js/pages/college-fee-clearance/index.tsx`
- Controller: `CollegeFeeClearanceController`
- Service: `FeeClearanceService`
- Permission: `college_fee_clearance.view`
- Governing decision: ADR 197
- Status: IMPLEMENTED / OWNER_QA_REQUIRED
- Accounting model: read-only projection over required Demand Item snapshots + authoritative Student Fee Ledger; no duplicate clearance balance/table.
- Downstream gate: Student Enrollment remains blocked until owner QA PASS.

- `PAGE_SPECS/COURSE_DELIVERY/COURSE_OFFERINGS_PAGE.md` — IMPLEMENTED, PENDING_REVIEW / OWNER QA REQUIRED (2026-09-20).
- `PAGE_SPECS/COURSE_DELIVERY/FACULTY_ALLOCATIONS_PAGE.md` — IMPLEMENTED, PENDING_REVIEW / OWNER QA REQUIRED (2026-09-21).
